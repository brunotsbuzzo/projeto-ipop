"""API do Cadastro de Regras IPOP (usada pelo frontend Angular).

Fluxo:
  1. POST /api/validacoes        a planilha vai para o bucket e o worker confere (sem abrir o IPOP)
  2. GET  /api/validacoes/{id}   a tela acompanha até ficar "valido" ou "com_erros"
  3. POST /api/solicitacoes      com a validação OK, a solicitação entra na fila de cadastro
  4. GET  /api/solicitacoes[/id] histórico e detalhe com o andamento regra por regra

Rodar: uvicorn app.main:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import io
import logging
import re
import secrets
import tempfile
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import Annotated, Any

from fastapi import Depends, FastAPI, File, HTTPException, Query, UploadFile, status
from fastapi.responses import PlainTextResponse, StreamingResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

from ipop import config as config_mod
from ipop.infra.armazenamento import Armazenamento, prefixo_execucao
from ipop.infra.db import Repositorio, para_json
from ipop.progresso import FASES_FINAIS, FUSO

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
logger = logging.getLogger("app")

CONFIG = config_mod.carregar()
ID_VALIDO = re.compile(r"^\d{8}-\d{6}-[0-9a-f]{6}$")
EXTENSOES = {".xlsx", ".xlsm"}
MAGIC_ZIP = b"PK\x03\x04"


class Estado:
    repo: Repositorio | None = None
    armazenamento: Armazenamento | None = None


@asynccontextmanager
async def ciclo_de_vida(_app: FastAPI):
    if not CONFIG.web_usuario or not CONFIG.web_senha:
        raise RuntimeError("Defina WEB_USUARIO e WEB_SENHA.")
    faltando = CONFIG.faltando_infra()
    if faltando:
        raise RuntimeError(f"Faltam variáveis de ambiente: {', '.join(faltando)}")
    Estado.repo = Repositorio(CONFIG)
    Estado.armazenamento = Armazenamento(CONFIG)
    Estado.repo.garantir_schema()
    Estado.armazenamento.garantir_bucket()
    yield
    Estado.repo.fechar()


app = FastAPI(title="Cadastro de Regras IPOP", lifespan=ciclo_de_vida, docs_url="/api/docs",
              openapi_url="/api/openapi.json", redoc_url=None)
seguranca = HTTPBasic(realm="Cadastro de Regras IPOP")


def usuario_logado(cred: Annotated[HTTPBasicCredentials, Depends(seguranca)]) -> str:
    ok = (secrets.compare_digest(cred.username.encode(), CONFIG.web_usuario.encode())
          and secrets.compare_digest(cred.password.encode(), CONFIG.web_senha.encode()))
    if not ok:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Usuário ou senha inválidos.",
                            headers={"WWW-Authenticate": 'Basic realm="Cadastro de Regras IPOP"'})
    return cred.username


Usuario = Annotated[str, Depends(usuario_logado)]


def repo() -> Repositorio:
    return Estado.repo  # type: ignore[return-value]


def bucket() -> Armazenamento:
    return Estado.armazenamento  # type: ignore[return-value]


def novo_id() -> str:
    return datetime.now(FUSO).strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(3)


# ---------- regras de apresentação ----------
FEITAS = ("confirmada", "salva_sem_confirmacao")


def status_da_solicitacao(e: dict, regras: list[dict] | None = None) -> dict:
    """Converte a fase técnica no status que a tela mostra (Status Tag do design system)."""
    fase = e["fase"]
    if regras is not None:
        total = len(regras)
        feitas = sum(1 for r in regras if r["status"] in FEITAS)
        parada = next((r["n"] for r in regras if r["status"] in ("erro", "verificar")), None)
    else:
        contagem = e.get("contagem") or {}
        total = e.get("total_regras") or 0
        feitas = sum(contagem.get(s, 0) for s in FEITAS)
        parada = e.get("parada")
    if fase in ("na_fila", "reservada"):
        return {"codigo": "recebida", "rotulo": "Recebida", "tag": "info"}
    if fase in ("verificando_rede", "lendo_planilha"):
        return {"codigo": "conferindo", "rotulo": "Conferindo dados", "tag": "processing"}
    if fase in ("login", "cadastrando"):
        rotulo = f"Cadastrando · {min(feitas + 1, total)} de {total}" if total else "Cadastrando"
        return {"codigo": "cadastrando", "rotulo": rotulo, "tag": "processing"}
    if fase == "concluida":
        return {"codigo": "concluida", "rotulo": "Concluída", "tag": "success"}
    if fase == "cancelada":
        return {"codigo": "cancelada", "rotulo": "Cancelada", "tag": "default"}
    if fase == "erro_validacao":
        return {"codigo": "erro", "rotulo": "Planilha com erros", "tag": "error"}
    if parada:
        return {"codigo": "erro", "rotulo": f"Parou na regra {parada}", "tag": "error"}
    if fase == "interrompida":
        return {"codigo": "erro", "rotulo": "Interrompida", "tag": "error"}
    return {"codigo": "erro", "rotulo": "Erro", "tag": "error"}


def regra_para_tela(execucao_id: str, r: dict) -> dict:
    dados = dict(r.get("dados") or {})
    return {
        **dados,
        "n": r["n"],
        "nome": dados.get("nome", r["nome"]),
        "modulo": dados.get("modulo", r["modulo"]),
        "linha": dados.get("linha", r["linha"]),
        "status": r["status"],
        "detalhe": r["detalhe"],
        "print_url": f"/api/solicitacoes/{execucao_id}/arquivos/{r['print']}" if r.get("print") else None,
        "inicio": r.get("inicio"),
        "fim": r.get("fim"),
    }


def resumo_regras(regras: list[dict]) -> dict:
    subs = sum(1 for r in regras if r["modulo"] == "Subscrição")
    return {"subscricao": subs, "oferta": len(regras) - subs, "total": len(regras),
            "cadastradas": sum(1 for r in regras if r["status"] in FEITAS)}


def resumo_lista(e: dict) -> dict:
    return para_json({
        "id": e["id"], "lote_id": e["lote_id"], "titulo": e["titulo"], "solicitante": e["solicitante"],
        "categoria": e["categoria"], "criada_em": e["criada_em"], "terminou_em": e["terminou_em"],
        "status": status_da_solicitacao(e), "total_regras": e.get("total_regras") or 0,
    })


def _obter(id_: str, tipo: str) -> dict:
    if not ID_VALIDO.match(id_):
        raise HTTPException(404, "Não encontrada.")
    e = repo().obter_execucao(id_)
    if e is None or e["tipo"] != tipo:
        raise HTTPException(404, "Não encontrada.")
    return e


# ---------- configuração ----------
@app.get("/saude", include_in_schema=False)
def saude():
    return {"ok": True}


@app.get("/api/config")
def obter_config(usuario: Usuario):
    workers = repo().listar_workers()
    return para_json({
        "usuario": usuario,
        "categorias": list(CONFIG.categorias),
        "ambiente": CONFIG.robo_ambiente,
        "tamanho_maximo_mb": CONFIG.tamanho_maximo_mb,
        "worker_online": any(w["online"] for w in workers),
    })


@app.get("/api/workers")
def listar_workers(_: Usuario):
    return para_json(repo().listar_workers())


@app.post("/api/workers/checar", status_code=202)
def pedir_checagem(_: Usuario):
    repo().pedir_checagem()
    return {"ok": True}


@app.get("/api/modelo-planilha")
def baixar_modelo(_: Usuario):
    from app.modelo_planilha import gerar_modelo
    conteudo = gerar_modelo(CONFIG, bucket())
    return StreamingResponse(
        io.BytesIO(conteudo),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": 'attachment; filename="ModeloRegras-SubseOferta.xlsx"'},
    )


# ---------- validação ----------
@app.post("/api/validacoes", status_code=201)
async def criar_validacao(usuario: Usuario, arquivo: Annotated[UploadFile, File()]):
    nome = Path(arquivo.filename or "pedido.xlsx").name
    if Path(nome).suffix.lower() not in EXTENSOES:
        raise HTTPException(422, "Envie a planilha XLSX do modelo oficial.")
    limite = CONFIG.tamanho_maximo_mb * 1024 * 1024
    id_ = novo_id()
    chave = prefixo_execucao(id_) + "pedido.xlsx"
    with tempfile.TemporaryDirectory() as temporaria:
        destino = Path(temporaria) / "pedido.xlsx"
        tamanho = 0
        with open(destino, "wb") as saida:
            while bloco := await arquivo.read(1024 * 1024):
                tamanho += len(bloco)
                if tamanho > limite:
                    raise HTTPException(413, f"A planilha passa de {CONFIG.tamanho_maximo_mb} MB.")
                saida.write(bloco)
        if destino.read_bytes()[:4] != MAGIC_ZIP:
            raise HTTPException(422, "O arquivo não é uma planilha XLSX válida.")
        await run_in_threadpool(bucket().enviar, destino, chave)
    repo().criar_execucao(id=id_, tipo="validacao", usuario=usuario, nome_original=nome, objeto_pedido=chave,
                          tamanho_arquivo=tamanho, ambiente=CONFIG.robo_ambiente, so_dados=True)
    return {"id": id_, "status": "validando"}


@app.get("/api/validacoes/{validacao_id}")
def obter_validacao(validacao_id: str, _: Usuario):
    e = _obter(validacao_id, "validacao")
    regras = [regra_para_tela(e["id"], r) for r in e["regras"]]
    problemas = e.get("problemas") or []
    if e["fase"] == "concluida_so_dados":
        situacao = "valido"
    elif e["fase"] == "erro_validacao":
        situacao = "com_erros"
    elif e["fase"] in FASES_FINAIS:
        situacao = "falhou"
    else:
        situacao = "validando"
    return para_json({
        "id": e["id"],
        "status": situacao,
        "mensagem": e["mensagem"],
        "arquivo": {"nome": e["nome_original"], "tamanho": e["tamanho_arquivo"], "validado_em": e["terminou_em"]},
        "resumo": resumo_regras(regras),
        "regras": regras,
        "erros": [p for p in problemas if p.get("nivel") == "erro"],
        "avisos": [p for p in problemas if p.get("nivel") == "aviso"],
    })


# ---------- solicitações ----------
class NovaSolicitacao(BaseModel):
    validacao_id: str
    titulo: str = Field(min_length=1, max_length=200)
    lote_id: str = Field(min_length=1, max_length=40)
    solicitante: str = Field(min_length=1, max_length=120)
    categoria: str = Field(min_length=1, max_length=80)


@app.post("/api/solicitacoes", status_code=201)
def criar_solicitacao(usuario: Usuario, dados: NovaSolicitacao):
    v = _obter(dados.validacao_id, "validacao")
    if v["fase"] != "concluida_so_dados":
        raise HTTPException(409, "A planilha precisa estar validada e sem erros para enviar.")
    if dados.categoria not in CONFIG.categorias:
        raise HTTPException(422, "Categoria do pedido inválida.")
    ja = next((s for s in repo().listar_execucoes(500) if s.get("validacao_id") == v["id"]), None)
    if ja:
        raise HTTPException(409, f"Esta planilha já foi enviada na solicitação do lote {ja['lote_id']}.")
    id_ = novo_id()
    repo().criar_execucao(
        id=id_, tipo="cadastro", usuario=usuario, solicitante=dados.solicitante.strip(), titulo=dados.titulo.strip(),
        lote_id=dados.lote_id.strip(), categoria=dados.categoria, validacao_id=v["id"],
        nome_original=v["nome_original"], tamanho_arquivo=v["tamanho_arquivo"], objeto_pedido=v["objeto_pedido"],
        ambiente=CONFIG.robo_ambiente, so_dados=False,
    )
    # A tabela de regras aparece já no envio (todas "pendente"); o robô regrava ao conferir de novo.
    repo().definir_regras(id_, [
        {**{k: r.get(k) for k in ("n", "nome", "aba", "linha", "modulo", "tipo", "percentual", "vigencia", "modelo",
                                    "variaveis", "dados")}, "status": "pendente", "detalhe": ""}
        for r in v["regras"]
    ])
    return obter_solicitacao(id_, usuario)


@app.get("/api/solicitacoes")
def listar_solicitacoes(_: Usuario, busca: str = "", filtro_status: Annotated[str, Query(alias="status")] = "",
                        limite: int = 200):
    itens = [resumo_lista(e) for e in repo().listar_execucoes(max(1, min(limite, 500)), busca=busca)]
    if filtro_status:
        itens = [i for i in itens if i["status"]["codigo"] == filtro_status]
    return itens


@app.get("/api/solicitacoes/{solicitacao_id}")
def obter_solicitacao(solicitacao_id: str, _: Usuario):
    e = _obter(solicitacao_id, "cadastro")
    regras = [regra_para_tela(e["id"], r) for r in e["regras"]]
    st = status_da_solicitacao(e, e["regras"])
    retomar_de = next((r["n"] for r in regras if r["status"] not in FEITAS), None)
    return para_json({
        "id": e["id"], "lote_id": e["lote_id"], "titulo": e["titulo"], "solicitante": e["solicitante"],
        "categoria": e["categoria"], "usuario": e["usuario"], "ambiente": e["ambiente"],
        "criada_em": e["criada_em"], "terminou_em": e["terminou_em"], "fase": e["fase"], "mensagem": e["mensagem"],
        "status": st,
        "ativa": e["fase"] not in FASES_FINAIS,
        "pode_cancelar": e["fase"] not in FASES_FINAIS and not e["cancelar"],
        "pode_retomar": e["fase"] in ("erro", "interrompida", "cancelada") and retomar_de is not None,
        "retomar_de": retomar_de,
        "arquivo": {"nome": e["nome_original"], "tamanho": e["tamanho_arquivo"],
                    "url": f"/api/solicitacoes/{e['id']}/arquivo"},
        "resumo": resumo_regras(regras),
        "regras": regras,
        "problemas": e.get("problemas") or [],
        "eventos": repo().listar_eventos(e["id"]),
    })


@app.post("/api/solicitacoes/{solicitacao_id}/cancelar")
def cancelar_solicitacao(solicitacao_id: str, usuario: Usuario):
    _obter(solicitacao_id, "cadastro")
    resultado = repo().pedir_cancelamento(solicitacao_id)
    if resultado is None:
        raise HTTPException(409, "Esta solicitação não está na fila nem em andamento.")
    if resultado == "cancelada":
        repo().inserir_evento(solicitacao_id, "cancelada", "Cancelada", "Cancelada antes de o robô começar.", usuario)
    return {"resultado": resultado}


class Retomada(BaseModel):
    inicio: int | None = Field(default=None, ge=1)


@app.post("/api/solicitacoes/{solicitacao_id}/retomar")
def retomar_solicitacao(solicitacao_id: str, usuario: Usuario, dados: Retomada | None = None):
    atual = obter_solicitacao(solicitacao_id, usuario)
    inicio = (dados.inicio if dados and dados.inicio else None) or atual["retomar_de"]
    if not atual["pode_retomar"] or not inicio:
        raise HTTPException(409, "Esta solicitação não pode ser retomada agora.")
    if not repo().retomar(solicitacao_id, inicio, usuario):
        raise HTTPException(409, "Esta solicitação não pode ser retomada agora.")
    return obter_solicitacao(solicitacao_id, usuario)


@app.get("/api/solicitacoes/{solicitacao_id}/arquivo")
def baixar_planilha(solicitacao_id: str, _: Usuario):
    e = _obter(solicitacao_id, "cadastro")
    return _stream(e["objeto_pedido"], e["nome_original"])


@app.get("/api/solicitacoes/{solicitacao_id}/arquivos/{caminho:path}")
def baixar_arquivo(solicitacao_id: str, caminho: str, _: Usuario):
    e = _obter(solicitacao_id, "cadastro")
    if ".." in caminho.split("/") or caminho.startswith("/"):
        raise HTTPException(404, "Arquivo não encontrado.")
    return _stream(prefixo_execucao(e["id"]) + caminho, Path(caminho).name)


@app.get("/api/solicitacoes/{solicitacao_id}/log", response_class=PlainTextResponse)
def ler_log(solicitacao_id: str, _: Usuario, linhas: int = 400):
    _obter(solicitacao_id, "cadastro")
    registros = repo().ler_logs(solicitacao_id, max(1, min(linhas, 5000)))
    return "\n".join(
        f"{r['criado_em'].astimezone(FUSO):%d/%m %H:%M:%S} | {r['nivel']:<7} | {r['mensagem']}" for r in registros
    ) or "(ainda sem log)"


def _stream(chave: str, nome: str):
    try:
        pedacos, tipo, tamanho = bucket().abrir(chave)
    except FileNotFoundError:
        raise HTTPException(404, "Arquivo não encontrado.") from None
    cabecalhos = {"Content-Disposition": f"inline; filename*=UTF-8''{_quote(nome)}"}
    if tamanho:
        cabecalhos["Content-Length"] = str(tamanho)
    return StreamingResponse(pedacos, media_type=tipo, headers=cabecalhos)


def _quote(nome: str) -> str:
    from urllib.parse import quote
    return quote(nome)


def _json(valor: Any) -> Any:  # pragma: no cover - atalho para depuração
    return para_json(valor)
