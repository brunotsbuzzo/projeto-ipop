"""Gera a planilha-modelo oficial (botão "Baixar modelo da planilha")."""
from __future__ import annotations

import io
import tempfile
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

from ipop.config import Config
from ipop.services.leitor_pedido import COLUNAS_FIXAS

EXEMPLOS_SUBSCRICAO = [
    "CodParceiro Exclusão (Categórica)",
    "NroCpfCnpj Inclusão (Categórica)",
    "ClasseBonus Inclusão (Categórica)",
    "IdadeSegurado Inclusão (Contínua)",
]
COLUNAS_OFERTA = ["Nome Agrupamento", "Fator (%)", "Data Inicial", "Data Final", "Código Parceiro (Exclusão)"]
CABECALHO = PatternFill("solid", fgColor="E6F2EC")


def _aba(wb: Workbook, titulo: str, colunas: list[str], linhas: list[list] | None = None):
    ws = wb.create_sheet(titulo)
    ws.append(colunas)
    for celula in ws[1]:
        celula.font = Font(bold=True, color="002612")
        celula.fill = CABECALHO
    for linha in linhas or []:
        ws.append(linha)
    for i, nome in enumerate(colunas, start=1):
        ws.column_dimensions[get_column_letter(i)].width = max(14, min(42, len(str(nome)) + 4))
    ws.freeze_panes = "A2"
    return ws


def gerar_modelo(config: Config, armazenamento=None) -> bytes:
    with tempfile.TemporaryDirectory() as temporaria:
        tbl = Path(temporaria)
        if armazenamento is None or not armazenamento.baixar_tabelas_auxiliares(tbl):
            tbl = config.tbl_dim_dir
        de_para = pd.read_excel(tbl / "TblDePara.xlsx")
        modelos = pd.read_excel(tbl / "TblRegraModelo.xlsx")

    wb = Workbook()
    wb.remove(wb.active)
    _aba(wb, "Módulo Subscrição", COLUNAS_FIXAS + EXEMPLOS_SUBSCRICAO, [[
        "Automóvel", "2026-11-01", "2026-11-30", "R_EXEMPLO_Agravo_10%", "Agravo/Desconto", 1.10,
        "Ituran Compreensiva", "", "10", "R_EXEMPLO_Agravo_10%", "5; 6; 7", "18 a 25",
    ]])
    _aba(wb, "Módulo Oferta", COLUNAS_OFERTA, [["R_EXEMPLO_Oferta_6%", 6, "2026-11-01", "2026-11-30", "10"]])
    _aba(wb, "Tabela de variáveis", ["Nome no IPOP", "Nome na planilha (NomeDW)", "Código"],
         de_para[["Nome Ipop", "NomeDW", "IDVariavel"]].astype(str).values.tolist())
    _aba(wb, "Modelos de regras", ["Modelos de regras", "Descrição"],
         modelos[["Modelos de regras", "Descrição"]].fillna("").astype(str).values.tolist())
    ajuda = wb.create_sheet("Como preencher")
    for texto in [
        "Uma linha = uma regra. Preencha a aba Módulo Subscrição e/ou a aba Módulo Oferta.",
        "Nome das colunas de variável: <NomeDW> <Inclusão|Exclusão> (<Categórica|Contínua>). Ex.: CodParceiro Exclusão (Categórica).",
        "Vários valores na mesma célula: separe por ;  ·  Faixas contínuas: 18 a 25; 26 a 40.",
        "Fator na Subscrição é multiplicador: 1,58 = +58% · 0,90 = −10%. Na Oferta, Fator (%) é o percentual.",
        "Modelos de regras: use um nome da aba Modelos de regras, ou Não se aplica para criar a regra do zero.",
    ]:
        ajuda.append([texto])
    ajuda.column_dimensions["A"].width = 120
    saida = io.BytesIO()
    wb.save(saida)
    return saida.getvalue()
