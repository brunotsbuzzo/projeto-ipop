"""Worker do robô: pega execuções no Postgres, baixa a planilha do bucket e roda o robô.

Duas filas, cada uma numa thread:
- validação (conferir a planilha antes do envio): rápida, não abre navegador, roda ao lado do cadastro;
- cadastro (abre o IPOP): uma por vez em todo o sistema, garantido por um advisory lock do Postgres.

Rodar: python -m ipop.worker
"""
from __future__ import annotations

import logging
import tempfile
import threading
import time
from pathlib import Path

from ipop import config as config_mod
from ipop.cli import configurar_log
from ipop.conectividade import como_dicts, verificar
from ipop.infra.armazenamento import Armazenamento, prefixo_execucao
from ipop.infra.db import Repositorio
from ipop.infra.progresso_banco import HandlerLogBanco, ProgressoBanco
from ipop.progresso import instalar_sinais, parada_solicitada
from ipop.robo import executar

logger = logging.getLogger("ipop.worker")

SEGUNDOS_BATIMENTO = 5
SEGUNDOS_CHECAGEM_PERIODICA = 15 * 60
SEGUNDOS_ORFA = 120


class Worker:
    def __init__(self, config: config_mod.Config, repo: Repositorio, armazenamento: Armazenamento):
        self.config = config
        self.repo = repo
        self.armazenamento = armazenamento
        self.nome = config.worker_nome
        self.ativas: dict[str, str] = {}  # tipo -> id da execução
        self.handlers: dict[str, HandlerLogBanco] = {}
        self._trava = threading.Lock()
        self._ultima_checagem = 0.0
        robo_log = logging.getLogger("ipop")
        if robo_log.getEffectiveLevel() > logging.INFO:  # o log da execução precisa do passo a passo
            robo_log.setLevel(logging.INFO)

    # ---------- ciclo de vida ----------
    def rodar(self) -> None:
        instalar_sinais()
        self.repo.registrar_worker(self.nome)
        self.repo.recuperar_orfas(SEGUNDOS_ORFA)
        logger.info("Worker %s no ar (ambiente padrão %s).", self.nome, self.config.robo_ambiente)
        threads = [
            threading.Thread(target=self._laco_batimento, name="batimento", daemon=True),
            threading.Thread(target=self._laco, args=("validacao",), name="validacao", daemon=True),
        ]
        for t in threads:
            t.start()
        try:
            self._laco("cadastro")
        finally:
            for t in threads[1:]:
                t.join(timeout=30)
            self._descarregar_logs()
            self.repo.worker_saiu(self.nome)
            logger.info("Worker encerrado.")

    def _laco(self, tipo: str) -> None:
        controle = self.repo.conexao_dedicada()
        controle.execute(f"LISTEN {self.repo.canal_fila}")
        try:
            while not parada_solicitada():
                try:
                    processou = self.processar_uma(tipo, controle)
                except Exception:
                    logger.exception("Falha no laço de %s; tentando de novo em instantes.", tipo)
                    processou = False
                    time.sleep(self.config.worker_intervalo_s)
                if not processou:
                    for _ in controle.notifies(timeout=self.config.worker_intervalo_s, stop_after=1):
                        pass
        finally:
            controle.close()

    def processar_uma(self, tipo: str, controle=None) -> bool:
        """Processa a próxima execução do tipo. Devolve False se a fila estava vazia."""
        usa_trava = tipo == "cadastro"
        dono = controle or self.repo.conexao_dedicada()
        try:
            if usa_trava and not self.repo.tentar_trava_do_robo(dono):
                return False  # outro worker está com o robô
            try:
                execucao = self.repo.reservar_proxima(self.nome, tipo)
                if execucao is None:
                    return False
                self._executar(execucao)
                return True
            finally:
                if usa_trava:
                    self.repo.soltar_trava_do_robo(dono)
        finally:
            if controle is None:
                dono.close()

    # ---------- uma execução ----------
    def _executar(self, execucao: dict) -> None:
        id_ = execucao["id"]
        tipo = execucao["tipo"]
        logger.info("Iniciando %s %s (%s)", tipo, id_, execucao["nome_original"])
        tid = threading.get_ident()
        handler = HandlerLogBanco(self.repo, id_, thread_id=tid)
        raiz = logging.getLogger()
        with tempfile.TemporaryDirectory(prefix=f"ipop-{id_}-") as temporaria:
            pasta = Path(temporaria)
            arquivo_log = logging.FileHandler(pasta / "execucao.log", encoding="utf-8")
            arquivo_log.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"))
            arquivo_log.addFilter(lambda r: r.thread == tid)
            raiz.addHandler(handler)
            raiz.addHandler(arquivo_log)
            with self._trava:
                self.ativas[tipo] = id_
                self.handlers[id_] = handler
            progresso = ProgressoBanco(self.repo, self.armazenamento, id_, inicio=execucao["inicio"],
                                       registrar_eventos=tipo == "cadastro")
            try:
                self.armazenamento.baixar(execucao["objeto_pedido"], pasta / "pedido.xlsx")
                tbl_dim = pasta / "tbl_dim"
                usar_bucket = self.armazenamento.baixar_tabelas_auxiliares(tbl_dim)
                parametros = {
                    "pedido": "pedido.xlsx",
                    "ambiente": execucao["ambiente"],
                    "so_dados": execucao["so_dados"],
                    "inicio": execucao["inicio"],
                    "continuar_em_erro": execucao["continuar_em_erro"],
                }
                codigo = executar(pasta, self.config, progresso, parametros,
                                  tbl_dim_dir=tbl_dim if usar_bucket else None)
                logger.info("Terminou %s com código %s", id_, codigo)
            except Exception as erro:
                logger.exception("Falha ao preparar a execução %s", id_)
                progresso.fase("erro", f"Não foi possível preparar a execução: {erro}")
            finally:
                raiz.removeHandler(handler)
                raiz.removeHandler(arquivo_log)
                arquivo_log.close()
                with self._trava:
                    self.ativas.pop(tipo, None)
                    self.handlers.pop(id_, None)
                try:
                    handler.descarregar()
                    self.armazenamento.enviar(pasta / "execucao.log", prefixo_execucao(id_) + "execucao.log")
                except Exception:
                    logger.warning("Não foi possível guardar o log de %s.", id_)

    # ---------- batimento, log e checagem de rede ----------
    def _laco_batimento(self) -> None:
        while not parada_solicitada():
            try:
                with self._trava:
                    ativas = list(self.ativas.values())
                pedido = self.repo.batimento(self.nome, self.ativas.get("cadastro"), ativas)
                self._descarregar_logs()
                agora = time.monotonic()
                if pedido or agora - self._ultima_checagem > SEGUNDOS_CHECAGEM_PERIODICA:
                    self._ultima_checagem = agora
                    self._checar_rede()
                self.repo.recuperar_orfas(SEGUNDOS_ORFA)
            except Exception:
                logger.exception("Falha no batimento do worker")
            time.sleep(SEGUNDOS_BATIMENTO)

    def _descarregar_logs(self) -> None:
        with self._trava:
            handlers = list(self.handlers.values())
        for h in handlers:
            try:
                h.descarregar()
            except Exception:
                logger.warning("Falha ao gravar log no banco; tento de novo.")

    def _checar_rede(self) -> None:
        ambientes = ["hml", "prd"] if self.config.permitir_producao else ["hml"]
        checagens = []
        for amb in ambientes:
            for c in verificar(self.config, amb):
                if c.nome.startswith("IPOP") or amb == ambientes[0]:
                    checagens.append(c)
        self.repo.salvar_checagem(self.nome, como_dicts(checagens))


def main() -> int:
    configurar_log()
    cfg = config_mod.carregar()
    faltando = cfg.faltando_infra()
    if faltando:
        logger.error("Faltam variáveis de ambiente: %s", ", ".join(faltando))
        return 2
    repo = Repositorio(cfg, tamanho_pool=6)
    armazenamento = Armazenamento(cfg)
    for tentativa in range(30):  # espera Postgres e MinIO subirem
        try:
            repo.garantir_schema()
            armazenamento.garantir_bucket()
            break
        except Exception as erro:
            logger.warning("Postgres/bucket ainda indisponível (%s). Tentativa %d/30.", erro, tentativa + 1)
            time.sleep(2)
    else:
        return 3
    try:
        Worker(cfg, repo, armazenamento).rodar()
    finally:
        repo.fechar()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
