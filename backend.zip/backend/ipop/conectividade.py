"""Testa se o servidor alcança o IPOP e o SQL Server antes de começar."""
from __future__ import annotations

import socket
import time
from dataclasses import asdict, dataclass
from urllib.parse import urlparse

from ipop.config import Config


@dataclass
class Checagem:
    nome: str
    destino: str
    ok: bool
    detalhe: str
    ms: int | None = None


def _tcp(nome: str, host: str, porta: int, timeout: float = 5.0) -> Checagem:
    destino = f"{host}:{porta}"
    if not host:
        return Checagem(nome, destino, False, "Não configurado no .env.")
    try:
        enderecos = sorted({info[4][0] for info in socket.getaddrinfo(host, porta, type=socket.SOCK_STREAM)})
    except socket.gaierror as erro:
        return Checagem(nome, destino, False, f"DNS não resolveu o nome ({erro}). Use o nome completo (FQDN) ou o IP.")
    inicio = time.perf_counter()
    try:
        with socket.create_connection((host, porta), timeout=timeout):
            pass
    except OSError as erro:
        return Checagem(nome, destino, False, f"Resolveu para {', '.join(enderecos)}, mas a porta não respondeu ({erro}).")
    return Checagem(nome, destino, True, f"Conectou ({', '.join(enderecos)}).", int((time.perf_counter() - inicio) * 1000))


def _driver_odbc(config: Config) -> Checagem:
    try:
        import pyodbc
    except ImportError as erro:
        return Checagem("Driver ODBC", config.sql_driver, False, f"pyodbc/unixODBC indisponível: {erro}")
    drivers = pyodbc.drivers()
    if config.sql_driver in drivers:
        return Checagem("Driver ODBC", config.sql_driver, True, "Instalado.")
    return Checagem("Driver ODBC", config.sql_driver, False, f"Não instalado. Encontrados: {drivers or 'nenhum'}")


def _login_sql(config: Config) -> Checagem:
    from ipop.services.enriquecedor_sql import EnriquecedorSQL
    enriquecedor = EnriquecedorSQL(config)
    try:
        enriquecedor.conectar().cursor().execute("SELECT 1").fetchone()
        return Checagem("Login SQL", f"{config.sql_banco} como {config.sql_usuario}", True, "Consulta de teste OK.")
    except Exception as erro:
        return Checagem("Login SQL", f"{config.sql_banco} como {config.sql_usuario}", False, str(erro)[:400])
    finally:
        enriquecedor.fechar()


def verificar(config: Config, ambiente: str, *, testar_login_sql: bool = True) -> list[Checagem]:
    url = urlparse(config.url_login(ambiente))
    checagens = [
        _tcp(f"IPOP ({ambiente})", url.hostname or "", url.port or (443 if url.scheme == "https" else 80)),
        _tcp("SQL Server", config.sql_servidor.split(",")[0].split("\\")[0], config.sql_porta),
        _driver_odbc(config),
    ]
    if testar_login_sql and checagens[1].ok and checagens[2].ok:
        checagens.append(_login_sql(config))
    return checagens


def como_dicts(checagens: list[Checagem]) -> list[dict]:
    return [asdict(c) for c in checagens]
