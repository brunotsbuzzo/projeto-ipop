"""Bucket S3 (MinIO hoje; qualquer S3 compatível amanhã, só trocando o .env).

Organização:
    execucoes/<id>/pedido.xlsx
    execucoes/<id>/regras_enriquecidas.json
    execucoes/<id>/erros/regra_NNN.png
    execucoes/<id>/trace.zip
    execucoes/<id>/execucao.log
    config/tbl_dim/TblDePara.xlsx       (opcional: substitui a tabela que vem na imagem)
    config/tbl_dim/TblRegraModelo.xlsx  (opcional)
"""
from __future__ import annotations

import logging
import mimetypes
from pathlib import Path
from typing import Iterator

import boto3
from botocore.config import Config as BotoConfig
from botocore.exceptions import ClientError

from ipop.config import Config

logger = logging.getLogger(__name__)

TABELAS_AUXILIARES = ("TblDePara.xlsx", "TblRegraModelo.xlsx")
mimetypes.add_type("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ".xlsx")


def prefixo_execucao(execucao_id: str) -> str:
    return f"execucoes/{execucao_id}/"


class Armazenamento:
    def __init__(self, config: Config, cliente=None):
        self.bucket = config.s3_bucket
        self.s3 = cliente or boto3.client(
            "s3",
            endpoint_url=config.s3_endpoint,
            aws_access_key_id=config.s3_access_key,
            aws_secret_access_key=config.s3_secret_key,
            region_name=config.s3_regiao,
            config=BotoConfig(
                signature_version="s3v4",
                s3={"addressing_style": "path"},  # MinIO usa http://host:9000/bucket/chave
                retries={"max_attempts": 5, "mode": "standard"},
                connect_timeout=5,
                read_timeout=60,
            ),
        )

    def garantir_bucket(self) -> None:
        try:
            self.s3.head_bucket(Bucket=self.bucket)
        except ClientError as erro:
            if erro.response.get("Error", {}).get("Code") not in {"404", "NoSuchBucket", "NotFound"}:
                raise
            logger.info("Criando o bucket %s", self.bucket)
            self.s3.create_bucket(Bucket=self.bucket)

    def enviar(self, caminho: Path, chave: str) -> None:
        tipo = mimetypes.guess_type(caminho.name)[0] or "application/octet-stream"
        self.s3.upload_file(str(caminho), self.bucket, chave, ExtraArgs={"ContentType": tipo})

    def baixar(self, chave: str, destino: Path) -> None:
        destino.parent.mkdir(parents=True, exist_ok=True)
        self.s3.download_file(self.bucket, chave, str(destino))

    def baixar_se_existir(self, chave: str, destino: Path) -> bool:
        try:
            self.baixar(chave, destino)
            return True
        except ClientError as erro:
            if erro.response.get("Error", {}).get("Code") in {"404", "NoSuchKey", "NotFound"}:
                return False
            raise

    def abrir(self, chave: str) -> tuple[Iterator[bytes], str, int]:
        """(pedaços do arquivo, content-type, tamanho). Levanta FileNotFoundError se não existir."""
        try:
            resposta = self.s3.get_object(Bucket=self.bucket, Key=chave)
        except ClientError as erro:
            if erro.response.get("Error", {}).get("Code") in {"404", "NoSuchKey", "NotFound"}:
                raise FileNotFoundError(chave) from erro
            raise
        corpo = resposta["Body"]
        return (corpo.iter_chunks(chunk_size=256 * 1024), resposta.get("ContentType") or "application/octet-stream",
                int(resposta.get("ContentLength") or 0))

    def listar(self, prefixo: str) -> list[str]:
        """Chaves sob o prefixo, relativas a ele."""
        chaves: list[str] = []
        for pagina in self.s3.get_paginator("list_objects_v2").paginate(Bucket=self.bucket, Prefix=prefixo):
            chaves.extend(obj["Key"][len(prefixo):] for obj in pagina.get("Contents", []))
        return sorted(chaves)

    def copiar(self, origem: str, destino: str) -> None:
        self.s3.copy_object(Bucket=self.bucket, Key=destino, CopySource={"Bucket": self.bucket, "Key": origem})

    def apagar(self, chave: str) -> None:
        self.s3.delete_object(Bucket=self.bucket, Key=chave)

    def baixar_tabelas_auxiliares(self, destino: Path) -> bool:
        """Baixa config/tbl_dim/ do bucket. False se não houver versão no bucket."""
        baixadas = [self.baixar_se_existir(f"config/tbl_dim/{nome}", destino / nome) for nome in TABELAS_AUXILIARES]
        if all(baixadas):
            return True
        if any(baixadas):
            logger.warning("Só parte das tabelas auxiliares está no bucket; usando as que vêm com o robô.")
        return False

    def saude(self) -> bool:
        self.s3.head_bucket(Bucket=self.bucket)
        return True
