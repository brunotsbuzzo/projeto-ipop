"""Andamento gravado no Postgres e arquivos no bucket (usado pelo worker)."""
from __future__ import annotations

import logging
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ipop.infra.armazenamento import Armazenamento, prefixo_execucao
from ipop.infra.db import Repositorio
from ipop.progresso import Progresso


class ProgressoBanco(Progresso):
    def __init__(self, repo: Repositorio, armazenamento: Armazenamento, execucao_id: str, *,
                 inicio: int = 1, registrar_eventos: bool = True):
        super().__init__()
        self.repo = repo
        self.armazenamento = armazenamento
        self.id = execucao_id
        self.inicio = inicio
        self.registrar_eventos = registrar_eventos

    def fase(self, fase: str, mensagem: str = "") -> None:
        self.repo.atualizar_execucao(self.id, fase=fase, mensagem=mensagem)

    def registrar(self, **campos: Any) -> None:
        self.repo.atualizar_execucao(self.id, **campos)

    def definir_regras(self, regras: list[dict[str, Any]]) -> None:
        self.regras[:] = regras
        self.repo.definir_regras(self.id, regras, preservar_ate=self.inicio)

    def atualizar_regra(self, indice: int, **campos: Any) -> None:
        self.regras[indice].update(campos)
        self.repo.atualizar_regra(self.id, self.regras[indice]["n"], **campos)

    def guardar_arquivo(self, caminho_local: Path, nome: str) -> str:
        self.armazenamento.enviar(caminho_local, prefixo_execucao(self.id) + nome)
        return nome

    def cancelamento_pedido(self) -> bool:
        return self.repo.cancelamento_pedido(self.id)

    def evento(self, tipo: str, titulo: str, detalhe: str = "") -> None:
        if self.registrar_eventos:
            self.repo.inserir_evento(self.id, tipo, titulo, detalhe, "Robô IPOP")


class HandlerLogBanco(logging.Handler):
    """Junta os registros de log da execução; o worker grava em lote a cada poucos segundos."""

    def __init__(self, repo: Repositorio, execucao_id: str, nivel: int = logging.INFO, thread_id: int | None = None):
        super().__init__(nivel)
        if thread_id is not None:  # validação e cadastro rodam em threads diferentes
            self.addFilter(lambda registro: registro.thread == thread_id)
        self.repo = repo
        self.id = execucao_id
        self._pendentes: list[tuple] = []
        self._trava = threading.Lock()

    def emit(self, registro: logging.LogRecord) -> None:
        try:
            mensagem = registro.getMessage()
            if registro.exc_info:
                mensagem += "\n" + logging.Formatter().formatException(registro.exc_info)
            item = (datetime.fromtimestamp(registro.created, timezone.utc), registro.levelname,
                    registro.name, mensagem[:20_000])
            with self._trava:
                self._pendentes.append(item)
        except Exception:  # pragma: no cover
            self.handleError(registro)

    def descarregar(self) -> None:
        with self._trava:
            pendentes, self._pendentes = self._pendentes, []
        if not pendentes:
            return
        try:
            self.repo.gravar_logs(self.id, pendentes)
        except Exception:
            with self._trava:  # tenta de novo no próximo ciclo
                self._pendentes[:0] = pendentes
            raise
