"""Postgres: fila de execuções, andamento por regra, log e workers.

A fila é a própria tabela `execucoes`: o worker reserva a mais antiga com
FOR UPDATE SKIP LOCKED. Não há broker; o estado e a fila ficam no mesmo lugar,
então uma execução nunca "volta para a fila" sozinha e cadastra regras em dobro.
"""
from __future__ import annotations

import json
import logging
from contextlib import contextmanager
from typing import Any, Iterator

import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb
from psycopg_pool import ConnectionPool

from ipop.config import Config
from ipop.progresso import FASES_ATIVAS, FASES_FINAIS

logger = logging.getLogger(__name__)

SCHEMA_SQL = """
CREATE SCHEMA IF NOT EXISTS {s};

CREATE TABLE IF NOT EXISTS {s}.execucoes (
    id                text PRIMARY KEY,
    tipo              text NOT NULL DEFAULT 'cadastro' CHECK (tipo IN ('validacao', 'cadastro')),
    criada_em         timestamptz NOT NULL DEFAULT now(),
    usuario           text NOT NULL,
    solicitante       text NOT NULL DEFAULT '',
    titulo            text NOT NULL DEFAULT '',
    lote_id           text NOT NULL DEFAULT '',
    categoria         text NOT NULL DEFAULT '',
    validacao_id      text REFERENCES {s}.execucoes (id) ON DELETE SET NULL,
    nome_original     text NOT NULL,
    tamanho_arquivo   bigint NOT NULL DEFAULT 0,
    objeto_pedido     text NOT NULL,
    ambiente          text NOT NULL CHECK (ambiente IN ('hml', 'prd')),
    so_dados          boolean NOT NULL,
    inicio            integer NOT NULL DEFAULT 1 CHECK (inicio >= 1),
    continuar_em_erro boolean NOT NULL DEFAULT false,
    origem            text REFERENCES {s}.execucoes (id) ON DELETE SET NULL,
    fase              text NOT NULL DEFAULT 'na_fila',
    mensagem          text NOT NULL DEFAULT '',
    worker            text,
    iniciou_em        timestamptz,
    terminou_em       timestamptz,
    heartbeat         timestamptz,
    cancelar          boolean NOT NULL DEFAULT false,
    conectividade     jsonb,
    avisos            jsonb,
    erros_validacao   jsonb,
    problemas         jsonb,
    atualizada_em     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS execucoes_na_fila ON {s}.execucoes (tipo, criada_em) WHERE fase = 'na_fila';
CREATE INDEX IF NOT EXISTS execucoes_criada_em ON {s}.execucoes (criada_em DESC);

CREATE TABLE IF NOT EXISTS {s}.regras (
    execucao_id text NOT NULL REFERENCES {s}.execucoes (id) ON DELETE CASCADE,
    n           integer NOT NULL,
    nome        text NOT NULL,
    aba         text,
    linha       integer,
    modulo      text,
    tipo        text,
    percentual  double precision,
    vigencia    text,
    modelo      bigint,
    variaveis   integer,
    status      text NOT NULL DEFAULT 'pendente',
    detalhe     text NOT NULL DEFAULT '',
    print       text,
    inicio      timestamptz,
    fim         timestamptz,
    dados       jsonb,
    PRIMARY KEY (execucao_id, n)
);

CREATE TABLE IF NOT EXISTS {s}.eventos (
    id          bigserial PRIMARY KEY,
    execucao_id text NOT NULL REFERENCES {s}.execucoes (id) ON DELETE CASCADE,
    criado_em   timestamptz NOT NULL DEFAULT now(),
    tipo        text NOT NULL,
    titulo      text NOT NULL,
    detalhe     text NOT NULL DEFAULT '',
    responsavel text NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS eventos_por_execucao ON {s}.eventos (execucao_id, id);

CREATE TABLE IF NOT EXISTS {s}.logs (
    id          bigserial PRIMARY KEY,
    execucao_id text NOT NULL REFERENCES {s}.execucoes (id) ON DELETE CASCADE,
    criado_em   timestamptz NOT NULL,
    nivel       text NOT NULL,
    origem      text NOT NULL,
    mensagem    text NOT NULL
);
CREATE INDEX IF NOT EXISTS logs_por_execucao ON {s}.logs (execucao_id, id);

CREATE TABLE IF NOT EXISTS {s}.workers (
    nome               text PRIMARY KEY,
    iniciado_em        timestamptz NOT NULL DEFAULT now(),
    visto_em           timestamptz NOT NULL DEFAULT now(),
    executando         text,
    conectividade      jsonb,
    checado_em         timestamptz,
    checagem_pedida_em timestamptz
);
"""

CAMPOS_REGRA = ("nome", "aba", "linha", "modulo", "tipo", "percentual", "vigencia", "modelo", "variaveis",
                "status", "detalhe", "print", "inicio", "fim", "dados")
CAMPOS_EXECUCAO_LIVRES = {"conectividade", "avisos", "erros_validacao", "problemas"}
STATUS_FEITOS = ("confirmada", "salva_sem_confirmacao")
SEGUNDOS_ONLINE = 30


class Repositorio:
    def __init__(self, config: Config, *, tamanho_pool: int = 5):
        self.config = config
        self.s = config.db_schema  # validado em Config: só [a-z0-9_]
        self.canal_fila = f"{self.s}_fila"
        self.chave_trava = f"{self.s}:robo"
        self.pool = ConnectionPool(
            config.database_url, min_size=1, max_size=tamanho_pool, open=True, name="robo-ipop",
            kwargs={"autocommit": True, "row_factory": dict_row},
        )

    def fechar(self) -> None:
        self.pool.close()

    @contextmanager
    def conexao(self) -> Iterator[psycopg.Connection]:
        with self.pool.connection() as conexao:
            yield conexao

    def conexao_dedicada(self) -> psycopg.Connection:
        """Conexão fora do pool, para LISTEN e para a trava do robô."""
        return psycopg.connect(self.config.database_url, autocommit=True, row_factory=dict_row)

    def _q(self, sql: str) -> str:
        return sql.format(s=self.s)

    # ---------- schema ----------
    def garantir_schema(self) -> None:
        with self.conexao() as c, c.transaction():
            c.execute("SELECT pg_advisory_xact_lock(hashtext(%s))", (f"{self.s}:schema",))
            c.execute(self._q(SCHEMA_SQL))

    # ---------- criação e fila ----------
    def criar_execucao(self, *, id: str, tipo: str, usuario: str, nome_original: str, objeto_pedido: str,
                       ambiente: str, so_dados: bool, tamanho_arquivo: int = 0, inicio: int = 1,
                       continuar_em_erro: bool = False, solicitante: str = "", titulo: str = "", lote_id: str = "",
                       categoria: str = "", validacao_id: str | None = None, origem: str | None = None) -> None:
        with self.conexao() as c, c.transaction():
            c.execute(self._q("""
                INSERT INTO {s}.execucoes (id, tipo, usuario, solicitante, titulo, lote_id, categoria, validacao_id,
                                           nome_original, tamanho_arquivo, objeto_pedido, ambiente, so_dados,
                                           inicio, continuar_em_erro, origem, mensagem)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'Aguardando o robô...')
            """), (id, tipo, usuario, solicitante, titulo, lote_id, categoria, validacao_id, nome_original,
                   tamanho_arquivo, objeto_pedido, ambiente, so_dados, inicio, continuar_em_erro, origem))
            if tipo == "cadastro":
                c.execute(self._q("""
                    INSERT INTO {s}.eventos (execucao_id, tipo, titulo, detalhe, responsavel)
                    VALUES (%s, 'recebida', 'Recebida', 'Solicitação registrada e colocada na fila do robô.', %s)
                """), (id, solicitante or usuario))
            c.execute("SELECT pg_notify(%s, %s)", (self.canal_fila, tipo))

    def retomar(self, id: str, inicio: int, usuario: str) -> bool:
        """Volta uma solicitação parada para a fila, a partir da regra `inicio`."""
        with self.conexao() as c, c.transaction():
            ok = c.execute(self._q("""
                UPDATE {s}.execucoes
                   SET fase = 'na_fila', inicio = %s, cancelar = false, worker = NULL, terminou_em = NULL,
                       heartbeat = NULL, mensagem = 'Aguardando o robô...', atualizada_em = now()
                 WHERE id = %s AND tipo = 'cadastro' AND fase IN ('erro', 'interrompida', 'cancelada')
             RETURNING id
            """), (inicio, id)).fetchone()
            if not ok:
                return False
            c.execute(self._q("""
                INSERT INTO {s}.eventos (execucao_id, tipo, titulo, detalhe, responsavel)
                VALUES (%s, 'retomada', %s, 'A solicitação voltou para a fila do robô.', %s)
            """), (id, f"Retomada da regra {inicio}", usuario))
            c.execute("SELECT pg_notify(%s, 'cadastro')", (self.canal_fila,))
        return True

    def posicao_na_fila(self, id: str) -> int:
        with self.conexao() as c:
            linha = c.execute(self._q("""
                SELECT count(*) AS n FROM {s}.execucoes
                WHERE fase = 'na_fila' AND criada_em <= (SELECT criada_em FROM {s}.execucoes WHERE id = %s)
            """), (id,)).fetchone()
        return int(linha["n"])

    def tentar_trava_do_robo(self, conexao: psycopg.Connection) -> bool:
        """Só um robô no IPOP por vez, mesmo com vários workers. Cai junto com a conexão."""
        return bool(conexao.execute("SELECT pg_try_advisory_lock(hashtext(%s)) AS ok",
                                    (self.chave_trava,)).fetchone()["ok"])

    def soltar_trava_do_robo(self, conexao: psycopg.Connection) -> None:
        conexao.execute("SELECT pg_advisory_unlock(hashtext(%s))", (self.chave_trava,))

    def reservar_proxima(self, worker: str, tipo: str = "cadastro") -> dict | None:
        with self.conexao() as c:
            return c.execute(self._q("""
                UPDATE {s}.execucoes
                   SET fase = 'reservada', worker = %s, iniciou_em = now(), heartbeat = now(),
                       mensagem = 'Preparando...', atualizada_em = now()
                 WHERE id = (SELECT id FROM {s}.execucoes
                              WHERE fase = 'na_fila' AND NOT cancelar AND tipo = %s
                              ORDER BY criada_em, id
                              FOR UPDATE SKIP LOCKED
                              LIMIT 1)
             RETURNING *
            """), (worker, tipo)).fetchone()

    def recuperar_orfas(self, limite_s: int = 120) -> list[str]:
        """Execuções cujo worker sumiu (sem batimento) viram 'interrompida'.

        Não voltam para a fila: a regra que estava no meio pode ter sido salva no IPOP,
        e repetir sozinha cadastraria em dobro. A pessoa confere e clica em Retomar.
        """
        with self.conexao() as c, c.transaction():
            orfas = [l["id"] for l in c.execute(self._q("""
                UPDATE {s}.execucoes
                   SET fase = 'interrompida', terminou_em = now(), atualizada_em = now(),
                       mensagem = 'O worker parou de responder no meio da execução. '
                                  || 'Confira a regra marcada "verificar" no IPOP e retome.'
                 WHERE fase = ANY(%s) AND (heartbeat IS NULL OR heartbeat < now() - make_interval(secs => %s))
             RETURNING id
            """), (list(FASES_ATIVAS), limite_s)).fetchall()]
            if orfas:
                c.execute(self._q("""
                    UPDATE {s}.regras SET status = 'verificar',
                           detalhe = 'O worker caiu durante esta regra. Ela pode ter sido salva: confira no IPOP.'
                     WHERE execucao_id = ANY(%s) AND status = 'executando'
                """), (orfas,))
                c.execute(self._q("""
                    UPDATE {s}.regras SET status = 'não executada'
                     WHERE execucao_id = ANY(%s) AND status = 'pendente'
                """), (orfas,))
                logger.warning("Execuções órfãs marcadas como interrompidas: %s", orfas)
        return orfas

    # ---------- andamento (worker) ----------
    def atualizar_execucao(self, id: str, **campos: Any) -> None:
        sets, valores = ["atualizada_em = now()"], []
        for nome, valor in campos.items():
            if nome == "fase":
                sets.append("fase = %s")
                valores.append(valor)
                if valor in FASES_FINAIS:
                    sets.append("terminou_em = now()")
            elif nome == "mensagem":
                sets.append("mensagem = %s")
                valores.append(valor)
            elif nome in CAMPOS_EXECUCAO_LIVRES:
                sets.append(f"{nome} = %s")
                valores.append(Jsonb(valor))
            else:
                raise ValueError(f"Campo de execução desconhecido: {nome}")
        with self.conexao() as c:
            c.execute(self._q(f"UPDATE {{s}}.execucoes SET {', '.join(sets)} WHERE id = %s"), (*valores, id))

    def definir_regras(self, id: str, regras: list[dict], *, preservar_ate: int = 1) -> None:
        """Grava as regras da execução. Numa retomada (preservar_ate > 1), as regras antes dela
        que já estavam cadastradas mantêm a situação."""
        with self.conexao() as c, c.transaction():
            anteriores = {
                l["n"]: l for l in c.execute(self._q(
                    "SELECT n, status, detalhe, print, inicio, fim FROM {s}.regras WHERE execucao_id = %s"), (id,)).fetchall()
            }
            c.execute(self._q("DELETE FROM {s}.regras WHERE execucao_id = %s"), (id,))
            linhas = []
            for r in regras:
                r = {"status": "pendente", "detalhe": "", **{k: v for k, v in r.items() if v is not None}}
                antiga = anteriores.get(r["n"])
                if antiga and r["n"] < preservar_ate and antiga["status"] in STATUS_FEITOS:
                    r.update({k: antiga[k] for k in ("status", "detalhe", "print", "inicio", "fim")})
                valores = [Jsonb(r.get(campo)) if campo == "dados" and r.get(campo) is not None else r.get(campo)
                           for campo in CAMPOS_REGRA]
                linhas.append((id, r["n"], *valores))
            with c.cursor() as cur:
                cur.executemany(self._q(f"""
                    INSERT INTO {{s}}.regras (execucao_id, n, {', '.join(CAMPOS_REGRA)})
                    VALUES (%s, %s, {', '.join(['%s'] * len(CAMPOS_REGRA))})
                """), linhas)

    def atualizar_regra(self, id: str, n: int, **campos: Any) -> None:
        campos = {k: v for k, v in campos.items() if k in CAMPOS_REGRA}
        if not campos:
            return
        if campos.get("status") == "pulada":
            # Não rebaixa uma regra que já foi cadastrada numa execução anterior.
            with self.conexao() as c:
                atual = c.execute(self._q("SELECT status FROM {s}.regras WHERE execucao_id = %s AND n = %s"),
                                  (id, n)).fetchone()
            if atual and atual["status"] in STATUS_FEITOS:
                return
        sets = ", ".join(f"{k} = %s" for k in campos)
        valores = [Jsonb(v) if k == "dados" and v is not None else v for k, v in campos.items()]
        with self.conexao() as c:
            c.execute(self._q(f"UPDATE {{s}}.regras SET {sets} WHERE execucao_id = %s AND n = %s"),
                      (*valores, id, n))

    def inserir_evento(self, id: str, tipo: str, titulo: str, detalhe: str = "", responsavel: str = "") -> None:
        with self.conexao() as c:
            c.execute(self._q("""
                INSERT INTO {s}.eventos (execucao_id, tipo, titulo, detalhe, responsavel) VALUES (%s, %s, %s, %s, %s)
            """), (id, tipo, titulo, detalhe, responsavel))

    def listar_eventos(self, id: str) -> list[dict]:
        with self.conexao() as c:
            return c.execute(self._q("""
                SELECT criado_em, tipo, titulo, detalhe, responsavel FROM {s}.eventos
                 WHERE execucao_id = %s ORDER BY id DESC
            """), (id,)).fetchall()

    def cancelamento_pedido(self, id: str) -> bool:
        with self.conexao() as c:
            linha = c.execute(self._q("SELECT cancelar FROM {s}.execucoes WHERE id = %s"), (id,)).fetchone()
        return bool(linha and linha["cancelar"])

    def gravar_logs(self, id: str, registros: list[tuple]) -> None:
        if not registros:
            return
        with self.conexao() as c, c.cursor() as cur:
            cur.executemany(self._q("""
                INSERT INTO {s}.logs (execucao_id, criado_em, nivel, origem, mensagem) VALUES (%s, %s, %s, %s, %s)
            """), [(id, *r) for r in registros])

    # ---------- workers ----------
    def registrar_worker(self, nome: str) -> None:
        with self.conexao() as c:
            c.execute(self._q("""
                INSERT INTO {s}.workers (nome) VALUES (%s)
                ON CONFLICT (nome) DO UPDATE SET iniciado_em = now(), visto_em = now(), executando = NULL
            """), (nome,))

    def batimento(self, nome: str, executando: str | None, ativas: list[str] | None = None) -> bool:
        """Atualiza o 'estou vivo'. Devolve True se alguém pediu um teste de conexão."""
        with self.conexao() as c, c.transaction():
            linha = c.execute(self._q("""
                UPDATE {s}.workers SET visto_em = now(), executando = %s WHERE nome = %s
             RETURNING checagem_pedida_em IS NOT NULL
                       AND (checado_em IS NULL OR checagem_pedida_em > checado_em) AS checar
            """), (executando, nome)).fetchone()
            ids = [i for i in (ativas or ([executando] if executando else [])) if i]
            if ids:
                c.execute(self._q("UPDATE {s}.execucoes SET heartbeat = now() WHERE id = ANY(%s)"), (ids,))
        return bool(linha and linha["checar"])

    def salvar_checagem(self, nome: str, checagens: list[dict]) -> None:
        with self.conexao() as c:
            c.execute(self._q("UPDATE {s}.workers SET conectividade = %s, checado_em = now() WHERE nome = %s"),
                      (Jsonb(checagens), nome))

    def worker_saiu(self, nome: str) -> None:
        with self.conexao() as c:
            c.execute(self._q("UPDATE {s}.workers SET executando = NULL, visto_em = now() - interval '1 hour' "
                              "WHERE nome = %s"), (nome,))

    # ---------- leitura (API) ----------
    def listar_execucoes(self, limite: int = 50, *, tipo: str = "cadastro", busca: str = "") -> list[dict]:
        filtro_busca = ""
        parametros: list[Any] = [tipo]
        if busca.strip():
            filtro_busca = "AND (e.lote_id ILIKE %s OR e.titulo ILIKE %s OR e.solicitante ILIKE %s)"
            termo = f"%{busca.strip()}%"
            parametros += [termo, termo, termo]
        parametros.append(limite)
        with self.conexao() as c:
            return c.execute(self._q(f"""
                SELECT e.*, coalesce(r.total, 0) AS total_regras, coalesce(r.contagem, '{{{{}}}}'::jsonb) AS contagem,
                       r.parada
                  FROM {{s}}.execucoes e
                  LEFT JOIN LATERAL (
                        SELECT sum(n)::int AS total, jsonb_object_agg(status, n) AS contagem,
                               (SELECT min(x.n) FROM {{s}}.regras x
                                 WHERE x.execucao_id = e.id AND x.status IN ('erro', 'verificar')) AS parada
                          FROM (SELECT status, count(*) AS n FROM {{s}}.regras WHERE execucao_id = e.id GROUP BY status) y
                  ) r ON true
                 WHERE e.tipo = %s {filtro_busca}
                 ORDER BY e.criada_em DESC, e.id DESC
                 LIMIT %s
            """), parametros).fetchall()

    def obter_execucao(self, id: str) -> dict | None:
        with self.conexao() as c:
            execucao = c.execute(self._q("SELECT * FROM {s}.execucoes WHERE id = %s"), (id,)).fetchone()
            if execucao is None:
                return None
            execucao["regras"] = c.execute(
                self._q("SELECT * FROM {s}.regras WHERE execucao_id = %s ORDER BY n"), (id,)).fetchall()
        return execucao

    def ler_logs(self, id: str, linhas: int = 400) -> list[dict]:
        with self.conexao() as c:
            return list(reversed(c.execute(self._q("""
                SELECT criado_em, nivel, origem, mensagem FROM {s}.logs WHERE execucao_id = %s
                 ORDER BY id DESC LIMIT %s
            """), (id, linhas)).fetchall()))

    def pedir_cancelamento(self, id: str) -> str | None:
        """Devolve 'cancelada' (estava na fila), 'pedido' (está rodando) ou None."""
        with self.conexao() as c:
            if c.execute(self._q("""
                UPDATE {s}.execucoes SET fase = 'cancelada', cancelar = true, terminou_em = now(),
                       mensagem = 'Cancelada antes de começar.', atualizada_em = now()
                 WHERE id = %s AND fase = 'na_fila' RETURNING id
            """), (id,)).fetchone():
                return "cancelada"
            if c.execute(self._q("""
                UPDATE {s}.execucoes SET cancelar = true, atualizada_em = now(),
                       mensagem = mensagem || ' (cancelamento pedido: para depois da regra atual)'
                 WHERE id = %s AND fase = ANY(%s) AND NOT cancelar RETURNING id
            """), (id, list(FASES_ATIVAS))).fetchone():
                return "pedido"
        return None

    def listar_workers(self) -> list[dict]:
        with self.conexao() as c:
            return c.execute(self._q(f"""
                SELECT *, visto_em > now() - interval '{SEGUNDOS_ONLINE} seconds' AS online
                  FROM {{s}}.workers ORDER BY visto_em DESC
            """)).fetchall()

    def pedir_checagem(self) -> None:
        with self.conexao() as c:
            c.execute(self._q("UPDATE {s}.workers SET checagem_pedida_em = now()"))

    def saude(self) -> bool:
        with self.conexao() as c:
            return c.execute("SELECT 1 AS ok").fetchone()["ok"] == 1


def para_json(valor: Any) -> Any:
    """Converte datas e afins para algo que o JSON da API aceita."""
    return json.loads(json.dumps(valor, default=str))
