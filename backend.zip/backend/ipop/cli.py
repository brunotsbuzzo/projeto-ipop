"""Linha de comando.

Uso direto (cria uma pasta de execução nova):
    python -m ipop.cli --pedido "ID3422 - Lote.xlsx" --so-dados
    python -m ipop.cli --pedido "ID3422 - Lote.xlsx" --ambiente hml
    python -m ipop.cli --pedido "ID3422 - Lote.xlsx" --ambiente hml --inicio 15

Pasta já preparada com parametros.json:
    python -m ipop.cli --execucao-dir dados/execucoes/20261105-141500-ab12
    python -m ipop.cli --checar-rede --ambiente hml

No docker-compose quem roda o robô é o worker (python -m ipop.worker); a linha de
comando serve para depurar uma planilha localmente, sem Postgres nem bucket.
"""
from __future__ import annotations

import argparse
import logging
import secrets
import shutil
import sys
from datetime import datetime
from pathlib import Path

from ipop import config as config_mod
from ipop.progresso import FUSO, gravar_json, ler_json


def configurar_log(arquivo: Path | None = None) -> None:
    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stdout)]
    if arquivo is not None:
        handlers.append(logging.FileHandler(arquivo, encoding="utf-8"))
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=handlers,
        force=True,
    )


def nova_execucao(cfg: config_mod.Config, arquivo_pedido: Path, parametros: dict) -> Path:
    carimbo = datetime.now(FUSO).strftime("%Y%m%d-%H%M%S")
    pasta = cfg.execucoes_dir / f"{carimbo}-{secrets.token_hex(2)}"
    pasta.mkdir(parents=True)
    destino = pasta / ("pedido" + (arquivo_pedido.suffix.lower() or ".xlsx"))
    shutil.copyfile(arquivo_pedido, destino)
    gravar_json(pasta / "parametros.json", {
        **parametros,
        "pedido": destino.name,
        "nome_original": arquivo_pedido.name,
    })
    return pasta


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m ipop.cli", description="Robô de cadastro de regras no IPOP")
    parser.add_argument("--execucao-dir", type=Path, help="pasta de execução já preparada (usado pela API)")
    parser.add_argument("--pedido", type=Path, help="planilha Excel do pedido")
    parser.add_argument("--ambiente", choices=config_mod.AMBIENTES, default="hml")
    parser.add_argument("--so-dados", action="store_true", help="só lê, enriquece e valida; não abre o navegador")
    parser.add_argument("--inicio", type=int, default=1, help="começar a partir da regra N (1 = primeira)")
    parser.add_argument("--continuar-em-erro", action="store_true", help="não parar na primeira regra com erro")
    parser.add_argument("--checar-rede", action="store_true", help="só testa o acesso ao IPOP e ao SQL")
    args = parser.parse_args(argv)
    cfg = config_mod.carregar()

    if args.checar_rede:
        configurar_log()
        from ipop.conectividade import verificar
        checagens = verificar(cfg, args.ambiente)
        for c in checagens:
            print(f"[{'OK ' if c.ok else 'ERRO'}] {c.nome:<14} {c.destino:<40} {c.detalhe}")
        return 0 if all(c.ok for c in checagens) else 3

    if args.execucao_dir:
        pasta = args.execucao_dir.resolve()
    elif args.pedido:
        if not args.pedido.exists():
            parser.error(f"Arquivo não encontrado: {args.pedido}")
        pasta = nova_execucao(cfg, args.pedido, {
            "ambiente": args.ambiente,
            "so_dados": args.so_dados,
            "inicio": args.inicio,
            "continuar_em_erro": args.continuar_em_erro,
            "solicitante": "linha de comando",
        })
    else:
        parser.error("Informe --pedido ou --execucao-dir.")

    configurar_log(pasta / "execucao.log")
    logging.getLogger("ipop").info("Pasta da execução: %s", pasta)

    from ipop.progresso import ProgressoArquivo, instalar_sinais
    from ipop.robo import executar
    instalar_sinais()
    parametros = ler_json(pasta / "parametros.json")
    codigo = executar(pasta, cfg, ProgressoArquivo(pasta, parametros), parametros)
    estado = ler_json(pasta / "status.json", {})
    print(f"\n>>> {estado.get('fase')}: {estado.get('mensagem')}")
    for erro in estado.get("erros_validacao", [])[:30]:
        print(f"    - {erro}")
    print(f">>> Detalhes em {pasta}")
    return codigo


if __name__ == "__main__":
    sys.exit(main())
