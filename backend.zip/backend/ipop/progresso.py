"""Andamento de uma execução.

`Progresso` é a interface que o robô usa. Há duas implementações:
- `ProgressoArquivo`: grava status.json numa pasta (linha de comando, sem banco).
- `ProgressoBanco` (ipop/infra/progresso_banco.py): grava no Postgres e no bucket (worker).
"""
from __future__ import annotations

import json
import os
import signal
import tempfile
import threading
from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

FUSO = ZoneInfo("America/Sao_Paulo")

FASES_ATIVAS = {"reservada", "verificando_rede", "lendo_planilha", "login", "cadastrando"}
FASES_FINAIS = {"concluida", "concluida_so_dados", "erro", "erro_validacao", "cancelada", "interrompida"}


def agora() -> str:
    return datetime.now(FUSO).isoformat(timespec="seconds")


def gravar_json(caminho: Path, dados: Any) -> None:
    """Grava de forma atômica: quem lê nunca vê o arquivo pela metade."""
    caminho.parent.mkdir(parents=True, exist_ok=True)
    fd, temporario = tempfile.mkstemp(dir=caminho.parent, prefix=".tmp-", suffix=".json")
    with os.fdopen(fd, "w", encoding="utf-8") as arquivo:
        json.dump(dados, arquivo, ensure_ascii=False, indent=2, default=str)
    os.replace(temporario, caminho)


def ler_json(caminho: Path, padrao: Any = None) -> Any:
    try:
        with open(caminho, encoding="utf-8") as arquivo:
            return json.load(arquivo)
    except (FileNotFoundError, json.JSONDecodeError):
        return padrao


# ---------- pedido de parada (SIGTERM / Ctrl+C) ----------
_parar = threading.Event()


def instalar_sinais() -> None:
    """SIGTERM/SIGINT não matam a regra no meio: o robô termina a regra atual e para."""
    def _ao_receber(signum, _frame):
        if _parar.is_set():  # segundo sinal: sai na hora
            raise SystemExit(130)
        _parar.set()

    signal.signal(signal.SIGTERM, _ao_receber)
    signal.signal(signal.SIGINT, _ao_receber)


def parada_solicitada() -> bool:
    return _parar.is_set()


# ---------- interface ----------
class Progresso(ABC):
    def __init__(self) -> None:
        self.regras: list[dict[str, Any]] = []

    @abstractmethod
    def fase(self, fase: str, mensagem: str = "") -> None: ...

    @abstractmethod
    def registrar(self, **campos: Any) -> None:
        """Guarda informações da execução: conectividade, avisos, erros_validacao."""

    @abstractmethod
    def definir_regras(self, regras: list[dict[str, Any]]) -> None: ...

    @abstractmethod
    def atualizar_regra(self, indice: int, **campos: Any) -> None: ...

    @abstractmethod
    def guardar_arquivo(self, caminho_local: Path, nome: str) -> str:
        """Publica um arquivo da execução (print, JSON, trace). Devolve o nome relativo."""

    def evento(self, tipo: str, titulo: str, detalhe: str = "") -> None:
        """Marco do andamento mostrado na linha do tempo da solicitação."""

    def cancelamento_pedido(self) -> bool:
        return False

    def deve_parar(self) -> tuple[str, str] | None:
        """(fase, mensagem) se for para parar antes da próxima regra."""
        if self.cancelamento_pedido():
            return "cancelada", "Cancelada pelo usuário."
        if parada_solicitada():
            return "interrompida", "O worker foi desligado. Retome a partir da próxima regra pendente."
        return None

    def marcar_restantes(self, status: str) -> None:
        for indice, regra in enumerate(self.regras):
            if regra.get("status") in {"pendente", "executando"}:
                self.atualizar_regra(indice, status=status)


class ProgressoArquivo(Progresso):
    def __init__(self, pasta: Path, parametros: dict[str, Any]):
        super().__init__()
        self.pasta = pasta
        self.caminho = pasta / "status.json"
        self.estado: dict[str, Any] = {"iniciou_em": agora(), "parametros": parametros, "regras": self.regras}

    def _salvar(self) -> None:
        self.estado["atualizado_em"] = agora()
        gravar_json(self.caminho, self.estado)

    def fase(self, fase: str, mensagem: str = "") -> None:
        self.estado.update(fase=fase, mensagem=mensagem)
        if fase in FASES_FINAIS:
            self.estado["terminou_em"] = agora()
        self._salvar()

    def registrar(self, **campos: Any) -> None:
        self.estado.update(campos)
        self._salvar()

    def definir_regras(self, regras: list[dict[str, Any]]) -> None:
        self.regras[:] = regras
        self._salvar()

    def atualizar_regra(self, indice: int, **campos: Any) -> None:
        self.regras[indice].update(campos)
        self._salvar()

    def guardar_arquivo(self, caminho_local: Path, nome: str) -> str:
        return nome  # o arquivo já está na pasta da execução

    def evento(self, tipo: str, titulo: str, detalhe: str = "") -> None:
        self.estado.setdefault("eventos", []).append({"tipo": tipo, "titulo": titulo, "detalhe": detalhe, "em": agora()})
        self._salvar()
