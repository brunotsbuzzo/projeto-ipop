"""Leitura da planilha de pedido (portado de services/leitor_pedido.py).

Mudanças em relação ao original:
- Só processa abas de regra (nome começa com "Módulo" ou é/parece Oferta),
  em vez de depender de uma lista de abas a ignorar.
- O módulo do IPOP é sempre "Subscrição" ou "Oferta", mesmo que a aba se
  chame "Módulo de Subscrição".
- Linhas totalmente vazias são puladas.
- Números inteiros vindos do Excel como float (10.0) viram "10".
"""
from __future__ import annotations

import logging
import re
import unicodedata
from datetime import datetime
from typing import Any

import pandas as pd

logger = logging.getLogger(__name__)

COLUNAS_FIXAS = [
    "Negócio",
    "Data inicial",
    "Data final",
    "Nome da ação",
    "Tipo de regra",
    "Fator",
    "Modelos de regras",
    "Descrição do modelo de regra",
]
COLUNAS_OFERTA_OBRIGATORIAS = {"nome agrupamento", "fator (%)", "data inicial", "data final"}
COLUNAS_OFERTA_BASE = {
    "Nome Agrupamento", "Nome da ação", "Fator (%)", "Fator", "Data Inicial", "Data inicial",
    "Data Final", "Data final", "Tipo de regra", "Modelos de regras", "Descrição do modelo de regra",
    "id_regra_modelo", "ID",
}
DATA_FINAL_PADRAO = "2070-12-31"


def sem_acento(texto: Any) -> str:
    texto = unicodedata.normalize("NFD", str(texto))
    return "".join(c for c in texto if unicodedata.category(c) != "Mn").strip().lower()


def vazio(valor: Any) -> bool:
    if valor is None:
        return True
    if isinstance(valor, str):
        return not valor.strip()
    try:
        return bool(pd.isna(valor))
    except (TypeError, ValueError):
        return False


def texto_celula(valor: Any) -> str:
    """Texto de uma célula sem o '.0' que o pandas põe em colunas numéricas."""
    if isinstance(valor, float) and valor.is_integer():
        return str(int(valor))
    return str(valor).strip()


def normalizar_data_iso(valor: Any, padrao: str) -> str:
    """Converte a data da planilha para 'AAAA-MM-DD'."""
    if vazio(valor):
        return padrao
    if isinstance(valor, str):
        valor = valor.strip()
        for formato in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d/%m/%Y", "%d%m%Y"):
            try:
                return datetime.strptime(valor, formato).strftime("%Y-%m-%d")
            except ValueError:
                continue
        raise ValueError(f"Data em formato não reconhecido: {valor!r}")
    try:
        return pd.Timestamp(valor).strftime("%Y-%m-%d")
    except Exception as erro:
        raise ValueError(f"Data inválida: {valor!r}") from erro


def _id_modelo(row: pd.Series) -> int | None:
    bruto = row.get("id_regra_modelo", row.get("ID", None))
    if vazio(bruto):
        return None
    try:
        return int(float(bruto))
    except (TypeError, ValueError):
        return None


class LeitorDeRegrasExcel:
    def __init__(self, caminho_arquivo: str):
        self.caminho_arquivo = caminho_arquivo
        self.regras: list[dict] = []
        self.abas_lidas: list[str] = []
        self.abas_ignoradas: list[str] = []
        self.avisos: list[str] = []

    # ---------- abas ----------
    @staticmethod
    def eh_aba_oferta(df: pd.DataFrame, nome_aba: str) -> bool:
        nome = sem_acento(nome_aba)
        if nome in {"oferta", "modulo oferta", "modulo de oferta"}:
            return True
        colunas = {str(c).strip().lower() for c in df.columns}
        return COLUNAS_OFERTA_OBRIGATORIAS.issubset(colunas)

    @staticmethod
    def eh_aba_subscricao(df: pd.DataFrame, nome_aba: str) -> bool:
        """Aba 'Módulo ...' ou qualquer aba com as colunas fixas do modelo (ex.: 'Planilha1')."""
        colunas = set(map(str, df.columns))
        tem_colunas = {"Nome da ação", "Tipo de regra", "Fator", "Data inicial"}.issubset(colunas)
        return tem_colunas or (sem_acento(nome_aba).startswith("modulo") and "Nome da ação" in colunas)

    def ler(self) -> list[dict]:
        try:
            abas = pd.read_excel(self.caminho_arquivo, sheet_name=None)
        except Exception as erro:
            raise ValueError(f"Erro ao ler o arquivo Excel: {erro}") from erro

        for nome_aba, df in abas.items():
            if self.eh_aba_oferta(df, nome_aba):
                self.abas_lidas.append(nome_aba)
                self._processar_aba_oferta(df, nome_aba)
            elif self.eh_aba_subscricao(df, nome_aba):
                self.abas_lidas.append(nome_aba)
                self._processar_aba_subscricao(df, nome_aba)
            else:
                self.abas_ignoradas.append(nome_aba)

        logger.info("Abas lidas: %s | ignoradas: %s", self.abas_lidas, self.abas_ignoradas)
        if not self.abas_lidas:
            raise ValueError(
                "Nenhuma aba de regras encontrada. O nome da aba precisa começar com 'Módulo' "
                "(ex.: 'Módulo Subscrição') ou ser 'Oferta'."
            )
        return self.regras

    # ---------- Subscrição ----------
    def _processar_aba_subscricao(self, df: pd.DataFrame, nome_aba: str) -> None:
        faltando = [c for c in ("Nome da ação", "Tipo de regra", "Fator") if c not in df.columns]
        if faltando:
            raise ValueError(f"Aba '{nome_aba}' sem as colunas {faltando}.")

        colunas_variaveis = [c for c in df.columns if c not in COLUNAS_FIXAS]
        for indice, row in df.iterrows():
            if all(vazio(row.get(c)) for c in ("Nome da ação", "Tipo de regra", "Fator")):
                continue  # linha em branco no fim da planilha
            regra = {
                "modulo": "Subscrição",
                "negocio": texto_celula(row.get("Negócio", "")),
                "nome_regra": texto_celula(row.get("Nome da ação", "")),
                "data_inicial": normalizar_data_iso(row.get("Data inicial"), DATA_FINAL_PADRAO),
                "data_final": normalizar_data_iso(row.get("Data final"), DATA_FINAL_PADRAO),
                "tipo_regra": texto_celula(row.get("Tipo de regra", "")),
                "ajuste": row.get("Fator"),
                "fator_original": "" if vazio(row.get("Fator")) else texto_celula(row.get("Fator")),
                "nome_regra_modelo": "" if vazio(row.get("Modelos de regras")) else texto_celula(row.get("Modelos de regras")),
                "id_regra_modelo": _id_modelo(row),
                "nome_aba": nome_aba,
                "linha_planilha": int(indice) + 2,  # +1 do cabeçalho, +1 porque o Excel começa em 1
                "variaveis": [],
            }
            for coluna in colunas_variaveis:
                valor = row[coluna]
                if vazio(valor):
                    continue
                variavel = self._parse_variavel(str(coluna), valor, nome_aba)
                if variavel:
                    regra["variaveis"].append(variavel)
            self.regras.append(regra)

    # ---------- Oferta ----------
    def _processar_aba_oferta(self, df: pd.DataFrame, nome_aba: str) -> None:
        cpf = re.compile(r"cpf\s*/\s*cnpj", re.IGNORECASE)
        parceiro = re.compile(r"c[oó]digo\s+parceiro|codparceiro", re.IGNORECASE)

        for indice, row in df.iterrows():
            nome_agrupamento = row.get("Nome Agrupamento", row.get("Nome da ação", ""))
            if vazio(nome_agrupamento):
                continue
            nome_agrupamento = texto_celula(nome_agrupamento)
            ajuste = row.get("Fator (%)", row.get("Fator", ""))
            regra = {
                "modulo": "Oferta",
                "nome_regra": nome_agrupamento,
                "data_inicial": normalizar_data_iso(row.get("Data Inicial", row.get("Data inicial")), DATA_FINAL_PADRAO),
                "data_final": normalizar_data_iso(row.get("Data Final", row.get("Data final")), DATA_FINAL_PADRAO),
                "tipo_regra": "Oferta" if vazio(row.get("Tipo de regra")) else texto_celula(row.get("Tipo de regra")),
                "ajuste": ajuste,
                "fator_original": "" if vazio(ajuste) else texto_celula(ajuste),
                "nome_regra_modelo": "" if vazio(row.get("Modelos de regras")) else texto_celula(row.get("Modelos de regras")),
                "id_regra_modelo": _id_modelo(row),
                "nome_aba": nome_aba,
                "linha_planilha": int(indice) + 2,
                "variaveis": [],
            }

            # Em Oferta o CPF/CNPJ aponta sempre para o agrupamento com o mesmo nome da regra.
            variavel_cpf: dict | None = {
                "nome_dw": "NroCpfCnpj", "acao": "inclusão", "tipo": "categórica",
                "valores": [nome_agrupamento],
            }
            for coluna in df.columns:
                if coluna in COLUNAS_OFERTA_BASE:
                    continue
                valor = row[coluna]
                if vazio(valor):
                    continue
                coluna = str(coluna)
                if cpf.search(coluna):
                    valor = nome_agrupamento
                variavel = self._parse_variavel(coluna, valor, nome_aba)
                if variavel is None and parceiro.search(coluna):
                    variavel = self._parse_variavel(f"{coluna} (categórica)", valor, nome_aba)
                if variavel and parceiro.search(variavel["nome_dw"]):
                    variavel["nome_dw"] = "CodParceiro"
                if variavel and cpf.search(variavel["nome_dw"]):
                    variavel["nome_dw"] = "NroCpfCnpj"
                    variavel_cpf = None
                if variavel:
                    regra["variaveis"].append(variavel)
            if variavel_cpf is not None:
                regra["variaveis"].insert(0, variavel_cpf)
            self.regras.append(regra)

    # ---------- variáveis ----------
    def _parse_variavel(self, coluna: str, valor: Any, nome_aba: str) -> dict | None:
        """'CodParceiro Exclusão (Categórica)' -> nome, ação, tipo e valores separados por ';'."""
        match = re.search(r"^(.*?)\s*\(([^)]+)\)$", coluna.strip())
        if not match:
            return None  # colunas "Clique aqui escolha a Variável..." não têm (tipo)

        corpo = match.group(1).strip()
        tipo = sem_acento(match.group(2))
        acao = "inclusão"
        if tipo in {"inclusao", "exclusao", "igual", "diferente"}:
            acao = "inclusão" if tipo in {"inclusao", "igual"} else "exclusão"
            tipo = "categorica"

        acao_match = re.search(r"\b(inclus[ãa]o|exclus[ãa]o|igual|diferente)\b", corpo, flags=re.IGNORECASE)
        if acao_match:
            palavra = sem_acento(acao_match.group(1))
            acao = "inclusão" if palavra in {"inclusao", "igual"} else "exclusão"
            corpo = re.sub(r"\b(inclus[ãa]o|exclus[ãa]o|igual|diferente)\b", "", corpo, flags=re.IGNORECASE).strip(" -")

        nome_variavel = corpo.strip()
        if not nome_variavel:
            return None

        brutos = [v.strip() for v in texto_celula(valor).split(";") if v.strip()]
        if tipo == "continua":
            valores: list = []
            for item in brutos:
                partes = re.split(r"\s+a\s+", item.strip())
                try:
                    minimo, maximo = (int(float(p.replace(",", "."))) for p in partes)
                except ValueError:
                    raise ValueError(
                        f"Aba '{nome_aba}', coluna '{coluna}': faixa inválida {item!r}. Use o formato '18 a 25'."
                    ) from None
                valores.append((minimo, maximo))
            tipo_final = "contínua"
        else:
            valores = brutos
            tipo_final = "categórica"

        return {"nome_dw": nome_variavel, "acao": acao, "tipo": tipo_final, "valores": valores}
