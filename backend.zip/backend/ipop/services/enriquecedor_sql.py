"""Consulta o SQL Server (RosieRep) para completar as variáveis das regras.

Portado de services/enriquecedor_sql_service.py com estas mudanças:
- Credenciais vêm da Config (.env), nunca do código.
- Consultas com parâmetros (?) em vez de f-string, em lotes para não passar
  do limite de 2100 parâmetros do SQL Server.
- Lista vazia não gera mais "IN ()".
- Se não conectar, levanta erro claro (antes seguia sem dados e quebrava depois).
"""
from __future__ import annotations

import logging
from collections import defaultdict
from typing import Any, Iterable, Sequence

from ipop.config import Config

logger = logging.getLogger(__name__)

LOTE_PARAMETROS = 1000


class ErroSQL(RuntimeError):
    pass


def _lotes(itens: Sequence[Any], tamanho: int = LOTE_PARAMETROS) -> Iterable[Sequence[Any]]:
    for inicio in range(0, len(itens), tamanho):
        yield itens[inicio:inicio + tamanho]


def _marcadores(quantidade: int) -> str:
    return ",".join("?" * quantidade)


class EnriquecedorSQL:
    def __init__(self, config: Config, conexao=None):
        self.config = config
        self._conexao = conexao

    # ---------- conexão ----------
    def conectar(self):
        if self._conexao is not None:
            return self._conexao
        try:
            import pyodbc
        except ImportError as erro:
            raise ErroSQL(
                "pyodbc não pôde ser carregado. Instale o unixODBC e o 'ODBC Driver 18 for SQL Server' "
                f"(veja o README). Detalhe: {erro}"
            ) from erro
        if self.config.sql_driver not in pyodbc.drivers():
            raise ErroSQL(
                f"Driver ODBC '{self.config.sql_driver}' não está instalado. Instalados: {pyodbc.drivers()}"
            )
        try:
            self._conexao = pyodbc.connect(self.config.string_conexao_sql(), timeout=15)
        except Exception as erro:
            raise ErroSQL(f"Não foi possível conectar ao SQL Server '{self.config.sql_servidor}': {erro}") from erro
        return self._conexao

    def fechar(self):
        if self._conexao is not None:
            try:
                self._conexao.close()
            finally:
                self._conexao = None

    def _consultar(self, sql: str, parametros: Sequence[Any]) -> list[dict]:
        cursor = self.conectar().cursor()
        try:
            cursor.execute(sql, list(parametros))
            colunas = [c[0] for c in cursor.description]
            return [dict(zip(colunas, linha)) for linha in cursor.fetchall()]
        finally:
            cursor.close()

    def _consultar_in(self, sql_modelo: str, valores: Sequence[Any], fixos: Sequence[Any] = ()) -> list[dict]:
        """sql_modelo tem '{in}' no lugar da lista do IN; os parâmetros fixos vêm antes."""
        resultado: list[dict] = []
        valores = list(valores)
        for lote in _lotes(valores):
            sql = sql_modelo.format(**{"in": _marcadores(len(lote))})
            resultado.extend(self._consultar(sql, [*fixos, *lote]))
        return resultado

    # ---------- enriquecimento ----------
    def enriquecer(self, regras: list[dict]) -> list[dict]:
        ids_variaveis: set[int] = set()
        valores_por_variavel: dict[int, set[str]] = defaultdict(set)
        for regra in regras:
            for var in regra.get("variaveis", []):
                id_var = var.get("id_variavel")
                if not id_var:
                    continue
                ids_variaveis.add(int(id_var))
                if var.get("tipo") == "categórica":
                    valores_por_variavel[int(id_var)].update(str(v) for v in var.get("valores", []))

        if not ids_variaveis:
            return regras

        ids = sorted(ids_variaveis)
        variaveis = {
            int(l["IDVariavel"]): l
            for l in self._consultar_in(
                "SELECT ID AS IDVariavel, FlagAgrupamento FROM [var].[Variavel] WHERE ID IN ({in})", ids
            )
        }
        grupos: dict[int, list[int]] = defaultdict(list)
        for l in self._consultar_in(
            "SELECT IDVariavel, IDGrupoVariavel FROM [var].[GrupoVariavelDetalhe] WHERE IDVariavel IN ({in}) "
            "ORDER BY IDVariavel, IDGrupoVariavel",
            ids,
        ):
            grupos[int(l["IDVariavel"])].append(int(l["IDGrupoVariavel"]))

        dominios: dict[int, list[dict]] = defaultdict(list)
        for id_var, valores in valores_por_variavel.items():
            if not valores:
                continue
            for l in self._consultar_in(
                "SELECT ID, IDVariavel, VALOR, DOMINIO FROM [var].[VariavelDominio] "
                "WHERE IDVariavel = ? AND VALOR IN ({in})",
                sorted(valores),
                fixos=[id_var],
            ):
                dominios[id_var].append({"ID": int(l["ID"]), "VALOR": l["VALOR"], "DOMINIO": l["DOMINIO"]})

        # Valores numéricos que não bateram com nenhum VALOR: confere se são o código
        # (IdDominio) do domínio. A planilha pode trazer o código no lugar do texto
        # (ex.: agrupamento 398873 = "R_ITURAN_OUT26 _C_Oferta_12%"). Confirmado pelo
        # SQL, vira um domínio normal: o robô seleciona a linha pelo ID e confere o texto.
        dominios_por_id: dict[int, dict[str, dict]] = defaultdict(dict)
        for id_var, valores in valores_por_variavel.items():
            achados = {str(d["VALOR"]) for d in dominios.get(id_var, [])}
            numericos = sorted({int(v) for v in valores - achados if v.strip().isdigit()})
            if not numericos:
                continue
            for l in self._consultar_in(
                "SELECT ID, IDVariavel, VALOR, DOMINIO FROM [var].[VariavelDominio] "
                "WHERE IDVariavel = ? AND ID IN ({in})",
                numericos,
                fixos=[id_var],
            ):
                codigo = str(int(l["ID"]))
                dominio = {"ID": int(l["ID"]), "VALOR": l["VALOR"], "DOMINIO": l["DOMINIO"], "CODIGO": codigo}
                dominios_por_id[id_var][codigo] = dominio
                if all(d["ID"] != dominio["ID"] for d in dominios[id_var]):
                    dominios[id_var].append(dominio)

        ids_dominio = sorted({d["ID"] for lista in dominios.values() for d in lista})
        agrupados: dict[int, list[dict]] = defaultdict(list)
        if ids_dominio:
            for l in self._consultar_in(
                "SELECT ID, IDVariavelDominio, VALOR FROM [var].[VariavelAgrupada] WHERE IDVariavelDominio IN ({in})",
                ids_dominio,
            ):
                agrupados[int(l["IDVariavelDominio"])].append({"ID": int(l["ID"]), "VALOR": l["VALOR"]})

        for regra in regras:
            for var in regra.get("variaveis", []):
                id_var = var.get("id_variavel")
                if not id_var or int(id_var) not in variaveis:
                    continue
                id_var = int(id_var)
                info = variaveis[id_var]
                var["sql_variavel"] = {"FlagAgrupamento": info.get("FlagAgrupamento")}
                var["grupo_variavel_id"] = grupos.get(id_var, [])
                if var.get("tipo") == "categórica":
                    atuais = {str(v) for v in var.get("valores", [])}
                    pedidos = {v.strip() for v in atuais}
                    var["dominios"] = [
                        d for d in dominios.get(id_var, [])
                        if str(d["VALOR"]) in atuais or d.get("CODIGO") in pedidos
                    ]
                    textos = {str(d["VALOR"]) for d in var["dominios"]}
                    # Valores da planilha que eram código: {valor da planilha: domínio}.
                    var["valores_que_sao_id"] = {
                        v: dominios_por_id[id_var][v.strip()]
                        for v in sorted(atuais)
                        if v not in textos and v.strip() in dominios_por_id.get(id_var, {})
                    }
                    if info.get("FlagAgrupamento") == 1:
                        var["agrupados"] = [a for d in var["dominios"] for a in agrupados.get(d["ID"], [])]
        return regras
