"""Passo a passo do cadastro de UMA regra na tela (antigo RegraService)."""
from __future__ import annotations

import logging
from typing import Callable

from playwright.sync_api import Page

from ipop.models.regra import RegraBase
from ipop.pages.formulario_regra import CadastroDeRegraPage
from ipop.pages.lista_regras import ListaRegrasPage

logger = logging.getLogger(__name__)


class CadastroService:
    def __init__(
        self,
        page: Page,
        *,
        verificar_apos_salvar: bool = True,
        ao_passo: Callable[[str], None] | None = None,
    ):
        self.page = page
        self.lista = ListaRegrasPage(page)
        self.formulario = CadastroDeRegraPage(page)
        self.verificar_apos_salvar = verificar_apos_salvar
        # Chamado com o nome de cada passo (ex.: para salvar o HTML da tela).
        self.ao_passo = ao_passo

    def _passo(self, nome: str) -> None:
        if self.ao_passo is None:
            return
        try:
            self.ao_passo(nome)
        except Exception:  # depuração nunca derruba o cadastro
            logger.warning("Não foi possível registrar o passo %s.", nome, exc_info=True)

    def _nome_do_modelo(self, regra: RegraBase, id_modelo: int) -> str:
        """Acha o modelo na lista pelo ID exato e devolve o nome que o IPOP mostra."""
        try:
            self.lista.pesquisar_por_id(id_modelo)
            return self.lista.nome_da_regra(id_modelo)
        except Exception as erro:
            if not regra.nome_regra_modelo:
                raise RuntimeError(f"Regra-modelo {id_modelo} não encontrada na lista do IPOP.") from erro
            logger.warning("Modelo %s não achado pelo ID (%s); tentando pelo nome '%s'.",
                           id_modelo, erro, regra.nome_regra_modelo)
            self.lista.pesquisar_por_nome(regra.nome_regra_modelo)
            # Mesmo pesquisando pelo nome, a linha escolhida é a do ID exato
            # (a busca também traz as "Cópia de ..." desse modelo).
            return self.lista.nome_da_regra(id_modelo)

    def _esperar_copia_nova(
        self, id_modelo: int, nome_modelo: str, ids_antes: set[str], tentativas: int = 6
    ) -> int:
        """Pesquisa de novo até aparecer a cópia nova (o IPOP pode demorar a listar)."""
        linhas: list[tuple[str, str]] = []
        novas: dict[str, str] = {}
        for tentativa in range(1, tentativas + 1):
            if tentativa > 1:
                self.page.wait_for_timeout(5_000)
            linhas = self.lista.linhas_da_busca(nome_modelo)
            copias = self.lista.copias_na_busca_de(linhas)
            novas = {i: n for i, n in copias.items() if i not in ids_antes}
            if novas:
                break
            self._passo(f"busca_copias_depois_{tentativa}")
            logger.info("Cópia nova ainda não apareceu na lista (tentativa %s de %s).", tentativa, tentativas)
        if len(novas) != 1:
            vistas = "; ".join(f"{i}: {n}" for i, n in linhas[:15]) or "lista vazia"
            raise RuntimeError(
                f"Depois de copiar o modelo {id_modelo}, esperava 1 'Cópia de {nome_modelo}' nova "
                f"na lista e achei {len(novas)} ({', '.join(sorted(novas)) or 'nenhuma'}). "
                f"Linhas que a busca mostrou: {vistas}. "
                "Parei sem editar nada. Confira a lista no IPOP."
            )
        return int(next(iter(novas)))

    def _copiar_modelo(self, regra: RegraBase) -> None:
        id_modelo = int(regra.id_regra_modelo)
        self.lista.mostrar_mais_linhas()
        nome_modelo = self._nome_do_modelo(regra, id_modelo)
        if not nome_modelo:
            raise RuntimeError(f"Não consegui ler o nome da regra-modelo {id_modelo} na lista do IPOP.")

        # O IPOP não deixa a cópia nova selecionada. Para abrir a cópia CERTA (e nunca
        # uma "Cópia de ..." antiga que já esteja na lista), anota as cópias que já
        # existem e, depois de copiar, abre a única que apareceu.
        self._passo("modelo_achado")
        copias_antes = self.lista.copias_na_busca(nome_modelo)
        self._passo("busca_copias_antes")
        logger.info("Cópias desse modelo já existentes: %s", sorted(copias_antes) or "nenhuma")
        self.lista.selecionar_por_id(id_modelo)
        self.lista.copiar_selecionada()
        logger.info("Modelo %s (%s) copiado.", id_modelo, nome_modelo)
        self._passo("apos_copiar")

        id_copia = self._esperar_copia_nova(id_modelo, nome_modelo, set(copias_antes))
        logger.info("Cópia nova: ID %s.", id_copia)
        self.lista.selecionar_por_id(id_copia)
        self.lista.abrir_selecionada()
        self.formulario.nome_regra_input.wait_for(state="visible", timeout=30_000)

        # Trava de segurança: só edita se o que abriu for mesmo uma cópia.
        # Sem isso, um clique na linha errada renomearia uma regra existente.
        nome_aberto = self.formulario.nome_regra_input.input_value().strip()
        if not nome_aberto.casefold().startswith("cópia de"):
            raise RuntimeError(
                f"A regra aberta se chama {nome_aberto!r} e não é uma 'Cópia de ...'. "
                "Parei sem salvar para não alterar uma regra existente."
            )

    def cadastrar(self, regra: RegraBase) -> str:
        """Cadastra a regra. Devolve 'confirmada' ou 'salva_sem_confirmacao'."""
        self.lista.esperar_lista_pronta()
        self._passo("lista_pronta")
        if regra.id_regra_modelo:
            self._copiar_modelo(regra)
        else:
            self.lista.abrir_nova_regra()
            self.formulario.nome_regra_input.wait_for(state="visible", timeout=30_000)
        self._passo("regra_aberta")

        self.formulario.preencher_secao_regra(regra)
        self._passo("secao_regra_preenchida")
        for numero, acao in enumerate(regra.variaveis, start=1):
            self.formulario.preencher_arvore_de_decisao(acao)
            self._passo(f"variavel_{numero}_{acao.variavel.variavel_id}")

        self._passo("antes_de_salvar")
        self.formulario.salvar_regra()
        self.lista.esperar_carregamento()
        self._passo("apos_salvar")
        self.formulario.fechar_pagina_de_cadastro()
        self.lista.esperar_lista_pronta()

        if self.verificar_apos_salvar:
            if self.lista.regra_existe(regra.nome_regra):
                return "confirmada"
            logger.warning("Regra '%s' salva, mas não apareceu na busca da lista.", regra.nome_regra)
            return "salva_sem_confirmacao"
        return "salva_sem_confirmacao"
