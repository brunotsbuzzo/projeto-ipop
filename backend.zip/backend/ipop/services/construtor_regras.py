"""Lê o pedido, completa com as tabelas locais e o SQL, valida e cria os objetos de regra."""
from __future__ import annotations

import json
import logging
import unicodedata
from pathlib import Path
from typing import Any, Callable

import pandas as pd

from ipop.config import Config
from ipop.models.regra import (
    RegraAgravo, RegraBase, RegraDesconto, RegraEngenhariaReversa, RegraOferta, RegraRecusa,
)
from ipop.services.leitor_pedido import LeitorDeRegrasExcel, vazio

logger = logging.getLogger(__name__)


def data_br(iso: str) -> str:
    try:
        ano, mes, dia = str(iso)[:10].split("-")
        return f"{dia}/{mes}/{ano}"
    except ValueError:
        return str(iso)


class ErroValidacao(ValueError):
    def __init__(self, erros: list[str], avisos: list[str], problemas: list[dict] | None = None):
        self.erros = erros
        self.avisos = avisos
        self.problemas = problemas or []
        limite = 30
        linhas = "\n".join(f"  - {e}" for e in erros[:limite])
        extra = f"\n  ... e mais {len(erros) - limite} problema(s)." if len(erros) > limite else ""
        super().__init__(f"{len(erros)} problema(s) na planilha. Nada foi cadastrado.\n{linhas}{extra}")


def _normalizar_nome_modelo(valor: Any) -> str:
    if vazio(valor):
        return ""
    texto = unicodedata.normalize("NFD", str(valor)).encode("ascii", "ignore").decode("ascii")
    return "".join(ch for ch in texto.lower() if ch.isalnum())


def criar_regra(dados: dict) -> RegraBase:
    """Escolhe a classe certa (antigo FabricaRegra.criar)."""
    base = RegraBase.parse_comum(dados)
    tipo = base.tipo_regra.strip().casefold()
    valores = vars(base)

    if base.modulo == "Oferta":
        return RegraOferta(**valores)
    if tipo == "agravo/desconto":
        return RegraAgravo(**valores) if base.ajuste > 1 else RegraDesconto(**valores)
    if tipo == "não exibe prêmio":
        return RegraRecusa(**valores)
    if tipo == "ajuste por relac. is":
        return RegraEngenhariaReversa(**valores)
    raise ValueError(f"Tipo de regra inválido: {base.tipo_regra!r}")


class ConstrutorRegras:
    def __init__(
        self,
        config: Config,
        caminho_pedido: str | Path,
        *,
        caminho_saida_json: str | Path | None = None,
        fabrica_enriquecedor: Callable[[Config], Any] | None = None,
        tbl_dim_dir: str | Path | None = None,
    ):
        self.tbl_dim_dir = Path(tbl_dim_dir) if tbl_dim_dir else config.tbl_dim_dir
        self.config = config
        self.caminho_pedido = str(caminho_pedido)
        self.caminho_saida_json = Path(caminho_saida_json) if caminho_saida_json else None
        self._fabrica_enriquecedor = fabrica_enriquecedor
        self.regras: list[dict] = []
        self.avisos: list[str] = []
        self.df_de_para = pd.DataFrame()
        self.df_regra_modelo = pd.DataFrame()

    # ---------- etapas ----------
    def carregar_regras(self) -> None:
        leitor = LeitorDeRegrasExcel(self.caminho_pedido)
        self.regras = leitor.ler()
        self.abas_lidas = leitor.abas_lidas
        logger.info("%d regra(s) lidas da planilha.", len(self.regras))

    def carregar_tabelas_auxiliares(self) -> None:
        self.df_de_para = pd.read_excel(self.tbl_dim_dir / "TblDePara.xlsx").rename(columns={"NomeDW": "nome_dw"})
        self.df_regra_modelo = pd.read_excel(self.tbl_dim_dir / "TblRegraModelo.xlsx").rename(
            columns={"Modelos de regras": "modelos_de_regras"}
        )

    def nome_copia_do_modelo(self, id_modelo: int) -> str | None:
        linha = self.df_regra_modelo[self.df_regra_modelo["ID"] == id_modelo]
        if linha.empty or vazio(linha["NomeRegraIPOP"].iloc[0]):
            return None
        return f"Cópia de {str(linha['NomeRegraIPOP'].iloc[0]).strip()}"

    def enriquecer_localmente(self) -> None:
        nomes_catalogo = self.df_regra_modelo["modelos_de_regras"].map(_normalizar_nome_modelo)
        for regra in self.regras:
            nome_modelo = regra.get("nome_regra_modelo", "")
            id_modelo = regra.get("id_regra_modelo")

            if id_modelo is None and nome_modelo:
                achado = self.df_regra_modelo[nomes_catalogo == _normalizar_nome_modelo(nome_modelo)]
                if achado.empty:
                    regra["_modelo_nao_encontrado"] = True
                elif not vazio(achado["ID"].iloc[0]):
                    id_modelo = int(achado["ID"].iloc[0])

            # Oferta sem modelo: usa a regra-modelo do antigo robô Selenium.
            if id_modelo is None and regra["modulo"] == "Oferta" and self.config.oferta_modelo_id:
                id_modelo = self.config.oferta_modelo_id

            regra["id_regra_modelo"] = int(id_modelo) if id_modelo is not None else None
            regra["nome_regra_copia_IPOP"] = (
                self.nome_copia_do_modelo(regra["id_regra_modelo"]) if regra["id_regra_modelo"] else None
            )

            for variavel in regra["variaveis"]:
                linhas = self.df_de_para[self.df_de_para["nome_dw"] == variavel["nome_dw"]]
                variavel["id_variavel"] = int(linhas["IDVariavel"].iloc[0]) if not linhas.empty else None
                nome_ipop = linhas["Nome Ipop"].iloc[0] if not linhas.empty and "Nome Ipop" in linhas else None
                variavel["nome_ipop"] = str(nome_ipop).strip() if not vazio(nome_ipop) else variavel["nome_dw"]

    def enriquecer_com_sql(self) -> None:
        if not any(v.get("id_variavel") for r in self.regras for v in r["variaveis"]):
            return
        if self._fabrica_enriquecedor is not None:
            enriquecedor = self._fabrica_enriquecedor(self.config)
        else:
            from ipop.services.enriquecedor_sql import EnriquecedorSQL
            enriquecedor = EnriquecedorSQL(self.config)
        try:
            self.regras = enriquecedor.enriquecer(self.regras)
        finally:
            fechar = getattr(enriquecedor, "fechar", None)
            if fechar:
                fechar()

    def exportar_json(self) -> None:
        if self.caminho_saida_json is None:
            return
        self.caminho_saida_json.parent.mkdir(parents=True, exist_ok=True)
        with open(self.caminho_saida_json, "w", encoding="utf-8") as arquivo:
            json.dump(self.regras, arquivo, indent=2, ensure_ascii=False, default=str)

    def validar(self) -> None:
        """Confere tudo ANTES de abrir o navegador; erro aqui impede o cadastro inteiro.

        Cada problema vira um dict {nivel, aba, linha, nome, campo, mensagem}, que a tela usa
        para marcar a célula errada. `erros`/`avisos` (texto) continuam para a linha de comando.
        """
        problemas: list[dict] = []
        nomes_vistos: dict[str, int | None] = {}

        def add(nivel: str, regra: dict, campo: str, mensagem: str) -> None:
            problemas.append({
                "nivel": nivel, "aba": regra.get("nome_aba"), "linha": regra.get("linha_planilha"),
                "nome": regra.get("nome_regra") or "", "campo": campo, "mensagem": mensagem,
            })

        for regra in self.regras:
            if vazio(regra.get("nome_regra")):
                add("erro", regra, "nome", "Nome da ação: coluna vazia.")
            else:
                anterior = nomes_vistos.get(regra["nome_regra"], -1)
                if anterior != -1:
                    # Acontece de propósito (ex.: ID3420, uma regra por filial com o mesmo nome).
                    add("aviso", regra, "nome", f"Nome da ação: “{regra['nome_regra']}” repetido (também na linha {anterior}).")
                nomes_vistos[regra["nome_regra"]] = regra.get("linha_planilha")

            ajuste = regra.get("ajuste")
            if vazio(ajuste):
                add("erro", regra, "fator", "Fator: coluna vazia.")
            else:
                try:
                    regra["ajuste"] = float(str(ajuste).replace(",", ".")) if isinstance(ajuste, str) else float(ajuste)
                except ValueError:
                    add("erro", regra, "fator", f"Fator: “{ajuste}” não é um número.")

            if regra.get("data_inicial", "") > regra.get("data_final", ""):
                add("erro", regra, "vigencia", f"Vigência: a data inicial ({data_br(regra['data_inicial'])}) "
                                               f"é depois da data final ({data_br(regra['data_final'])}).")

            if regra["modulo"] == "Subscrição":
                tipo = str(regra.get("tipo_regra", "")).strip().casefold()
                if tipo not in {"agravo/desconto", "não exibe prêmio", "ajuste por relac. is"}:
                    add("erro", regra, "tipo", f"Tipo de regra: “{regra.get('tipo_regra')}” não é suportado.")

            if regra.get("_modelo_nao_encontrado"):
                add("erro", regra, "modelo", f"Modelo de regra: “{regra.get('nome_regra_modelo')}” não está na lista oficial de modelos.")
            elif regra.get("id_regra_modelo") is None:
                add("aviso", regra, "modelo", "Modelo de regra: sem regra-modelo. A regra será criada do zero.")

            if not regra["variaveis"]:
                add("aviso", regra, "variaveis", "Variáveis: regra sem nenhuma variável.")

            for var in regra["variaveis"]:
                rotulo = f"{var.get('nome_ipop') or var.get('nome_dw')} ({var.get('id_variavel')})"
                if not var.get("id_variavel"):
                    add("erro", regra, "variaveis", f"Variáveis: “{var.get('nome_dw')}” não está na tabela de variáveis do IPOP.")
                    continue
                if not var.get("grupo_variavel_id"):
                    add("erro", regra, "variaveis", f"Variáveis: {rotulo} sem grupo de variáveis no IPOP.")
                if not var.get("valores"):
                    add("erro", regra, "variaveis", f"Variáveis: {rotulo} sem valores.")
                if var.get("tipo") == "categórica":
                    esperados = {str(v) for v in var.get("valores", [])}
                    achados = {str(d.get("VALOR")) for d in var.get("dominios", []) or []}
                    trocados = var.get("valores_que_sao_id") or {}
                    for valor, dominio in trocados.items():
                        add("erro", regra, "variaveis",
                            f"Variáveis: {rotulo} · {valor} é o código (IdDominio) de “{dominio.get('VALOR')}” no IPOP, "
                            f"não o texto. O IPOP não mostra esse código na tela. Na planilha, use “{dominio.get('VALOR')}”.")
                    faltando = sorted(esperados - achados - set(trocados))
                    if faltando:
                        lista = "; ".join(faltando[:10]) + ("…" if len(faltando) > 10 else "")
                        add("aviso", regra, "variaveis", f"Variáveis: {rotulo} · {lista} não está nas tabelas do IPOP. "
                                                         "O robô vai procurar pelo texto na lista.")

        self.problemas = problemas
        texto = lambda p: f"[{p['aba']} linha {p['linha']}] {p['nome'] or '(sem nome)'}: {p['mensagem']}"
        erros = [texto(p) for p in problemas if p["nivel"] == "erro"]
        self.avisos = [texto(p) for p in problemas if p["nivel"] == "aviso"]
        for aviso in self.avisos:
            logger.warning(aviso)
        if erros:
            raise ErroValidacao(erros, self.avisos, problemas)

    def previa(self) -> list[dict]:
        """Linhas da pré-visualização (o que a pessoa vê antes de enviar), na ordem do cadastro."""
        problemas = getattr(self, "problemas", [])
        linhas = []
        for n, regra in enumerate(self.regras, start=1):
            campos = sorted({p["campo"] for p in problemas
                             if p["nivel"] == "erro" and p["linha"] == regra.get("linha_planilha") and p["aba"] == regra.get("nome_aba")})
            linhas.append({
                "n": n,
                "aba": regra.get("nome_aba"),
                "modulo": regra.get("modulo"),
                "linha": regra.get("linha_planilha"),
                "negocio": regra.get("negocio") or "",
                "vigencia_inicio": regra.get("data_inicial"),
                "vigencia_fim": regra.get("data_final"),
                "nome": regra.get("nome_regra") or "",
                "fator_original": regra.get("fator_original") or "",
                "fator": regra.get("ajuste") if isinstance(regra.get("ajuste"), (int, float)) else None,
                "tipo": regra.get("tipo_regra") or "",
                "modelo": regra.get("nome_regra_modelo") or ("Modelo padrão de Oferta" if regra.get("modulo") == "Oferta" and regra.get("id_regra_modelo") else "Não se aplica"),
                "id_modelo": regra.get("id_regra_modelo"),
                "variaveis": [
                    {
                        "nome": v.get("nome_ipop") or v.get("nome_dw"),
                        "codigo": v.get("id_variavel"),
                        "acao": "Inclusão" if v.get("acao") == "inclusão" else "Exclusão",
                        "valores": [f"{a} a {b}" if isinstance(a, (int, float)) and not isinstance(a, bool) and v.get("tipo") == "contínua" else str(a)
                                    for a, b in ((x if isinstance(x, (list, tuple)) else (x, None)) for x in v.get("valores", []))],
                    }
                    for v in regra.get("variaveis", [])
                ],
                "campos_com_erro": campos,
            })
        return linhas

    def executar(self) -> list[RegraBase]:
        self.carregar_regras()
        self.carregar_tabelas_auxiliares()
        self.enriquecer_localmente()
        self.enriquecer_com_sql()
        self.exportar_json()
        self.validar()
        objetos = [criar_regra(r) for r in self.regras]
        logger.info("%d regra(s) prontas para cadastro.", len(objetos))
        return objetos
