"""Telas de login e de escolha de módulo do IPOP."""
from __future__ import annotations

from playwright.sync_api import Page, expect


class ErroLogin(RuntimeError):
    pass


class LoginPage:
    def __init__(self, page: Page, url_login: str):
        self.page = page
        self.url_login = url_login
        self.input_usuario = page.locator("#usuario_input")
        self.input_senha = page.locator("#senha_input")
        self.botao_entrar = page.locator("#entrar_button")
        self.marca_home = page.locator("a.navbar-brand")

    def entrar(self, usuario: str, senha: str, timeout: int = 60_000) -> None:
        self.page.goto(self.url_login, wait_until="domcontentloaded", timeout=timeout)
        expect(self.input_usuario).to_be_editable(timeout=timeout)
        self.input_usuario.fill(usuario)
        self.input_senha.fill(senha)
        self.botao_entrar.click()
        try:
            self.marca_home.wait_for(state="visible", timeout=timeout)
        except Exception as erro:
            raise ErroLogin(
                "Login no IPOP não concluiu (usuário/senha errados, conta sem acesso ou IPOP fora do ar)."
            ) from erro
        # O trace e o HTML salvos depois copiam o valor dos campos: não deixa a senha na página.
        self.page.evaluate("() => document.querySelectorAll('input[type=password]').forEach(i => { i.value = ''; })")


class HomePage:
    def __init__(self, page: Page):
        self.page = page
        self.busca_regras = page.locator('input[placeholder="Pesquisar"][aria-controls="regras_lista"]')

    def acessar_modulo(self, nome_modulo: str, timeout: int = 30_000) -> None:
        """nome_modulo: 'Subscrição' ou 'Oferta' (texto do menu)."""
        self.page.locator("a.navbar-brand").click()
        modulo = self.page.locator(f'a.nav-link span:text-is("{nome_modulo}")')
        modulo.wait_for(state="visible", timeout=timeout)
        modulo.click()
        self.busca_regras.wait_for(state="visible", timeout=timeout)
