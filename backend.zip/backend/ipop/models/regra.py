"""Regras e variáveis (portado de models/*.py do RoboIPOP-Subs-Oferta)."""
from __future__ import annotations

from dataclasses import dataclass, field, fields
from typing import Any


@dataclass
class Variavel:
    grupo_variavel_id: str
    variavel_id: str
    tipo_lista_id: str
    tipo_variavel_id: str


@dataclass
class VariavelCategorica(Variavel):
    # Texto exibido no grid (VALOR do domínio ou o valor da planilha).
    valores: list[str] = field(default_factory=list)
    dominios: list[dict[str, Any]] = field(default_factory=list)
    # IDs dos domínios (IdDominio), alinhados posição a posição com `valores`.
    # Vazio quando o SQL não encontrou o domínio ou quando a variável precisa
    # ser selecionada pelo texto (ex.: CodGrpModelo).
    ids_dominio: list[str] = field(default_factory=list)


@dataclass
class VariavelContinua(Variavel):
    valores: list[tuple[int, int]] = field(default_factory=list)


@dataclass
class AcaoVariavel:
    tipo_acao: str  # "inclusão" ou "exclusão"
    variavel: Variavel


def _normalizar_acao(acao: Any) -> str:
    texto = str(acao or "").strip().casefold()
    if texto in {"inclusao", "inclusão", "igual"}:
        return "inclusão"
    if texto in {"exclusao", "exclusão", "diferente"}:
        return "exclusão"
    raise ValueError(f"Ação de variável inválida: {acao!r}")


def _primeiro_grupo(grupos: Any) -> str:
    if isinstance(grupos, (list, tuple, set)):
        grupos = list(grupos)
        for item in grupos:
            if item not in (None, "", 0):
                return str(item)
        return str(grupos[0]) if grupos else ""
    return "" if grupos is None else str(grupos)


@dataclass
class RegraBase:
    id_regra_modelo: int | None
    nome_regra_modelo: str
    nome_regra_copia_IPOP: str | None
    nome_aba: str
    modulo: str  # "Subscrição" ou "Oferta"
    nome_regra: str
    ajuste: float
    tipo_regra: str
    data_inicial: str  # AAAA-MM-DD
    data_final: str  # AAAA-MM-DD
    variaveis: list[AcaoVariavel] = field(default_factory=list)

    hora_inicial: str = "00:00"
    hora_final: str = "23:59"
    comentario: str = ""
    subs_balanceada: bool = False
    linha_planilha: int | None = None

    @property
    def eh_oferta(self) -> bool:
        return self.modulo == "Oferta"

    @classmethod
    def parse_comum(cls, dados: dict) -> "RegraBase":
        variaveis: list[AcaoVariavel] = []
        for v in dados.get("variaveis", []):
            tipo_acao = _normalizar_acao(v.get("acao"))
            grupo_variavel_id = _primeiro_grupo(v.get("grupo_variavel_id", []))
            if not grupo_variavel_id:
                raise ValueError(f"grupo_variavel_id inválido para a variável {v.get('id_variavel')!r}")

            if v.get("tipo") == "categórica":
                # Com domínios do SQL: o ID (IdDominio) filtra o grid e acha a
                # linha exata; o VALOR serve de conferência. CodGrpModelo é
                # exceção: é selecionado pelo VALOR exibido. Sem domínios do
                # SQL: usa o texto da planilha.
                valores_planilha = [str(x) for x in v.get("valores", [])]
                dominios = v.get("dominios") or []
                usa_valor_exibido = str(v.get("nome_dw", "")).strip().casefold() == "codgrpmodelo"

                valores: list[str] = []
                ids_dominio: list[str] = []
                for d in dominios:
                    if d.get("VALOR") is None:
                        continue
                    valores.append(str(d["VALOR"]))
                    if not usa_valor_exibido and d.get("ID") is not None:
                        ids_dominio.append(str(int(d["ID"])))
                if len(ids_dominio) != len(valores):
                    ids_dominio = []
                if not valores:
                    valores = valores_planilha

                variavel: Variavel = VariavelCategorica(
                    grupo_variavel_id=grupo_variavel_id,
                    variavel_id=str(v["id_variavel"]),
                    tipo_variavel_id="categórica",
                    tipo_lista_id="3",
                    valores=valores,
                    dominios=dominios,
                    ids_dominio=ids_dominio,
                )
            else:
                variavel = VariavelContinua(
                    grupo_variavel_id=grupo_variavel_id,
                    variavel_id=str(v["id_variavel"]),
                    tipo_variavel_id="contínua",
                    tipo_lista_id="3",
                    valores=[tuple(i) for i in v.get("valores", [])],
                )
            variaveis.append(AcaoVariavel(tipo_acao=tipo_acao, variavel=variavel))

        return cls(
            id_regra_modelo=dados.get("id_regra_modelo"),
            nome_regra_modelo=str(dados.get("nome_regra_modelo") or ""),
            nome_regra_copia_IPOP=dados.get("nome_regra_copia_IPOP"),
            nome_aba=dados["nome_aba"],
            modulo=dados["modulo"],
            nome_regra=str(dados["nome_regra"]),
            data_inicial=dados["data_inicial"],
            data_final=dados["data_final"],
            tipo_regra=str(dados.get("tipo_regra") or ""),
            ajuste=float(dados["ajuste"]),
            comentario=dados.get("comentario", "") or "",
            subs_balanceada=bool(dados.get("subs_balanceada", False)),
            linha_planilha=dados.get("linha_planilha"),
            variaveis=variaveis,
        )

    def como_dict(self) -> dict:
        return {f.name: getattr(self, f.name) for f in fields(self) if f.name != "variaveis"}


@dataclass
class RegraAgravo(RegraBase):
    """Fator > 1: 1,58 vira 58 no campo de percentual."""

    def __post_init__(self):
        self.ajuste = round((self.ajuste - 1) * 100, 2)


@dataclass
class RegraDesconto(RegraBase):
    """Fator <= 1: 0,90 vira -10 no campo de percentual."""

    def __post_init__(self):
        self.ajuste = round((self.ajuste - 1) * 100, 2)


@dataclass
class RegraRecusa(RegraBase):
    """'Não exibe prêmio'."""


@dataclass
class RegraEngenhariaReversa(RegraBase):
    """'Ajuste por relac. IS'."""


@dataclass
class RegraOferta(RegraBase):
    """Módulo Oferta: o percentual vai como está na planilha."""
