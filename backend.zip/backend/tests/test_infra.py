"""Fila no Postgres: reserva por tipo, trava única do robô, órfãs e retomada."""
import pytest

from ipop.infra.db import Repositorio


@pytest.fixture
def repo(config_infra):
    r = Repositorio(config_infra)
    r.garantir_schema()
    yield r
    with r.conexao() as c:
        c.execute(f"DROP SCHEMA {config_infra.db_schema} CASCADE")
    r.fechar()


def _nova(repo, id_, tipo="cadastro"):
    repo.criar_execucao(id=id_, tipo=tipo, usuario="u", nome_original="p.xlsx", objeto_pedido="x",
                        ambiente="hml", so_dados=tipo == "validacao", titulo="T", lote_id="1", categoria="Frota")


def test_schema_idempotente_e_fila_por_tipo(repo):
    repo.garantir_schema()
    _nova(repo, "20261105-100000-aaaaaa", "validacao")
    _nova(repo, "20261105-100001-bbbbbb", "cadastro")
    assert repo.reservar_proxima("w", "cadastro")["id"] == "20261105-100001-bbbbbb"
    assert repo.reservar_proxima("w", "cadastro") is None
    assert repo.reservar_proxima("w", "validacao")["id"] == "20261105-100000-aaaaaa"
    eventos = repo.listar_eventos("20261105-100001-bbbbbb")
    assert [e["titulo"] for e in eventos] == ["Recebida"]
    assert repo.listar_eventos("20261105-100000-aaaaaa") == []


def test_so_um_robo_por_vez(repo):
    c1, c2 = repo.conexao_dedicada(), repo.conexao_dedicada()
    try:
        assert repo.tentar_trava_do_robo(c1)
        assert not repo.tentar_trava_do_robo(c2)
        c1.close()  # worker caiu: a trava é solta junto com a conexão
        assert repo.tentar_trava_do_robo(c2)
    finally:
        c2.close()


def test_orfa_vira_interrompida_e_marca_regra_para_conferir(repo):
    id_ = "20261105-100002-cccccc"
    _nova(repo, id_)
    repo.reservar_proxima("w")
    repo.definir_regras(id_, [{"n": 1, "nome": "A", "status": "confirmada"}, {"n": 2, "nome": "B", "status": "executando"},
                              {"n": 3, "nome": "C"}])
    with repo.conexao() as c:
        c.execute(f"UPDATE {repo.s}.execucoes SET fase='cadastrando', heartbeat = now() - interval '10 minutes'")
    assert repo.recuperar_orfas(120) == [id_]
    e = repo.obter_execucao(id_)
    assert e["fase"] == "interrompida"
    assert [r["status"] for r in e["regras"]] == ["confirmada", "verificar", "não executada"]
    assert repo.reservar_proxima("w") is None  # não volta sozinha para a fila


def test_retomada_preserva_regras_ja_cadastradas(repo):
    id_ = "20261105-100003-dddddd"
    _nova(repo, id_)
    repo.reservar_proxima("w")
    repo.definir_regras(id_, [{"n": 1, "nome": "A", "status": "confirmada", "detalhe": "ok"},
                              {"n": 2, "nome": "B", "status": "erro"}])
    repo.atualizar_execucao(id_, fase="erro", mensagem="parou")
    assert repo.retomar(id_, 2, "operador")
    assert not repo.retomar(id_, 2, "operador")  # já está na fila
    e = repo.reservar_proxima("w")
    assert e["inicio"] == 2
    repo.definir_regras(id_, [{"n": 1, "nome": "A"}, {"n": 2, "nome": "B"}], preservar_ate=2)
    repo.atualizar_regra(id_, 1, status="pulada", detalhe="Execução começou na regra 2.")
    regras = repo.obter_execucao(id_)["regras"]
    assert (regras[0]["status"], regras[0]["detalhe"]) == ("confirmada", "ok")
    assert regras[1]["status"] == "pendente"
    assert [ev["titulo"] for ev in repo.listar_eventos(id_)] == ["Retomada da regra 2", "Recebida"]


def test_cancelamento(repo):
    na_fila, rodando = "20261105-100004-eeeeee", "20261105-100005-ffffff"
    _nova(repo, rodando); repo.reservar_proxima("w")
    _nova(repo, na_fila)
    assert repo.pedir_cancelamento(na_fila) == "cancelada"
    assert repo.pedir_cancelamento(rodando) == "pedido"
    assert repo.cancelamento_pedido(rodando)
    assert repo.pedir_cancelamento(rodando) is None
