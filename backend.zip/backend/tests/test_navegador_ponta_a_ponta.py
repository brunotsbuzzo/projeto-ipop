"""Roda o robô de verdade (Chromium headless) contra o IPOP falso de tests/ipop_falso.

Cobre: login, troca de módulo, cópia do modelo, Nova regra, variáveis
categóricas e contínuas, o filtro do grid pesado (variável 193) e a tela de Oferta.
"""
from __future__ import annotations

import threading

import pandas as pd
import pytest

from ipop.conectividade import Checagem
from ipop.progresso import ProgressoArquivo, gravar_json, ler_json

from .conftest import gravar_pedido, linha_subs
from .ipop_falso.servidor import EstadoIPOP, criar_servidor

playwright = pytest.importorskip("playwright.sync_api")

# Descrição (DOMINIO) que o grid mostra; sem entrada aqui, a descrição é o próprio valor.
DESCRICOES = {"10": "Ituran"}
# IdDominio que a planilha pode trazer no lugar do texto -> texto do domínio.
CODIGOS = {"700001": "R_ITURAN_DEZ26_C_Subs_Agravo_58%"}
IDS_DOMINIO = {"10": 236899, "R_ITURAN_DEZ26_C_Subs_Agravo_58%": 700001, "R_ITURAN_DEZ26_Oferta_6%": 700002}


class SQLPorValor:
    def __init__(self, _config=None):
        pass

    def enriquecer(self, regras):
        for regra in regras:
            for var in regra["variaveis"]:
                if var.get("id_variavel"):
                    var["grupo_variavel_id"] = [4, 5]
                    if var["tipo"] == "categórica":
                        var["dominios"] = [{"ID": IDS_DOMINIO[v], "VALOR": v, "DOMINIO": DESCRICOES.get(v, v)}
                                           for v in var["valores"] if v in IDS_DOMINIO]
                        # Código (IdDominio) digitado no lugar do texto, como o SQL devolve.
                        for v in var["valores"]:
                            if v in CODIGOS:
                                texto = CODIGOS[v]
                                var["dominios"].append({"ID": int(v), "VALOR": texto, "DOMINIO": texto, "CODIGO": v})
        return regras

    def fechar(self):
        pass


def _grids():
    enchimento = [{"IdDominio": 100000 + i, "Valor": f"R_OUTRO_{i}", "Dominio": f"R_OUTRO_{i}"} for i in range(3000)]
    enchimento.insert(2500, {"IdDominio": 700001, "Valor": "R_ITURAN_DEZ26_C_Subs_Agravo_58%", "Dominio": "R_ITURAN_DEZ26_C_Subs_Agravo_58%"})
    enchimento.insert(2800, {"IdDominio": 700002, "Valor": "R_ITURAN_DEZ26_Oferta_6%", "Dominio": "R_ITURAN_DEZ26_Oferta_6%"})
    return {
        229: [{"IdDominio": 236898, "Valor": "100", "Dominio": "Outro"},
              {"IdDominio": 236899, "Valor": "10", "Dominio": "Ituran"}],
        193: enchimento,
    }


@pytest.fixture
def ipop_falso():
    estado = EstadoIPOP(_grids())
    servidor = criar_servidor(estado)
    thread = threading.Thread(target=servidor.serve_forever, daemon=True)
    thread.start()
    yield estado, f"http://127.0.0.1:{servidor.server_address[1]}/login"
    servidor.shutdown()


@pytest.fixture
def ambiente_robo(config, ipop_falso, monkeypatch, tmp_path):
    estado, url = ipop_falso
    for nome, valor in {"IPOP_URL_HML": url, "IPOP_USUARIO": "robo", "IPOP_SENHA": "segredo",
                        "SQL_SERVIDOR": "falso", "SQL_USUARIO": "u", "SQL_SENHA": "s", "HEADLESS": "true"}.items():
        monkeypatch.setenv(nome, valor)
    monkeypatch.setattr("ipop.robo.verificar", lambda cfg, amb: [Checagem("IPOP", url, True, "ok")])
    monkeypatch.setattr("ipop.services.enriquecedor_sql.EnriquecedorSQL", SQLPorValor)
    from ipop.config import Config
    return estado, Config()


def rodar(pasta, cfg):
    from ipop.robo import executar
    parametros = ler_json(pasta / "parametros.json")
    return executar(pasta, cfg, ProgressoArquivo(pasta, parametros), parametros)


def _preparar(cfg, abas, **parametros):
    pasta = cfg.execucoes_dir / "20261105-140000-abcd"
    pasta.mkdir(parents=True)
    gravar_pedido(pasta / "pedido.xlsx", abas)
    gravar_json(pasta / "parametros.json", {"pedido": "pedido.xlsx", "ambiente": "hml", "so_dados": False, **parametros})
    return pasta


def test_cadastra_subscricao_e_oferta(ambiente_robo):
    estado, cfg = ambiente_robo

    pasta = _preparar(cfg, {
        "Módulo Subscrição": [
            linha_subs("R_ITURAN_DEZ26_C_Subs_Agravo_58%", fator=1.58, **{
                "CodParceiro Exclusão (Categórica)": 10,
                "NroCpfCnpj Inclusão (Categórica)": "R_ITURAN_DEZ26_C_Subs_Agravo_58%"}),
            linha_subs("R_ESTUDO_IDADE_DESC_10%", fator=0.9, modelo="Não se aplica", **{
                "IdadeSegurado Inclusão (Contínua)": "18 a 25; 26 a 40"}),
        ],
        "Módulo Oferta": [{"Nome Agrupamento": "R_ITURAN_DEZ26_Oferta_6%", "Fator (%)": 6,
                           "Data Inicial": pd.Timestamp("2026-11-01"), "Data Final": pd.Timestamp("2026-12-31")}],
        "Tabela de variáveis": [{"CodVariavel": 1}],
    })

    assert rodar(pasta, cfg) == 0, ler_json(pasta / "status.json")
    status = ler_json(pasta / "status.json")
    assert status["fase"] == "concluida", status["mensagem"]
    assert [r["status"] for r in status["regras"]] == ["confirmada"] * 3

    agravo, desconto, oferta = estado.salvas
    assert agravo["nome"] == "R_ITURAN_DEZ26_C_Subs_Agravo_58%"
    assert agravo["id"] >= 900001  # editou a cópia, não o modelo
    assert (agravo["percentual"], agravo["tipo"]) == ("58", "Agravo/Desconto")
    assert (agravo["data_inicial"], agravo["data_final"], agravo["hora_final"]) == ("2026-10-31", "2026-12-31", "23:59")
    assert agravo["arvore"] == [
        {"acao": "exclusao", "grupo": "4", "variavel": "229", "valores": ["10"]},
        {"acao": "igualdade", "grupo": "4", "variavel": "193", "valores": ["R_ITURAN_DEZ26_C_Subs_Agravo_58%"]},
    ]

    assert desconto["id"] is None  # "Não se aplica" -> botão Nova
    assert desconto["percentual"] == "-10"
    assert desconto["arvore"] == [{"acao": "igualdade", "grupo": "4", "variavel": "201", "valores": ["18-25", "26-40"]}]

    assert oferta["modulo"] == "Oferta" and oferta["percentual"] == "6"
    assert oferta["arvore"][0]["valores"] == ["R_ITURAN_DEZ26_Oferta_6%"]

    # O grid de 3.000 linhas da variável 193 foi filtrado antes de chegar à tela.
    assert sum(1 for c in estado.chamadas_grid if c["IdVariavel"] == 193) == 4  # 2 regras x (intermediária + final)
    modelos = {r["id"]: r["nome"] for r in estado.regras["Subscrição"]}
    assert modelos[119978] == "Regra Modelo - Renovação Ituran Compreensiva"
    assert modelos[555] == "Regra antiga que não pode ser alterada"
    assert not (pasta / "trace.zip").exists()  # trace só é guardado quando dá erro


def test_para_na_regra_com_erro_e_guarda_print(ambiente_robo):
    estado, cfg = ambiente_robo

    pasta = _preparar(cfg, {"Módulo Subscrição": [
        linha_subs("R_OK_1", **{"CodParceiro Exclusão (Categórica)": 10}),
        linha_subs("R_FALHA", **{"CodParceiro Exclusão (Categórica)": 77}),  # 77 não existe no grid
        linha_subs("R_DEPOIS", **{"CodParceiro Exclusão (Categórica)": 10}),
    ]})

    assert rodar(pasta, cfg) == 5
    status = ler_json(pasta / "status.json")
    assert status["fase"] == "erro" and "regra 2" in status["mensagem"]
    assert [r["status"] for r in status["regras"]] == ["confirmada", "erro", "não executada"]
    assert (pasta / status["regras"][1]["print"]).exists()
    assert (pasta / "trace.zip").exists()
    assert "indicadores_lista" in (pasta / "erros" / "regra_002.html").read_text(encoding="utf-8")
    # O trace grava o que é digitado: só pode começar depois do login (sem a senha).
    import zipfile
    with zipfile.ZipFile(pasta / "trace.zip") as z:
        assert not any(b"segredo" in z.read(n) for n in z.namelist())
    assert not (pasta / "html").exists()  # passo a passo só com GRAVAR_HTML=true
    assert [s["nome"] for s in estado.salvas] == ["R_OK_1"]


def test_gravar_html_salva_cada_passo(ambiente_robo):
    import dataclasses

    _, cfg = ambiente_robo
    cfg = dataclasses.replace(cfg, gravar_html=True)
    pasta = _preparar(cfg, {"Módulo Subscrição": [linha_subs("R1", **{"CodParceiro Exclusão (Categórica)": 10})]})
    assert rodar(pasta, cfg) == 0, ler_json(pasta / "status.json")
    nomes = sorted(p.name for p in (pasta / "html" / "regra_001").glob("*.html"))
    for passo in ("modulo_subscricao", "lista_pronta", "apos_copiar", "regra_aberta",
                  "variavel_1_229", "antes_de_salvar", "apos_salvar"):
        assert any(passo in n for n in nomes), (passo, nomes)
    assert (pasta / "html" / "regra_000" / "01_apos_login.html").exists()


def test_retomar_a_partir_da_regra(ambiente_robo):
    estado, cfg = ambiente_robo

    pasta = _preparar(cfg, {"Módulo Subscrição": [
        linha_subs("R_JA_FEITA", **{"CodParceiro Exclusão (Categórica)": 10}),
        linha_subs("R_SEGUNDA", **{"CodParceiro Exclusão (Categórica)": 10}),
    ]}, inicio=2)
    assert rodar(pasta, cfg) == 0
    status = ler_json(pasta / "status.json")
    assert [r["status"] for r in status["regras"]] == ["pulada", "confirmada"]
    assert [s["nome"] for s in estado.salvas] == ["R_SEGUNDA"]


def test_login_errado_para_com_mensagem(ambiente_robo, monkeypatch):
    _, _ = ambiente_robo
    monkeypatch.setenv("IPOP_SENHA", "errada")
    monkeypatch.setenv("TIMEOUT_PADRAO_MS", "5000")
    from ipop.config import Config
    from ipop.pages import login_home

    original = login_home.LoginPage.entrar
    monkeypatch.setattr(login_home.LoginPage, "entrar", lambda self, u, s, timeout=60_000: original(self, u, s, timeout=5_000))
    cfg = Config()
    pasta = _preparar(cfg, {"Módulo Subscrição": [linha_subs("R1", **{"CodParceiro Exclusão (Categórica)": 10})]})
    assert rodar(pasta, cfg) == 1
    status = ler_json(pasta / "status.json")
    assert "Login no IPOP não concluiu" in status["mensagem"]
    assert [r["status"] for r in status["regras"]] == ["não executada"]


def test_trava_nao_altera_regra_que_nao_e_copia(ambiente_robo, monkeypatch):
    """Se a cópia falhar e a tela abrir o próprio modelo, o robô para sem salvar."""
    estado, cfg = ambiente_robo
    from ipop.pages.lista_regras import ListaRegrasPage

    monkeypatch.setattr(ListaRegrasPage, "copiar_selecionada", lambda self: None)
    pasta = _preparar(cfg, {"Módulo Subscrição": [linha_subs("R1", **{"CodParceiro Exclusão (Categórica)": 10})]})
    assert rodar(pasta, cfg) == 5
    status = ler_json(pasta / "status.json")
    assert "esperava 1 'Cópia de" in status["regras"][0]["detalhe"]
    assert estado.salvas == []


def test_edita_a_copia_nova_e_nao_uma_copia_antiga(ambiente_robo):
    """Uma "Cópia de ..." antiga do mesmo modelo já está na lista: o robô edita só a nova."""
    estado, cfg = ambiente_robo
    antiga = {"id": 777, "nome": "Cópia de Regra Modelo - Renovação Ituran Compreensiva"}
    outra = {"id": 778, "nome": "Cópia de Regra Modelo - Renovação Ituran Não Compreensiva"}
    estado.regras["Subscrição"][:0] = [antiga, outra]
    pasta = _preparar(cfg, {"Módulo Subscrição": [linha_subs("R1", **{"CodParceiro Exclusão (Categórica)": 10})]})
    assert rodar(pasta, cfg) == 0, ler_json(pasta / "status.json")
    assert [s["id"] for s in estado.salvas] == [900001]
    assert antiga["nome"].startswith("Cópia de") and outra["nome"].startswith("Cópia de")


def test_codigo_do_agrupamento_no_lugar_do_nome(ambiente_robo):
    """A planilha traz o IdDominio (700001) do agrupamento: o robô seleciona a linha pelo código."""
    estado, cfg = ambiente_robo
    pasta = _preparar(cfg, {"Módulo Subscrição": [
        linha_subs("R_COD", **{"NroCpfCnpj Inclusão (Categórica)": 700001})]})
    assert rodar(pasta, cfg) == 0, ler_json(pasta / "status.json")
    (salva,) = estado.salvas
    assert salva["arvore"] == [
        {"acao": "igualdade", "grupo": "4", "variavel": "193", "valores": ["R_ITURAN_DEZ26_C_Subs_Agravo_58%"]}
    ]


def test_janela_depois_do_salvar_para_sem_responder(ambiente_robo):
    """Se o IPOP abrir uma janela depois do Salvar, o robô registra o texto e para sem clicar nela."""
    estado, cfg = ambiente_robo
    estado.janela_ao_salvar = "Deseja realmente salvar a regra?"
    pasta = _preparar(cfg, {"Módulo Subscrição": [linha_subs("R1", **{"CodParceiro Exclusão (Categórica)": 10})]})
    assert rodar(pasta, cfg) == 5
    status = ler_json(pasta / "status.json")
    assert "Deseja realmente salvar a regra?" in status["regras"][0]["detalhe"]
    assert estado.salvas == []
