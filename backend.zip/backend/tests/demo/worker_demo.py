"""Worker de demonstração: SQL Server e rede trocados por imitações (só para desenvolvimento local)."""
import os

import ipop.robo
import ipop.services.enriquecedor_sql
from ipop.conectividade import Checagem
from tests.test_navegador_ponta_a_ponta import SQLPorValor

ipop.services.enriquecedor_sql.EnriquecedorSQL = SQLPorValor
ipop.robo.verificar = lambda cfg, amb: [Checagem("IPOP (demo)", os.environ["IPOP_URL_HML"], True, "ok")]

import ipop.worker as worker  # noqa: E402

worker.verificar = lambda cfg, amb: [Checagem("IPOP (demo)", os.environ["IPOP_URL_HML"], True, "Conectou (demo)."),
                                     Checagem("SQL Server", "imitação", True, "Conectou (demo).")]
raise SystemExit(worker.main())
