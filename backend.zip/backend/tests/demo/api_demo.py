"""API de demonstração que também serve o build do Angular (no compose quem faz isso é o nginx)."""
import os
from pathlib import Path

import uvicorn
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.main import app

DIST = Path(os.environ["FRONTEND_DIST"])
app.mount("/assets-estaticos", StaticFiles(directory=DIST), name="estaticos")


@app.get("/{caminho:path}", include_in_schema=False)
def spa(caminho: str):
    alvo = DIST / caminho
    if caminho and alvo.is_file():
        return FileResponse(alvo)
    return FileResponse(DIST / "index.html")


uvicorn.run(app, host="127.0.0.1", port=int(os.environ.get("PORTA", "8090")), log_level="warning")
