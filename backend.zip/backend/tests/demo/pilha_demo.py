"""Sobe Postgres temporário + S3 (moto) + IPOP falso + API + worker. Uso: python -m tests.demo.pilha_demo"""
import os
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

from tests.infra_local import PostgresTemporario, achar_pg, iniciar_s3
from tests.ipop_falso.servidor import EstadoIPOP, criar_servidor
from tests.test_navegador_ponta_a_ponta import _grids

RAIZ = Path(__file__).resolve().parents[2]
pg = PostgresTemporario(achar_pg())
url_pg = pg.iniciar()
s3, url_s3 = iniciar_s3()
estado = EstadoIPOP(_grids())
ipop = criar_servidor(estado)
threading.Thread(target=ipop.serve_forever, daemon=True).start()

env = {**os.environ,
       "DATABASE_URL": url_pg, "S3_ENDPOINT": url_s3, "S3_ACCESS_KEY": "demo", "S3_SECRET_KEY": "demo",
       "S3_BUCKET": "robo-ipop", "WEB_USUARIO": "renata", "WEB_SENHA": "demo",
       "IPOP_URL_HML": f"http://127.0.0.1:{ipop.server_address[1]}/login", "IPOP_USUARIO": "robo", "IPOP_SENHA": "segredo",
       "SQL_SERVIDOR": "demo", "SQL_USUARIO": "demo", "SQL_SENHA": "demo", "WORKER_NOME": "worker-demo",
       "FRONTEND_DIST": str(RAIZ.parent / "frontend/dist/ipop-cadastro-regras/browser"), "PYTHONPATH": str(RAIZ)}
api = subprocess.Popen([sys.executable, "-m", "tests.demo.api_demo"], cwd=RAIZ, env=env)
time.sleep(3)
worker = subprocess.Popen([sys.executable, "-m", "tests.demo.worker_demo"], cwd=RAIZ, env=env)
print(f"PRONTO http://127.0.0.1:8090  (usuário renata / senha demo)  postgres={url_pg}", flush=True)


def sair(*_):
    for p in (worker, api):
        p.send_signal(signal.SIGTERM)
    for p in (worker, api):
        try:
            p.wait(timeout=20)
        except subprocess.TimeoutExpired:
            p.kill()
    s3.stop(); pg.parar(); sys.exit(0)


signal.signal(signal.SIGTERM, sair)
signal.signal(signal.SIGINT, sair)
while True:
    time.sleep(1)
    if api.poll() is not None or worker.poll() is not None:
        print("Um processo caiu:", api.poll(), worker.poll(), flush=True)
        sair()
