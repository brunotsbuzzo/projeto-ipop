"""Fluxo inteiro como no docker-compose: API -> bucket/Postgres -> worker -> IPOP (falso) no Chromium."""
from __future__ import annotations

import importlib
import io
import threading

import pandas as pd
import pytest
from fastapi.testclient import TestClient

from ipop.conectividade import Checagem

from .conftest import gravar_pedido, linha_subs
from .ipop_falso.servidor import EstadoIPOP, criar_servidor
from .test_navegador_ponta_a_ponta import SQLPorValor, _grids

pytest.importorskip("playwright.sync_api")
AUTH = ("operador", "senha-web")


@pytest.fixture
def ambiente(config_infra, monkeypatch):
    estado = EstadoIPOP(_grids())
    servidor = criar_servidor(estado)
    threading.Thread(target=servidor.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{servidor.server_address[1]}/login"
    monkeypatch.setenv("IPOP_URL_HML", url)
    monkeypatch.setenv("IPOP_USUARIO", "robo")
    monkeypatch.setenv("IPOP_SENHA", "segredo")
    monkeypatch.setattr("ipop.robo.verificar", lambda cfg, amb: [Checagem("IPOP", url, True, "ok")])
    monkeypatch.setattr("ipop.services.enriquecedor_sql.EnriquecedorSQL", SQLPorValor)

    import app.main as api
    api = importlib.reload(api)
    from ipop.config import Config
    from ipop.infra.armazenamento import Armazenamento
    from ipop.infra.db import Repositorio
    from ipop.worker import Worker

    with TestClient(api.app) as cliente:
        cfg = Config()
        repo = Repositorio(cfg)
        worker = Worker(cfg, repo, Armazenamento(cfg))
        yield cliente, worker, estado
        repo.fechar()
    servidor.shutdown()


def _planilha(tmp_path, linhas_subs, oferta=True) -> bytes:
    abas = {"Módulo Subscrição": linhas_subs}
    if oferta:
        abas["Módulo Oferta"] = [{"Nome Agrupamento": "R_ITURAN_DEZ26_Oferta_6%", "Fator (%)": 6,
                                  "Data Inicial": pd.Timestamp("2026-11-01"), "Data Final": pd.Timestamp("2026-12-31")}]
    return gravar_pedido(tmp_path / "pedido.xlsx", abas).read_bytes()


def _validar(cliente, worker, conteudo: bytes) -> dict:
    r = cliente.post("/api/validacoes", auth=AUTH,
                     files={"arquivo": ("ModeloRegras-SubseOferta.xlsx", io.BytesIO(conteudo))})
    assert r.status_code == 201, r.text
    assert cliente.get(f"/api/validacoes/{r.json()['id']}", auth=AUTH).json()["status"] == "validando"
    assert worker.processar_uma("validacao")
    return cliente.get(f"/api/validacoes/{r.json()['id']}", auth=AUTH).json()


def _enviar(cliente, validacao_id: str):
    return cliente.post("/api/solicitacoes", auth=AUTH, json={
        "validacao_id": validacao_id, "titulo": "Renovação Ituran — carteira de novembro",
        "lote_id": "784530", "solicitante": "Renata Mendes", "categoria": "Renovação Ituran"})


def test_validacao_envio_e_cadastro(ambiente, tmp_path):
    cliente, worker, estado = ambiente
    assert cliente.get("/api/config", auth=AUTH).json()["categorias"] == ["Renovação Ituran", "Frota"]
    assert cliente.get("/api/solicitacoes").status_code == 401

    v = _validar(cliente, worker, _planilha(tmp_path, [
        linha_subs("R_ITURAN_DEZ26_C_Subs_Agravo_58%", fator=1.58, **{
            "CodParceiro Exclusão (Categórica)": 10,
            "NroCpfCnpj Inclusão (Categórica)": "R_ITURAN_DEZ26_C_Subs_Agravo_58%"}),
        linha_subs("R_ESTUDO_IDADE_DESC_10%", fator=0.9, modelo="Não se aplica",
                   **{"IdadeSegurado Inclusão (Contínua)": "18 a 25; 26 a 40"}),
    ]))
    assert v["status"] == "valido", v
    assert v["resumo"] == {"subscricao": 2, "oferta": 1, "total": 3, "cadastradas": 0}
    assert v["erros"] == []
    assert any("sem regra-modelo" in a["mensagem"] for a in v["avisos"])
    linha = v["regras"][0]
    assert (linha["fator_original"], linha["modelo"], linha["negocio"]) == ("1.58", "Ituran Compreensiva", "Automóvel")
    assert linha["variaveis"][0] == {"nome": "Código Parceiro", "codigo": 229, "acao": "Exclusão", "valores": ["10"]}
    assert v["regras"][1]["variaveis"][0]["valores"] == ["18 a 25", "26 a 40"]
    assert estado.salvas == []  # validar não abre o IPOP

    r = _enviar(cliente, v["id"])
    assert r.status_code == 201, r.text
    s = r.json()
    assert s["status"] == {"codigo": "recebida", "rotulo": "Recebida", "tag": "info"}
    assert _enviar(cliente, v["id"]).status_code == 409  # a mesma planilha não é enviada duas vezes

    lista = cliente.get("/api/solicitacoes", auth=AUTH, params={"busca": "784530"}).json()
    assert [i["lote_id"] for i in lista] == ["784530"]
    assert cliente.get("/api/solicitacoes", auth=AUTH, params={"status": "concluida"}).json() == []

    assert worker.processar_uma("cadastro")
    d = cliente.get(f"/api/solicitacoes/{s['id']}", auth=AUTH).json()
    assert d["status"]["codigo"] == "concluida", d["mensagem"]
    assert [r["status"] for r in d["regras"]] == ["confirmada"] * 3
    assert d["resumo"]["cadastradas"] == 3
    assert [e["titulo"] for e in d["eventos"]] == ["Concluída", "Cadastrando no IPOP", "Dados conferidos", "Recebida"]
    assert [x["nome"] for x in estado.salvas] == [
        "R_ITURAN_DEZ26_C_Subs_Agravo_58%", "R_ESTUDO_IDADE_DESC_10%", "R_ITURAN_DEZ26_Oferta_6%"]
    arquivo = cliente.get(d["arquivo"]["url"], auth=AUTH)
    assert arquivo.status_code == 200 and arquivo.content[:2] == b"PK"
    assert "Regra 1/3" in cliente.get(f"/api/solicitacoes/{s['id']}/log", auth=AUTH).text


def test_parada_no_erro_e_retomada(ambiente, tmp_path):
    cliente, worker, estado = ambiente
    v = _validar(cliente, worker, _planilha(tmp_path, [
        linha_subs("R_OK", **{"CodParceiro Exclusão (Categórica)": 10}),
        linha_subs("R_FALHA", **{"CodParceiro Exclusão (Categórica)": 77}),  # 77 não está no IPOP falso
        linha_subs("R_DEPOIS", **{"CodParceiro Exclusão (Categórica)": 10}),
    ], oferta=False))
    assert v["status"] == "valido"
    assert any("77 não está nas tabelas do IPOP" in a["mensagem"] for a in v["avisos"])
    s = _enviar(cliente, v["id"]).json()

    assert worker.processar_uma("cadastro")
    d = cliente.get(f"/api/solicitacoes/{s['id']}", auth=AUTH).json()
    assert d["status"] == {"codigo": "erro", "rotulo": "Parou na regra 2", "tag": "error"}
    assert [r["status"] for r in d["regras"]] == ["confirmada", "erro", "não executada"]
    assert d["pode_retomar"] and d["retomar_de"] == 2 and not d["pode_cancelar"]
    assert d["eventos"][0]["titulo"] == "Parou na regra 2"
    print_ = cliente.get(d["regras"][1]["print_url"], auth=AUTH)
    assert print_.status_code == 200 and print_.content[:4] == b"\x89PNG"

    # O cadastro do valor 77 foi corrigido no IPOP: a pessoa clica em "Retomar da regra 2".
    estado.grids[229].append({"IdDominio": 236900, "Valor": "77", "Dominio": "Novo parceiro"})
    r = cliente.post(f"/api/solicitacoes/{s['id']}/retomar", auth=AUTH, json={})
    assert r.status_code == 200 and r.json()["status"]["codigo"] == "recebida"
    assert worker.processar_uma("cadastro")
    d = cliente.get(f"/api/solicitacoes/{s['id']}", auth=AUTH).json()
    assert d["status"]["codigo"] == "concluida", d["mensagem"]
    assert [r["status"] for r in d["regras"]] == ["confirmada"] * 3
    assert [x["nome"] for x in estado.salvas] == ["R_OK", "R_FALHA", "R_DEPOIS"]  # R_OK não foi criada de novo
    assert "Retomada da regra 2" in [e["titulo"] for e in d["eventos"]]


def test_planilha_com_erros_nao_pode_ser_enviada(ambiente, tmp_path):
    cliente, worker, estado = ambiente
    v = _validar(cliente, worker, _planilha(tmp_path, [
        linha_subs("R_BOA", **{"CodParceiro Exclusão (Categórica)": 10}),
        {**linha_subs("R_DATA"), "Data inicial": pd.Timestamp("2026-11-30"), "Data final": pd.Timestamp("2026-11-01")},
        linha_subs("R_FATOR", fator="1,1O", modelo="Frota 131"),
    ], oferta=False))
    assert v["status"] == "com_erros"
    assert {(e["linha"], e["campo"]) for e in v["erros"]} == {(3, "vigencia"), (4, "fator"), (4, "modelo")}
    assert v["regras"][2]["campos_com_erro"] == ["fator", "modelo"]
    assert v["regras"][2]["fator_original"] == "1,1O"
    assert _enviar(cliente, v["id"]).status_code == 409
    assert cliente.post("/api/validacoes", auth=AUTH, files={"arquivo": ("x.csv", b"a;b")}).status_code == 422
    assert cliente.post("/api/validacoes", auth=AUTH, files={"arquivo": ("x.xlsx", b"nao e zip")}).status_code == 422
    modelo = cliente.get("/api/modelo-planilha", auth=AUTH)
    assert modelo.status_code == 200 and modelo.content[:2] == b"PK"
