"""Servidor HTTP local que serve o IPOP falso e guarda o que o robô salvou."""
from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HTML = (Path(__file__).parent / "app.html").read_bytes()


class EstadoIPOP:
    def __init__(self, grids: dict[int, list[dict]]):
        self.trava = threading.Lock()
        self.grids = grids
        self.chamadas_grid: list[dict] = []
        self.salvas: list[dict] = []
        # Texto de uma janela (modal) que o IPOP abre depois do Salvar, para testes.
        self.janela_ao_salvar: str | None = None
        self.proximo_id = 900001
        self.regras = {
            "Subscrição": [
                {"id": 119978, "nome": "Regra Modelo - Renovação Ituran Compreensiva"},
                {"id": 119979, "nome": "Regra Modelo - Renovação Ituran Não Compreensiva"},
                {"id": 555, "nome": "Regra antiga que não pode ser alterada"},
            ],
            "Oferta": [{"id": 139278, "nome": "Regra Modelo Oferta Ituran"}],
        }


def criar_servidor(estado: EstadoIPOP) -> ThreadingHTTPServer:
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def _json(self, dados, codigo=200):
            corpo = json.dumps(dados).encode()
            self.send_response(codigo)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(corpo)))
            self.end_headers()
            self.wfile.write(corpo)

        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(HTML)

        def do_POST(self):
            tamanho = int(self.headers.get("Content-Length") or 0)
            dados = json.loads(self.rfile.read(tamanho) or b"{}")
            with estado.trava:
                if self.path == "/api/login":
                    return self._json({"ok": dados.get("usuario") == "robo" and dados.get("senha") == "segredo"})
                if self.path == "/api/regras":
                    return self._json({"regras": estado.regras[dados["modulo"]]})
                if self.path == "/api/copiar":
                    origem = next(r for r in estado.regras[dados["modulo"]] if r["id"] == dados["id"])
                    nova = {"id": estado.proximo_id, "nome": f"Cópia de {origem['nome']}"}
                    estado.proximo_id += 1
                    estado.regras[dados["modulo"]].insert(0, nova)
                    return self._json({"regras": estado.regras[dados["modulo"]], "nova": nova["id"]})
                if self.path == "/api/salvar":
                    if estado.janela_ao_salvar:  # o IPOP pede confirmação: nada é salvo ainda
                        return self._json({"janela": estado.janela_ao_salvar})
                    estado.salvas.append(dados)
                    lista = estado.regras[dados["modulo"]]
                    alvo = next((r for r in lista if r["id"] == dados["id"]), None)
                    if alvo is None:
                        alvo = {"id": estado.proximo_id}
                        estado.proximo_id += 1
                        lista.insert(0, alvo)
                    alvo["nome"] = dados["nome"]
                    return self._json({"ok": True})
                if self.path.endswith("/RecuperaGridIndicadores"):
                    estado.chamadas_grid.append(dados)
                    if dados.get("Tentativa") == 1:
                        return self._json({"Grid": None, "Total": 0})
                    linhas = estado.grids.get(int(dados["IdVariavel"]), [])
                    return self._json({"Grid": linhas, "Total": len(linhas)})
            self._json({"erro": "rota desconhecida"}, 404)

    return ThreadingHTTPServer(("127.0.0.1", 0), Handler)
