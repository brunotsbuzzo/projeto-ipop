import pandas as pd
import pytest

from ipop.models.regra import RegraAgravo, RegraDesconto, RegraEngenhariaReversa, RegraOferta, RegraRecusa
from ipop.services.construtor_regras import ConstrutorRegras, ErroValidacao, criar_regra
from ipop.services.leitor_pedido import LeitorDeRegrasExcel

from .conftest import SQLFalso, gravar_pedido, linha_subs

APOIO = {"Tabela de variáveis": [{"CodVariavel": 1, "Variável DW": "x"}], "RegrasModelo": [{"Nome da regra": "a", "ID": 1}],
         "ListaModelosDeRegras": [{"Modelo": "x"}], "VariaveisAcao": [{"Var": "y"}]}


def construir(config, caminho, sql=None):
    c = ConstrutorRegras(config, caminho, fabrica_enriquecedor=lambda _c: sql or SQLFalso())
    return c, c.executar()


# ---------- leitura ----------
def test_ignora_abas_de_apoio_e_aceita_modulo_de_subscricao(tmp_path):
    caminho = gravar_pedido(tmp_path / "p.xlsx", {
        "Módulo de Subscrição": [linha_subs("R1", **{"CodParceiro Exclusão (Categórica)": 10})],
        **APOIO,
    })
    leitor = LeitorDeRegrasExcel(str(caminho))
    regras = leitor.ler()
    assert len(regras) == 1
    assert regras[0]["modulo"] == "Subscrição"  # antes virava "de Subscrição"
    assert set(leitor.abas_ignoradas) == set(APOIO)


def test_aceita_aba_sem_nome_de_modulo_quando_tem_as_colunas(tmp_path):
    caminho = gravar_pedido(tmp_path / "p.xlsx", {"Planilha1": [linha_subs("R1")]})
    assert [r["nome_regra"] for r in LeitorDeRegrasExcel(str(caminho)).ler()] == ["R1"]


def test_sem_aba_de_regras_da_erro_claro(tmp_path):
    caminho = gravar_pedido(tmp_path / "p.xlsx", APOIO)
    with pytest.raises(ValueError, match="Nenhuma aba de regras"):
        LeitorDeRegrasExcel(str(caminho)).ler()


def test_variaveis_categoricas_continuas_e_colunas_vazias(tmp_path):
    linhas = [
        linha_subs("R1", **{
            "CodParceiro Exclusão (Categórica)": 10,
            "IdadeSegurado Inclusão (Contínua)": "18 a 25; 26 a 40",
            "Clique aqui escolha a Variável 8": "ignorar",
        }),
        linha_subs("R2", **{"CodParceiro Exclusão (Categórica)": None, "IdadeSegurado Inclusão (Contínua)": None}),
        {c: None for c in linha_subs("x")},  # linha em branco no fim
    ]
    regras = LeitorDeRegrasExcel(str(gravar_pedido(tmp_path / "p.xlsx", {"Módulo Subscrição": linhas}))).ler()
    assert len(regras) == 2
    v1, v2 = regras[0]["variaveis"]
    assert v1 == {"nome_dw": "CodParceiro", "acao": "exclusão", "tipo": "categórica", "valores": ["10"]}
    assert v2 == {"nome_dw": "IdadeSegurado", "acao": "inclusão", "tipo": "contínua", "valores": [(18, 25), (26, 40)]}
    assert regras[1]["variaveis"] == []
    assert regras[0]["data_inicial"] == "2026-10-31" and regras[0]["linha_planilha"] == 2


def test_numero_inteiro_nao_vira_ponto_zero(tmp_path):
    # Com uma célula vazia, o pandas lê a coluna como float: 10 -> 10.0
    linhas = [linha_subs("R1", **{"CodParceiro Exclusão (Categórica)": 10}),
              linha_subs("R2", **{"CodParceiro Exclusão (Categórica)": None})]
    regras = LeitorDeRegrasExcel(str(gravar_pedido(tmp_path / "p.xlsx", {"Módulo Subscrição": linhas}))).ler()
    assert regras[0]["variaveis"][0]["valores"] == ["10"]


def test_faixa_invalida_para_tudo(tmp_path):
    caminho = gravar_pedido(tmp_path / "p.xlsx", {
        "Módulo Subscrição": [linha_subs("R1", **{"IdadeSegurado Inclusão (Contínua)": "18-25"})]})
    with pytest.raises(ValueError, match="faixa inválida"):
        LeitorDeRegrasExcel(str(caminho)).ler()


def test_aba_oferta_cria_variavel_de_agrupamento(tmp_path):
    caminho = gravar_pedido(tmp_path / "p.xlsx", {"Módulo Oferta": [{
        "Nome Agrupamento": "R_ITURAN_DEZ26_Oferta_6%", "Fator (%)": 6,
        "Data Inicial": pd.Timestamp("2026-11-01"), "Data Final": pd.Timestamp("2026-12-31"),
        "Código Parceiro (Exclusão)": 10,
    }]})
    (regra,) = LeitorDeRegrasExcel(str(caminho)).ler()
    assert regra["modulo"] == "Oferta"
    assert regra["variaveis"][0] == {"nome_dw": "NroCpfCnpj", "acao": "inclusão", "tipo": "categórica",
                                     "valores": ["R_ITURAN_DEZ26_Oferta_6%"]}
    assert regra["variaveis"][1]["nome_dw"] == "CodParceiro"
    assert regra["variaveis"][1]["acao"] == "exclusão"


# ---------- fábrica (fator -> percentual) ----------
@pytest.mark.parametrize("tipo,fator,classe,percentual", [
    ("Agravo/Desconto", 1.58, RegraAgravo, 58.0),
    ("Agravo/Desconto", 0.90, RegraDesconto, -10.0),
    ("Agravo/Desconto", 1.0, RegraDesconto, 0.0),
    ("Não exibe prêmio", 1, RegraRecusa, 1.0),
    ("Ajuste por relac. IS", 1.2, RegraEngenhariaReversa, 1.2),
])
def test_fabrica_escolhe_classe_e_converte(tipo, fator, classe, percentual):
    dados = {"nome_aba": "Módulo Subscrição", "modulo": "Subscrição", "nome_regra": "R", "tipo_regra": tipo,
             "ajuste": fator, "data_inicial": "2026-01-01", "data_final": "2026-12-31", "variaveis": []}
    regra = criar_regra(dados)
    assert type(regra) is classe and regra.ajuste == percentual


def test_fabrica_oferta_mantem_percentual():
    dados = {"nome_aba": "Oferta", "modulo": "Oferta", "nome_regra": "R", "tipo_regra": "Oferta",
             "ajuste": 59, "data_inicial": "2026-01-01", "data_final": "2026-12-31", "variaveis": []}
    regra = criar_regra(dados)
    assert isinstance(regra, RegraOferta) and regra.ajuste == 59


# ---------- construtor e validação ----------
def test_fluxo_completo_resolve_modelo_variaveis_e_dominios(config, tmp_path):
    caminho = gravar_pedido(tmp_path / "p.xlsx", {"Módulo Subscrição": [linha_subs(
        "R_ITURAN_DEZ26_C_Subs_Agravo_58%", modelo="ituran compreensiva",
        **{"CodParceiro Exclusão (Categórica)": 10, "NroCpfCnpj Inclusão (Categórica)": "R_ITURAN_DEZ26_C_Subs_Agravo_58%"},
    )], **APOIO})
    _, (regra,) = construir(config, caminho)
    assert isinstance(regra, RegraAgravo) and regra.ajuste == 58.0
    assert regra.id_regra_modelo == 119978
    assert regra.nome_regra_copia_IPOP == "Cópia de Regra Modelo - Renovação Ituran Compreensiva"
    parceiro, cpf = regra.variaveis
    assert (parceiro.tipo_acao, parceiro.variavel.variavel_id, parceiro.variavel.grupo_variavel_id) == ("exclusão", "229", "4")
    assert parceiro.variavel.ids_dominio == ["500000"]
    assert cpf.variavel.variavel_id == "193"


def test_oferta_sem_modelo_usa_modelo_padrao(config, tmp_path):
    caminho = gravar_pedido(tmp_path / "p.xlsx", {"Oferta": [{
        "Nome Agrupamento": "R_OF_6%", "Fator (%)": 6, "Data Inicial": "2026-11-01", "Data Final": "2026-12-31"}]})
    _, (regra,) = construir(config, caminho)
    assert regra.id_regra_modelo == 139278 and regra.eh_oferta


def test_validacao_junta_todos_os_problemas(config, tmp_path):
    caminho = gravar_pedido(tmp_path / "p.xlsx", {"Módulo Subscrição": [
        linha_subs("R1", fator=None),
        linha_subs("R2", modelo="Modelo que não existe"),
        linha_subs("R3", **{"VariavelInventada Inclusão (Categórica)": "x"}),
        linha_subs("R4", tipo="Tipo estranho"),
        {**linha_subs("R5"), "Data inicial": pd.Timestamp("2027-01-01")},
    ]})
    with pytest.raises(ErroValidacao) as erro:
        construir(config, caminho)
    texto = "\n".join(erro.value.erros)
    assert "R1: Fator: coluna vazia" in texto
    assert "“Modelo que não existe” não está na lista oficial de modelos" in texto
    assert "“VariavelInventada” não está na tabela de variáveis do IPOP" in texto
    assert "“Tipo estranho” não é suportado" in texto
    assert "R5: Vigência: a data inicial (01/01/2027) é depois da data final (31/12/2026)" in texto
    assert len(erro.value.erros) == 5
    campos = {(p["linha"], p["campo"]) for p in erro.value.problemas if p["nivel"] == "erro"}
    assert campos == {(2, "fator"), (3, "modelo"), (4, "variaveis"), (5, "tipo"), (6, "vigencia")}


def test_variavel_sem_grupo_no_sql_impede_cadastro(config, tmp_path):
    class SemGrupo(SQLFalso):
        def enriquecer(self, regras):
            return regras  # SQL não devolveu nada

    caminho = gravar_pedido(tmp_path / "p.xlsx", {"Módulo Subscrição": [
        linha_subs("R1", **{"CodParceiro Exclusão (Categórica)": 10})]})
    with pytest.raises(ErroValidacao, match="sem grupo"):
        construir(config, caminho, sql=SemGrupo())


def test_nome_repetido_e_dominio_faltando_sao_so_avisos(config, tmp_path):
    caminho = gravar_pedido(tmp_path / "p.xlsx", {"Módulo Subscrição": [
        linha_subs("R1", **{"CodParceiro Exclusão (Categórica)": 10}),
        linha_subs("R1", fator=0.9, **{"CodParceiro Exclusão (Categórica)": 99}),
    ]})
    construtor, regras = construir(config, caminho, sql=SQLFalso(sem_dominio={"99"}))
    assert len(regras) == 2
    assert any("“R1” repetido (também na linha 2)" in a for a in construtor.avisos)
    assert any("Código Parceiro (229) · 99 não está nas tabelas do IPOP" in a for a in construtor.avisos)
    previa = construtor.previa()
    assert previa[0]["variaveis"][0] == {"nome": "Código Parceiro", "codigo": 229, "acao": "Exclusão", "valores": ["10"]}
    assert previa[0]["fator_original"] == "1.58" and previa[1]["fator"] == 0.9
    assert regras[1].variaveis[0].variavel.ids_dominio == []  # vai procurar pelo texto no grid
