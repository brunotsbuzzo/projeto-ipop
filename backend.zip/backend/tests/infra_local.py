"""Postgres e S3 locais para os testes de integração (pulados se não houver Postgres instalado)."""
from __future__ import annotations

import os
import shutil
import socket
import subprocess
import tempfile
import time
from pathlib import Path

PG_BINS = [Path("/usr/lib/postgresql/16/bin"), Path("/usr/lib/postgresql/17/bin"), Path("/usr/local/bin")]


def _porta_livre() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def achar_pg() -> Path | None:
    if os.getenv("TEST_DATABASE_URL"):
        return None
    for pasta in PG_BINS:
        if (pasta / "pg_ctl").exists():
            return pasta
    return None


class PostgresTemporario:
    """initdb + pg_ctl numa pasta temporária. Roda como 'postgres' se o teste estiver como root."""

    def __init__(self, bin_dir: Path):
        self.bin = bin_dir
        self.pasta = Path(tempfile.mkdtemp(prefix="pg-teste-"))
        self.porta = _porta_livre()
        self.como_postgres = os.geteuid() == 0

    def _rodar(self, *args: str) -> None:
        comando = [str(self.bin / args[0]), *args[1:]]
        if self.como_postgres:
            comando = ["su", "postgres", "-s", "/bin/sh", "-c", " ".join(f"'{a}'" for a in comando)]
        subprocess.run(comando, check=True, capture_output=True)

    def iniciar(self) -> str:
        if self.como_postgres:
            shutil.chown(self.pasta, "postgres")
        dados = self.pasta / "dados"
        self._rodar("initdb", "-D", str(dados), "-U", "teste", "--auth=trust", "-E", "UTF8")
        self._rodar("pg_ctl", "-D", str(dados), "-o", f"-p {self.porta} -k {self.pasta} -c listen_addresses=127.0.0.1",
                    "-l", str(self.pasta / "log"), "-w", "start")
        return f"postgresql://teste@127.0.0.1:{self.porta}/postgres"

    def parar(self) -> None:
        try:
            self._rodar("pg_ctl", "-D", str(self.pasta / "dados"), "-m", "immediate", "stop")
        finally:
            shutil.rmtree(self.pasta, ignore_errors=True)


def iniciar_s3() -> tuple[object, str]:
    from moto.server import ThreadedMotoServer
    porta = _porta_livre()
    servidor = ThreadedMotoServer(ip_address="127.0.0.1", port=porta, verbose=False)
    servidor.start()
    for _ in range(50):
        try:
            socket.create_connection(("127.0.0.1", porta), timeout=0.2).close()
            break
        except OSError:
            time.sleep(0.1)
    return servidor, f"http://127.0.0.1:{porta}"
