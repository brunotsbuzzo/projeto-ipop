from __future__ import annotations

import shutil
from pathlib import Path

import pandas as pd
import pytest

from ipop.config import RAIZ_PROJETO, Config

COLUNAS_SUBS = [
    "Negócio", "Data inicial", "Data final", "Nome da ação", "Tipo de regra", "Fator",
    "Modelos de regras", "Descrição do modelo de regra",
]


def linha_subs(nome, fator=1.58, tipo="Agravo/Desconto", modelo="Ituran Compreensiva", **variaveis):
    linha = {
        "Negócio": "Automóvel", "Data inicial": pd.Timestamp("2026-10-31"), "Data final": pd.Timestamp("2026-12-31"),
        "Nome da ação": nome, "Tipo de regra": tipo, "Fator": fator, "Modelos de regras": modelo,
        "Descrição do modelo de regra": "",
    }
    linha.update(variaveis)
    return linha


def gravar_pedido(caminho: Path, abas: dict[str, list[dict] | pd.DataFrame]) -> Path:
    with pd.ExcelWriter(caminho, engine="openpyxl") as escritor:
        for nome, linhas in abas.items():
            df = linhas if isinstance(linhas, pd.DataFrame) else pd.DataFrame(linhas)
            df.to_excel(escritor, sheet_name=nome, index=False)
    return caminho


class SQLFalso:
    """Imita o EnriquecedorSQL: todo valor categórico tem domínio, grupo 4."""

    def __init__(self, _config=None, sem_dominio: set[str] | None = None):
        self.sem_dominio = sem_dominio or set()

    def enriquecer(self, regras):
        for regra in regras:
            for var in regra["variaveis"]:
                if not var.get("id_variavel"):
                    continue
                var["grupo_variavel_id"] = [4, 5]
                if var["tipo"] == "categórica":
                    var["dominios"] = [
                        {"ID": 500000 + i, "VALOR": v, "DOMINIO": f"dom {v}"}
                        for i, v in enumerate(var["valores"]) if v not in self.sem_dominio
                    ]
        return regras


@pytest.fixture
def config(tmp_path, monkeypatch) -> Config:
    dados = tmp_path / "dados"
    shutil.copytree(RAIZ_PROJETO / "dados" / "tbl_dim", dados / "tbl_dim")
    for nome in ("IPOP_USUARIO", "IPOP_SENHA", "SQL_SERVIDOR", "SQL_USUARIO", "SQL_SENHA", "PERMITIR_PRODUCAO"):
        monkeypatch.delenv(nome, raising=False)
    monkeypatch.setenv("DADOS_DIR", str(dados))
    return Config()


# ---------- Postgres + S3 para os testes de integração ----------
@pytest.fixture(scope="session")
def pg_url():
    import os
    from .infra_local import PostgresTemporario, achar_pg
    if os.getenv("TEST_DATABASE_URL"):
        yield os.environ["TEST_DATABASE_URL"]
        return
    bin_dir = achar_pg()
    if bin_dir is None:
        pytest.skip("Postgres não instalado (defina TEST_DATABASE_URL para usar um existente).")
    pg = PostgresTemporario(bin_dir)
    url = pg.iniciar()
    yield url
    pg.parar()


@pytest.fixture(scope="session")
def s3_url():
    pytest.importorskip("moto")
    from .infra_local import iniciar_s3
    servidor, url = iniciar_s3()
    yield url
    servidor.stop()


@pytest.fixture
def config_infra(config, pg_url, s3_url, monkeypatch, request):
    """Config apontando para o Postgres/S3 de teste, com um schema e bucket só deste teste."""
    import re
    from ipop.config import Config
    sufixo = re.sub(r"[^a-z0-9]", "_", request.node.name.lower())[:40]
    for nome, valor in {
        "DATABASE_URL": pg_url, "DB_SCHEMA": f"t_{sufixo}",
        "S3_ENDPOINT": s3_url, "S3_ACCESS_KEY": "teste", "S3_SECRET_KEY": "teste",
        "S3_BUCKET": f"b-{sufixo.replace('_', '-')}"[:60].rstrip("-"),
        "WEB_USUARIO": "operador", "WEB_SENHA": "senha-web", "WORKER_NOME": "worker-teste",
        "SQL_SERVIDOR": "falso", "SQL_USUARIO": "u", "SQL_SENHA": "s",
    }.items():
        monkeypatch.setenv(nome, valor)
    return Config()
