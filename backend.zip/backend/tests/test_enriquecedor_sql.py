"""O enriquecedor usa parâmetros (?) e nunca monta valores dentro do SQL."""
from ipop.services.enriquecedor_sql import LOTE_PARAMETROS, EnriquecedorSQL


class CursorFalso:
    def __init__(self, banco):
        self.banco = banco
        self.description = []
        self._linhas = []

    def execute(self, sql, parametros):
        self.banco.chamadas.append((sql, list(parametros)))
        colunas, linhas = self.banco.responder(sql, parametros)
        self.description = [(c,) for c in colunas]
        self._linhas = linhas
        return self

    def fetchall(self):
        return self._linhas

    def close(self):
        pass


class BancoFalso:
    def __init__(self):
        self.chamadas = []

    def cursor(self):
        return CursorFalso(self)

    def close(self):
        pass

    def responder(self, sql, p):
        if "[var].[Variavel]" in sql:
            return ["IDVariavel", "FlagAgrupamento"], [(i, 1 if i == 193 else 0) for i in p]
        if "GrupoVariavelDetalhe" in sql:
            return ["IDVariavel", "IDGrupoVariavel"], [(i, g) for i in p for g in (1, 4)]
        if "VariavelAgrupada" in sql:
            return ["ID", "IDVariavelDominio", "VALOR"], [(9, i, "12345678900") for i in p]
        if "[var].[VariavelDominio]" in sql and "AND ID IN" in sql:
            # Consulta por código: só 398873 é um IdDominio de verdade.
            id_var, *codigos = p
            return ["ID", "IDVariavel", "VALOR", "DOMINIO"], [
                (c, id_var, "R_ITURAN_OUT26 _C_Oferta_12%", "R_ITURAN_OUT26 _C_Oferta_12%") for c in codigos if c == 398873
            ]
        if "[var].[VariavelDominio]" in sql:
            id_var, *valores = p
            if id_var == 193:
                valores = [v for v in valores if v not in ("398873", "777")]  # não são VALOR
            return ["ID", "IDVariavel", "VALOR", "DOMINIO"], [
                (id_var * 1000 + n, id_var, v, f"d{v}") for n, v in enumerate(valores) if v != "sem"
            ]
        raise AssertionError(sql)


def test_consultas_parametrizadas_e_injecao(config):
    banco = BancoFalso()
    regras = [{"variaveis": [
        {"nome_dw": "CodParceiro", "tipo": "categórica", "id_variavel": 229, "valores": ["10", "x' OR '1'='1", "sem"]},
        {"nome_dw": "NroCpfCnpj", "tipo": "categórica", "id_variavel": 193, "valores": ["R_GRUPO"]},
        {"nome_dw": "IdadeSegurado", "tipo": "contínua", "id_variavel": 201, "valores": [(18, 25)]},
    ]}]
    EnriquecedorSQL(config, conexao=banco).enriquecer(regras)

    for sql, _ in banco.chamadas:
        assert "'" not in sql, f"valor montado dentro do SQL: {sql}"
    parceiro, cpf, idade = regras[0]["variaveis"]
    assert parceiro["grupo_variavel_id"] == [1, 4]
    assert [d["VALOR"] for d in parceiro["dominios"]] == ["10", "x' OR '1'='1"]
    assert cpf["agrupados"] == [{"ID": 9, "VALOR": "12345678900"}]
    assert idade["grupo_variavel_id"] == [1, 4] and "dominios" not in idade


def test_lista_grande_e_dividida_em_lotes(config):
    banco = BancoFalso()
    valores = [str(i) for i in range(LOTE_PARAMETROS * 2 + 5)]
    regras = [{"variaveis": [{"nome_dw": "X", "tipo": "categórica", "id_variavel": 7, "valores": valores}]}]
    EnriquecedorSQL(config, conexao=banco).enriquecer(regras)
    consultas_dominio = [p for sql, p in banco.chamadas if "[var].[VariavelDominio]" in sql]
    assert len(consultas_dominio) == 3
    assert all(len(p) <= LOTE_PARAMETROS + 1 for p in consultas_dominio)
    assert len(regras[0]["variaveis"][0]["dominios"]) == len(valores)


def test_sem_variaveis_nao_conecta(config):
    class Explode:
        def cursor(self):
            raise AssertionError("não devia consultar")

    regras = [{"variaveis": [{"nome_dw": "X", "tipo": "categórica", "id_variavel": None, "valores": ["a"]}]}]
    assert EnriquecedorSQL(config, conexao=Explode()).enriquecer(regras) == regras


def test_string_de_conexao_usa_env(config, monkeypatch):
    monkeypatch.setenv("SQL_SERVIDOR", "sql.interno")
    monkeypatch.setenv("SQL_SENHA", "a;b}c")
    from ipop.config import Config
    texto = Config().string_conexao_sql()
    assert "SERVER=sql.interno,1433" in texto and "DATABASE=RosieRep" in texto
    assert "PWD={a;b}}c}" in texto


def test_codigo_digitado_no_lugar_do_texto(config):
    """398873 não é VALOR, mas é o IdDominio de um agrupamento: vira domínio e fica marcado para o aviso."""
    banco = BancoFalso()
    regras = [{"variaveis": [
        {"nome_dw": "NroCpfCnpj", "tipo": "categórica", "id_variavel": 193, "valores": ["398873", "777", "R_GRUPO"]},
    ]}]
    EnriquecedorSQL(config, conexao=banco).enriquecer(regras)
    cpf = regras[0]["variaveis"][0]
    dominio = {"ID": 398873, "VALOR": "R_ITURAN_OUT26 _C_Oferta_12%",
               "DOMINIO": "R_ITURAN_OUT26 _C_Oferta_12%", "CODIGO": "398873"}
    # O código confirmado pelo SQL vira um domínio normal (o robô seleciona pelo ID).
    assert [d["VALOR"] for d in cpf["dominios"]] == ["R_GRUPO", "R_ITURAN_OUT26 _C_Oferta_12%"]
    assert cpf["valores_que_sao_id"] == {"398873": dominio}
    consulta_id = [p for sql, p in banco.chamadas if "AND ID IN" in sql]
    assert consulta_id == [[193, 777, 398873]] or consulta_id == [(193, 777, 398873)]
