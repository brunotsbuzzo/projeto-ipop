import { ChangeDetectionStrategy, Component, input } from '@angular/core';

/** "Título de seção" do Figma: overline + divisor + detalhe à direita. */
@Component({
  selector: 'hdi-secao',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <h2 class="titulo">{{ titulo() }}</h2>
    <span class="divisor" aria-hidden="true"></span>
    @if (detalhe()) {<span class="detalhe">{{ detalhe() }}</span>}
    <ng-content />
  `,
  styles: `
    :host { display: flex; align-items: center; gap: var(--hdi-size-base); width: 100%; }
    .titulo { margin: 0; font: 600 12px/20px var(--hdi-font-family); letter-spacing: .72px; text-transform: uppercase; color: var(--hdi-color-text-base); white-space: nowrap; }
    .divisor { flex: 1; height: 1px; background: var(--hdi-color-border-secondary); min-width: 24px; }
    .detalhe { font: 400 12px/20px var(--hdi-font-family); color: var(--hdi-color-text-secondary); white-space: nowrap; }
  `,
})
export class Secao {
  readonly titulo = input.required<string>();
  readonly detalhe = input('');
}
