import { ChangeDetectionStrategy, Component, input } from '@angular/core';

import { dataHora } from '../data/formatos';
import { EventoAndamento } from '../data/modelos';

const COR: Record<string, string> = {
  recebida: 'var(--hdi-color-info-default)',
  retomada: 'var(--hdi-color-info-default)',
  dados_conferidos: 'var(--hdi-color-success-default)',
  cadastrando: 'var(--hdi-color-accent-default)',
  concluida: 'var(--hdi-color-success-default)',
  parou: 'var(--hdi-color-error-default)',
  erro: 'var(--hdi-color-error-default)',
  interrompida: 'var(--hdi-color-error-default)',
  cancelada: 'var(--hdi-color-text-tertiary)',
};

/** "Linha do tempo" do Figma: um ponto colorido por fase do robô, do mais recente para o mais antigo. */
@Component({
  selector: 'hdi-linha-do-tempo',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @for (e of eventos(); track $index) {
      <div class="evento">
        <span class="ponto" [style.background]="cor(e.tipo)" aria-hidden="true"></span>
        <div class="texto">
          <p class="titulo">{{ e.titulo }}</p>
          @if (e.detalhe) {<p class="detalhe">{{ e.detalhe }}</p>}
          <p class="quando">{{ dataHora(e.criado_em) }}{{ e.responsavel ? ' · ' + e.responsavel : '' }}</p>
        </div>
      </div>
    } @empty {
      <p class="detalhe">Nenhum evento ainda.</p>
    }
  `,
  styles: `
    :host { display: flex; flex-direction: column; gap: var(--hdi-size-base); padding: var(--hdi-size-lg); border: 1px solid var(--hdi-color-border-secondary); border-radius: var(--hdi-radius-card); background: var(--hdi-color-bg-container); }
    .evento { display: flex; gap: var(--hdi-size-sm); align-items: flex-start; }
    .ponto { width: 8px; height: 8px; border-radius: 50%; margin-top: 7px; flex: none; }
    .texto { display: flex; flex-direction: column; gap: var(--hdi-size-xxs); min-width: 0; }
    p { margin: 0; }
    .titulo { font: 500 14px/22px var(--hdi-font-family); color: var(--hdi-color-text-base); }
    .detalhe { font: 400 12px/20px var(--hdi-font-family); color: var(--hdi-color-text-base); }
    .quando { font: 400 12px/20px var(--hdi-font-family); color: var(--hdi-color-text-secondary); }
  `,
})
export class LinhaDoTempo {
  readonly eventos = input.required<EventoAndamento[]>();
  protected readonly dataHora = dataHora;
  protected cor(tipo: string) { return COR[tipo] ?? 'var(--hdi-color-text-tertiary)'; }
}
