import { ChangeDetectionStrategy, Component, input } from '@angular/core';

/** "Apresentação" do Figma: contexto (ponto verde + overline), título H2, descrição e ações à direita. */
@Component({
  selector: 'hdi-cabecalho-pagina',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="intro">
      <p class="contexto"><span class="ponto" aria-hidden="true"></span>IPOP · Cadastro de regras</p>
      <h1>{{ titulo() }}</h1>
      @if (descricao()) {<p class="descricao">{{ descricao() }}</p>}
    </div>
    <div class="acoes"><ng-content /></div>
  `,
  styles: `
    :host { display: flex; align-items: center; gap: var(--hdi-size-lg); width: 100%; }
    .intro { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: var(--hdi-size-xxs); }
    .contexto { margin: 0; display: flex; align-items: center; gap: var(--hdi-size-xs); font: 600 12px/20px var(--hdi-font-family); letter-spacing: .72px; text-transform: uppercase; color: var(--hdi-color-primary-text); }
    .ponto { width: 8px; height: 8px; border-radius: 50%; background: var(--hdi-color-primary-default); }
    h1 { margin: 0; font: 600 30px/38px var(--hdi-font-family); color: var(--hdi-color-primary-text-strong); }
    .descricao { margin: 0; font: 400 14px/22px var(--hdi-font-family); color: var(--hdi-color-text-secondary); }
    .acoes { display: flex; gap: var(--hdi-size-xs); flex: none; }
    .acoes:empty { display: none; }
  `,
})
export class CabecalhoPagina {
  readonly titulo = input.required<string>();
  readonly descricao = input('');
}
