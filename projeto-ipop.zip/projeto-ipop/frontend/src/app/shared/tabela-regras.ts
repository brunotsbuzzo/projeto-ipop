import { ChangeDetectionStrategy, Component, computed, effect, input, signal } from '@angular/core';
import { NzButtonModule } from 'ng-zorro-antd/button';

import { SITUACAO, fator, variavel, vigencia } from '../data/formatos';
import { RegraTela } from '../data/modelos';
import { StatusTag } from './status-tag';

type Modulo = 'Subscrição' | 'Oferta';

/**
 * "Tabela de regras" do Figma: abas por módulo do arquivo, uma linha por regra da planilha.
 * Linhas com erro ficam com fundo vermelho e o campo errado em vermelho.
 * Com [situacao]=true mostra a coluna Situação (andamento do robô) e o link para o print.
 */
@Component({
  selector: 'hdi-tabela-regras',
  imports: [StatusTag, NzButtonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="abas" role="tablist" aria-label="Abas do arquivo">
      @for (aba of abas(); track aba.modulo) {
        <button type="button" role="tab" class="aba" [class.ativa]="aba.modulo === ativa()"
                [attr.aria-selected]="aba.modulo === ativa()" (click)="escolhida.set(aba.modulo)">
          Módulo {{ aba.modulo }} ({{ aba.total }}){{ aba.erros ? ' · ' + aba.erros + (aba.erros === 1 ? ' erro' : ' erros') : '' }}
        </button>
      }
    </div>
    <div class="rolagem">
      <table>
        <thead>
          <tr>
            <th class="c-linha">Linha</th>
            @if (ativa() === 'Subscrição') {
              <th class="c-negocio">Negócio</th>
              <th class="c-vigencia">Vigência</th>
              <th class="c-nome">Nome da ação</th>
              <th class="c-fator">Fator</th>
              <th class="c-tipo">Tipo de regra</th>
            } @else {
              <th class="c-vigencia">Vigência</th>
              <th class="c-nome-largo">Nome do agrupamento</th>
              <th class="c-fator">Fator (%)</th>
            }
            <th class="c-modelo">Modelo de regra</th>
            <th>Variáveis</th>
            @if (situacao()) {<th class="c-situacao">Situação</th>}
          </tr>
        </thead>
        <tbody>
          @for (r of visiveis(); track r.n) {
            <tr [class.com-erro]="r.campos_com_erro.length || (situacao() && r.status === 'erro')">
              <td class="secundario">{{ r.linha }}</td>
              @if (ativa() === 'Subscrição') {
                <td>{{ r.negocio || '—' }}</td>
                <td [class.erro]="tem(r, 'vigencia')">{{ vigencia(r) }}</td>
                <td [class.erro]="tem(r, 'nome')">{{ r.nome || '—' }}</td>
                <td [class.erro]="tem(r, 'fator')">{{ fator(r) }}</td>
                <td [class.erro]="tem(r, 'tipo')">{{ r.tipo }}</td>
              } @else {
                <td [class.erro]="tem(r, 'vigencia')">{{ vigencia(r) }}</td>
                <td [class.erro]="tem(r, 'nome')">{{ r.nome || '—' }}</td>
                <td [class.erro]="tem(r, 'fator')">{{ fator(r) }}</td>
              }
              <td [class.erro]="tem(r, 'modelo')">{{ r.modelo }}</td>
              <td [class.erro]="tem(r, 'variaveis')">
                @for (v of r.variaveis; track $index) {<span class="variavel">{{ variavel(v) }}</span>}
                @empty {—}
              </td>
              @if (situacao()) {
                <td>
                  <div class="situacao">
                    <hdi-status-tag [status]="SITUACAO[r.status].tag" [label]="SITUACAO[r.status].rotulo" />
                    @if (r.print_url) {
                      <a nz-button nzType="link" nzSize="small" class="ver-print" [href]="r.print_url" target="_blank" rel="noopener">Ver print</a>
                    }
                  </div>
                </td>
              }
            </tr>
          } @empty {
            <tr><td [attr.colspan]="situacao() ? 9 : 8" class="vazio">Nenhuma regra neste módulo.</td></tr>
          }
        </tbody>
      </table>
    </div>
  `,
  styles: `
    :host { display: block; border: 1px solid var(--hdi-color-border-secondary); border-radius: var(--hdi-radius-card); background: var(--hdi-color-bg-container); overflow: hidden; }
    .abas { display: flex; gap: var(--hdi-size-lg); padding: var(--hdi-size-sm) var(--hdi-size-lg) 0; border-bottom: 1px solid var(--hdi-color-border-secondary); }
    .aba { all: unset; cursor: pointer; padding-bottom: var(--hdi-size-sm); border-bottom: 2px solid transparent; font: 400 14px/22px var(--hdi-font-family); color: var(--hdi-color-text-secondary); }
    .aba.ativa { border-bottom-color: var(--hdi-color-primary-default); color: var(--hdi-color-primary-text); font-weight: 500; }
    .aba:focus-visible { outline: 2px solid var(--hdi-color-primary-border); outline-offset: 2px; }
    .rolagem { overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; font: 400 12px/20px var(--hdi-font-family); color: var(--hdi-color-text-base); }
    th { background: var(--hdi-color-bg-fill-alter); font-weight: 600; text-align: left; }
    th, td { padding: var(--hdi-size-sm) 6px; border-bottom: 1px solid var(--hdi-color-border-secondary); vertical-align: top; }
    th:first-child, td:first-child { padding-left: var(--hdi-size-lg); }
    th:last-child, td:last-child { padding-right: var(--hdi-size-lg); }
    tbody tr:last-child td { border-bottom: 0; }
    tr.com-erro td { background: var(--hdi-color-error-bg); }
    td.erro { color: var(--hdi-color-error-default); font-weight: 500; }
    .secundario { color: var(--hdi-color-text-secondary); }
    .variavel { display: block; }
    .variavel + .variavel { margin-top: var(--hdi-size-xxs); }
    .c-linha { width: 48px; } .c-negocio { width: 88px; } .c-vigencia { width: 160px; } .c-nome { width: 128px; }
    .c-nome-largo { width: 240px; } .c-fator { width: 56px; } .c-tipo { width: 120px; } .c-modelo { width: 152px; }
    .c-situacao { width: 128px; }
    .situacao { display: flex; flex-direction: column; align-items: flex-start; gap: var(--hdi-size-xxs); }
    td { overflow-wrap: anywhere; }
    .c-vigencia, td:nth-child(3) { white-space: nowrap; }
    .ver-print { padding: 0; height: auto; font-size: 12px; line-height: 20px; }
    .vazio { text-align: center; color: var(--hdi-color-text-secondary); padding: var(--hdi-size-lg); }
  `,
})
export class TabelaRegras {
  readonly regras = input.required<RegraTela[]>();
  readonly situacao = input(false);
  protected readonly escolhida = signal<Modulo | null>(null);

  protected readonly abas = computed(() => {
    const lista: { modulo: Modulo; total: number; erros: number }[] = [];
    for (const modulo of ['Subscrição', 'Oferta'] as Modulo[]) {
      const regras = this.regras().filter(r => r.modulo === modulo);
      if (regras.length || modulo === 'Subscrição') {
        lista.push({ modulo, total: regras.length, erros: regras.reduce((s, r) => s + r.campos_com_erro.length, 0) });
      }
    }
    return lista;
  });
  protected readonly ativa = computed<Modulo>(() => this.escolhida() ?? this.abas().find(a => a.total)?.modulo ?? 'Subscrição');
  protected readonly visiveis = computed(() => this.regras().filter(r => r.modulo === this.ativa()));

  protected readonly SITUACAO = SITUACAO;
  protected readonly vigencia = vigencia;
  protected readonly fator = fator;
  protected readonly variavel = variavel;
  protected tem(r: RegraTela, campo: string) { return r.campos_com_erro.includes(campo); }

  constructor() {
    // Se a aba escolhida deixar de existir (nova planilha), volta para a primeira.
    effect(() => {
      const escolhida = this.escolhida();
      if (escolhida && !this.abas().some(a => a.modulo === escolhida)) this.escolhida.set(null);
    });
  }
}
