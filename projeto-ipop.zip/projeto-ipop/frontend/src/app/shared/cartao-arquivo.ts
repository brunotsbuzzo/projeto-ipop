import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { NzIconModule } from 'ng-zorro-antd/icon';

/** "Arquivo anexado" do Figma: ícone de planilha, nome, detalhes e, à direita, status e ações. */
@Component({
  selector: 'hdi-cartao-arquivo',
  imports: [NzIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <span nz-icon nzType="table" class="icone" aria-hidden="true"></span>
    <div class="dados">
      <p class="nome">{{ nome() }}</p>
      <p class="meta">{{ meta() }}</p>
    </div>
    <div class="direita"><ng-content /></div>
  `,
  styles: `
    :host { display: flex; align-items: center; gap: var(--hdi-size-sm); padding: var(--hdi-size-base); border: 1px solid var(--hdi-color-border-secondary); border-radius: var(--hdi-radius-card); background: var(--hdi-color-bg-container); }
    .icone { font-size: 24px; color: var(--hdi-color-primary-default); }
    .dados { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: var(--hdi-size-xxs); }
    .nome { margin: 0; font: 500 14px/22px var(--hdi-font-family); color: var(--hdi-color-text-base); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .meta { margin: 0; font: 400 12px/20px var(--hdi-font-family); color: var(--hdi-color-text-secondary); }
    .direita { display: flex; align-items: center; gap: var(--hdi-size-base); }
  `,
})
export class CartaoArquivo {
  readonly nome = input.required<string>();
  readonly meta = input('');
}
