import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { NzIconModule } from 'ng-zorro-antd/icon';

/** "Erros encontrados" (vermelho) e "Avisos" (amarelo) da pré-visualização e do detalhe. */
@Component({
  selector: 'hdi-caixa-problemas',
  imports: [NzIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { '[class.aviso]': "tipo() === 'aviso'", role: 'status' },
  template: `
    <p class="titulo">{{ titulo() }}</p>
    @for (item of itens(); track $index) {
      <p class="item">
        <span nz-icon [nzType]="tipo() === 'aviso' ? 'exclamation-circle' : 'close-circle'" nzTheme="fill" aria-hidden="true"></span>
        <span>{{ item }}</span>
      </p>
    }
  `,
  styles: `
    :host { display: flex; flex-direction: column; gap: var(--hdi-size-xs); padding: var(--hdi-size-base); border: 1px solid var(--hdi-color-error-border); border-radius: var(--hdi-radius-card); background: var(--hdi-color-error-bg); }
    :host(.aviso) { border-color: var(--hdi-color-warning-border); background: var(--hdi-color-warning-bg); }
    .titulo { margin: 0; font: 600 14px/22px var(--hdi-font-family); color: var(--hdi-color-text-base); }
    .item { margin: 0; display: flex; gap: var(--hdi-size-xs); align-items: flex-start; font: 400 12px/20px var(--hdi-font-family); color: var(--hdi-color-text-base); }
    .item .anticon { font-size: 16px; margin-top: 2px; color: var(--hdi-color-error-default); }
    :host(.aviso) .item .anticon { color: var(--hdi-color-accent-default); }
  `,
})
export class CaixaProblemas {
  readonly titulo = input.required<string>();
  readonly itens = input.required<string[]>();
  readonly tipo = input<'erro' | 'aviso'>('erro');
}
