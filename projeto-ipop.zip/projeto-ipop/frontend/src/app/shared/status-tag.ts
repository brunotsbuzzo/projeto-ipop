import { ChangeDetectionStrategy, Component, ViewEncapsulation, input } from '@angular/core';
import { NzTagModule } from 'ng-zorro-antd/tag';

import { TagStatus } from '../data/modelos';

/**
 * Status Tag do design system (Figma 533:58): <nz-tag> encapsulado em <hdi-status-tag [status]>.
 * Escolha a variante pelo significado: success, processing (amarelo, decisão HDI), warning, error, default, info.
 */
@Component({
  selector: 'hdi-status-tag',
  imports: [NzTagModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  template: `<nz-tag class="hdi-tag hdi-tag--{{ status() }}">@if (dot()) {<span class="hdi-tag__dot"></span>}{{ label() }}</nz-tag>`,
  styles: `
    hdi-status-tag { display: inline-flex; }
    .ant-tag.hdi-tag {
      display: inline-flex; align-items: center; gap: var(--hdi-size-xxs); margin: 0;
      padding: 0 var(--hdi-control-padding-inline-tag); border-radius: var(--hdi-radius-tag);
      font: 400 12px/20px var(--hdi-font-family); border: 1px solid; white-space: nowrap;
    }
    .hdi-tag__dot { width: 6px; height: 6px; border-radius: 50%; background: currentColor; flex: none; }
    .hdi-tag--success { background: var(--hdi-color-success-bg); border-color: var(--hdi-color-success-border); color: var(--hdi-color-success-text); }
    .hdi-tag--processing, .hdi-tag--warning { background: var(--hdi-color-warning-bg); border-color: var(--hdi-color-warning-border); color: var(--hdi-color-warning-text); }
    .hdi-tag--processing .hdi-tag__dot, .hdi-tag--warning .hdi-tag__dot { background: var(--hdi-color-warning-default); }
    .hdi-tag--error { background: var(--hdi-color-error-bg); border-color: var(--hdi-color-error-border); color: var(--hdi-color-error-text); }
    .hdi-tag--default { background: var(--hdi-color-bg-fill-alter); border-color: var(--hdi-color-border-base); color: var(--hdi-color-text-secondary); }
    .hdi-tag--default .hdi-tag__dot { background: var(--hdi-color-text-tertiary); }
    .hdi-tag--info { background: var(--hdi-color-info-bg); border-color: var(--hdi-color-info-border); color: var(--hdi-color-info-text); }
  `,
})
export class StatusTag {
  readonly status = input<TagStatus>('success');
  readonly label = input.required<string>();
  readonly dot = input(true);
}
