import { registerLocaleData } from '@angular/common';
import { provideHttpClient, withFetch } from '@angular/common/http';
import localePt from '@angular/common/locales/pt';
import { ApplicationConfig, LOCALE_ID, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter, withComponentInputBinding, withInMemoryScrolling } from '@angular/router';
import {
  ArrowRightOutline, BellOutline, CheckCircleFill, CheckOutline, CloseCircleFill, DownOutline,
  ExclamationCircleFill, InboxOutline, InfoCircleFill, LoadingOutline, PlusOutline, SearchOutline, TableOutline,
} from '@ant-design/icons-angular/icons';
import { provideNzConfig } from 'ng-zorro-antd/core/config';
import { pt_BR, provideNzI18n } from 'ng-zorro-antd/i18n';
import { provideNzIcons } from 'ng-zorro-antd/icon';

import { routes } from './app.routes';

registerLocaleData(localePt);

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes, withComponentInputBinding(), withInMemoryScrolling({ scrollPositionRestoration: 'top' })),
    provideHttpClient(withFetch()),
    { provide: LOCALE_ID, useValue: 'pt-BR' },
    provideNzI18n(pt_BR),
    // Ícones do design system (Icon/* no Figma = ícones Ant Design), registrados localmente.
    provideNzIcons([
      ArrowRightOutline, BellOutline, CheckCircleFill, CheckOutline, CloseCircleFill, DownOutline,
      ExclamationCircleFill, InboxOutline, InfoCircleFill, LoadingOutline, PlusOutline, SearchOutline, TableOutline,
    ]),
    // --hdi-color-primary-default; o NG-ZORRO gera hover/active a partir dela.
    provideNzConfig({ theme: { primaryColor: '#007337' }, message: { nzTop: 72 } }),
  ],
};
