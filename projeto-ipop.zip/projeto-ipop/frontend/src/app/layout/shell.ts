import { ChangeDetectionStrategy, Component, OnInit, inject } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { NzBadgeModule } from 'ng-zorro-antd/badge';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzInputModule } from 'ng-zorro-antd/input';

import { IpopApi } from '../data/api';
import { Migalhas } from './migalhas';

/** Moldura da plataforma (Figma: "Navegação lateral" + "Cabeçalho"). */
@Component({
  selector: 'hdi-shell',
  imports: [RouterOutlet, RouterLink, NzBadgeModule, NzIconModule, NzInputModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <aside class="lateral" aria-label="Navegação lateral">
      <div class="logo"><span class="marca">HDI</span><span>Plataforma</span></div>
      <p class="grupo">OPERAÇÕES</p>
      <nav class="menu">
        <a class="item" href="/">
          <span class="glifo" aria-hidden="true">⌂</span><span class="rotulo forte">Início</span></a>
        <a class="item ativo" routerLink="/cadastro-regras" aria-current="page">
          <span class="glifo" aria-hidden="true">▦</span><span class="rotulo">Aplicações</span></a>
        <span class="item"><span class="glifo" aria-hidden="true">🗎</span><span class="rotulo">Documentação</span></span>
        <span class="item"><span class="glifo" aria-hidden="true">▶</span><span class="rotulo">Execuções</span></span>
        <span class="item"><span class="glifo" aria-hidden="true">≡</span><span class="rotulo">Logs</span></span>
      </nav>
      <div class="rodape">
        <span class="item"><span aria-hidden="true">⚙</span><span>Config.</span></span>
        <div class="usuario">
          <span class="avatar" aria-hidden="true"></span>
          <div><p class="nome">{{ api.config()?.usuario ?? '…' }}</p><p class="papel">{{ ambiente() }}</p></div>
        </div>
      </div>
    </aside>

    <div class="principal">
      <header class="cabecalho">
        <nav class="migalhas" aria-label="Caminho de navegação">
          <span>plataforma</span><span class="sep">/</span><span>aplicações</span><span class="sep">/</span>
          <a routerLink="/cadastro-regras" class="atual">cadastro de regras (IPOP){{ migalhas.extra() ? ' / ' + migalhas.extra() : '' }}</a>
        </nav>
        <div class="utilidades">
          <nz-input-wrapper class="busca">
            <input nz-input placeholder="Buscar serviço, doc, ticket..." aria-label="Busca global" />
            <span nzInputSuffix nz-icon nzType="search"></span>
          </nz-input-wrapper>
          <nz-badge nzDot [nzColor]="'var(--hdi-color-accent-default)'" class="sino">
            <span nz-icon nzType="bell" aria-label="Notificações"></span>
          </nz-badge>
        </div>
      </header>
      @if (api.config() && !api.config()!.worker_online) {
        <div class="alerta-worker" role="status">
          O robô (worker) está fora do ar. As solicitações ficam na fila e são processadas quando ele voltar.
        </div>
      }
      <main class="conteudo"><router-outlet /></main>
    </div>
  `,
  styles: `
    :host { display: flex; min-height: 100vh; background: var(--hdi-color-bg-container); }
    .lateral { width: 256px; flex: none; display: flex; flex-direction: column; background: var(--hdi-color-bg-layout); border-right: 1px solid var(--hdi-color-border-secondary); position: sticky; top: 0; height: 100vh; }
    .logo { display: flex; align-items: center; gap: 12px; padding: 18px 20px; font: 500 14px var(--hdi-font-family); color: var(--hdi-color-text-base); }
    .marca { width: 30px; height: 30px; border-radius: 7px; background: var(--hdi-color-primary-default); color: var(--hdi-color-text-inverse); display: grid; place-items: center; font: 600 10px var(--hdi-font-family); letter-spacing: .2px; }
    .grupo { margin: 0; padding: 12px 20px 8px; font: 500 11px var(--hdi-font-family); letter-spacing: 1px; color: var(--hdi-color-text-secondary); }
    .menu { flex: 1; display: flex; flex-direction: column; gap: 2px; padding: 0 8px; }
    .item { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 8px; font: 400 14px var(--hdi-font-family); color: var(--hdi-color-text-base); text-decoration: none; }
    .item .glifo { color: var(--hdi-color-text-secondary); }
    .item .forte { font-weight: 500; }
    a.item:hover { background: var(--hdi-color-bg-fill-alter); }
    .item.ativo, .item.ativo .glifo { background: var(--hdi-color-primary-bg); color: var(--hdi-color-primary-text); }
    .rodape { border-top: 1px solid var(--hdi-color-border-secondary); padding: 12px 8px 16px; display: flex; flex-direction: column; gap: 8px; }
    .rodape .item { padding: 8px 12px; }
    .usuario { display: flex; align-items: center; gap: 10px; padding: 6px 12px; }
    .avatar { width: 28px; height: 28px; border-radius: 50%; background: var(--hdi-color-accent-default); flex: none; }
    .usuario p { margin: 0; font-family: var(--hdi-font-family); }
    .nome { font-size: 13px; font-weight: 500; color: var(--hdi-color-text-base); }
    .papel { font-size: 11px; color: var(--hdi-color-text-secondary); }
    .principal { flex: 1; min-width: 0; display: flex; flex-direction: column; }
    .cabecalho { height: 64px; flex: none; display: flex; align-items: center; justify-content: space-between; padding: 0 var(--hdi-size-xl); border-bottom: 1px solid var(--hdi-color-border-secondary); background: var(--hdi-color-bg-container); gap: var(--hdi-size-base); }
    .migalhas { display: flex; gap: var(--hdi-size-xs); font: 400 14px/22px var(--hdi-font-family); color: var(--hdi-color-text-secondary); white-space: nowrap; min-width: 0; }
    .migalhas .sep { color: var(--hdi-color-text-tertiary); }
    .migalhas .atual { color: var(--hdi-color-text-base); font-weight: 500; text-decoration: none; overflow: hidden; text-overflow: ellipsis; }
    .utilidades { display: flex; align-items: center; gap: var(--hdi-size-base); }
    .busca { width: 300px; }
    .sino { font-size: 20px; line-height: 1; color: var(--hdi-color-text-base); padding: 2px; }
    .alerta-worker { margin: var(--hdi-size-base) var(--hdi-size-xl) 0; padding: var(--hdi-size-xs) var(--hdi-size-base); border: 1px solid var(--hdi-color-warning-border); background: var(--hdi-color-warning-bg); color: var(--hdi-color-warning-text); border-radius: var(--hdi-radius-card); font: 400 12px/20px var(--hdi-font-family); }
    .conteudo { padding: 28px var(--hdi-size-xl) var(--hdi-size-xxl); }
    @media (max-width: 960px) { .lateral { display: none; } .busca { width: 200px; } }
    @media (max-width: 640px) { .utilidades .busca { display: none; } .cabecalho, .conteudo { padding-inline: var(--hdi-size-base); } }
  `,
})
export class Shell implements OnInit {
  protected readonly api = inject(IpopApi);
  protected readonly migalhas = inject(Migalhas);

  protected ambiente() {
    const amb = this.api.config()?.ambiente;
    return amb === 'prd' ? 'IPOP produção' : amb === 'hml' ? 'IPOP homologação' : '';
  }

  ngOnInit() {
    this.api.carregarConfig().subscribe({ error: () => undefined });
  }
}
