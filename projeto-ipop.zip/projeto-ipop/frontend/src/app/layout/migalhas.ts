import { Injectable, signal } from '@angular/core';

/** Complemento do caminho de navegação (ex.: "/ 784530" no detalhe). */
@Injectable({ providedIn: 'root' })
export class Migalhas {
  readonly extra = signal('');
}
