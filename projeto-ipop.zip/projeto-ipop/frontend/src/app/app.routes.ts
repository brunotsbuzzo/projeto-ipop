import { Routes } from '@angular/router';

import { Shell } from './layout/shell';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'cadastro-regras' },
  {
    path: 'cadastro-regras',
    component: Shell,
    children: [
      { path: '', title: 'Cadastro de Regras (IPOP)', loadComponent: () => import('./pages/inicio').then(m => m.InicioPage) },
      { path: 'nova', title: 'Nova solicitação · IPOP', loadComponent: () => import('./pages/nova-solicitacao').then(m => m.NovaSolicitacaoPage) },
      { path: 'enviada/:id', title: 'Solicitação enviada · IPOP', loadComponent: () => import('./pages/solicitacao-enviada').then(m => m.SolicitacaoEnviadaPage) },
      { path: 'historico', title: 'Histórico de Solicitações · IPOP', loadComponent: () => import('./pages/historico').then(m => m.HistoricoPage) },
      { path: 'historico/:id', title: 'Detalhe da solicitação · IPOP', loadComponent: () => import('./pages/detalhe').then(m => m.DetalhePage) },
      { path: 'duvidas', title: 'Dúvidas frequentes · IPOP', loadComponent: () => import('./pages/duvidas').then(m => m.DuvidasPage) },
    ],
  },
  { path: '**', redirectTo: 'cadastro-regras' },
];
