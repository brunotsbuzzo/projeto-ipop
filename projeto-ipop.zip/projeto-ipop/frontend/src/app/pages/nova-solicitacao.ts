import { ChangeDetectionStrategy, Component, DestroyRef, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzModalModule, NzModalService } from 'ng-zorro-antd/modal';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzUploadFile, NzUploadModule } from 'ng-zorro-antd/upload';
import { Subscription, filter, switchMap, take, timer } from 'rxjs';

import { IpopApi } from '../data/api';
import { dataHora, tamanho } from '../data/formatos';
import { Validacao } from '../data/modelos';
import { CabecalhoPagina } from '../shared/cabecalho-pagina';
import { CaixaProblemas } from '../shared/caixa-problemas';
import { CartaoArquivo } from '../shared/cartao-arquivo';
import { Secao } from '../shared/secao';
import { StatusTag } from '../shared/status-tag';
import { TabelaRegras } from '../shared/tabela-regras';

type EstadoArquivo = 'vazio' | 'enviando' | 'validando' | 'valido' | 'com_erros' | 'falhou';

/** Figma 04.1 · "Nova Solicitação", "Arquivo em validação", "Pré-visualização com avisos" e "com erros". */
@Component({
  selector: 'hdi-nova-solicitacao',
  imports: [ReactiveFormsModule, NzButtonModule, NzFormModule, NzIconModule, NzInputModule, NzModalModule, NzSelectModule,
            NzUploadModule, CabecalhoPagina, CaixaProblemas, CartaoArquivo, Secao, StatusTag, TabelaRegras],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="pagina">
      <hdi-cabecalho-pagina titulo="Nova solicitação de cadastro de regras"
        descricao="Informe os dados da solicitação, selecione a categoria do pedido e anexe o arquivo para cadastro no IPOP." />

      <section class="bloco" style="gap: 28px">
        <hdi-secao titulo="1 · Identificação" detalhe="4 campos obrigatórios" />
        <form nz-form nzLayout="vertical" [formGroup]="form" class="cartao campos" (ngSubmit)="enviar()">
          <nz-form-item>
            <nz-form-label nzRequired nzFor="titulo">Titulo da Solicitação</nz-form-label>
            <nz-form-control nzErrorTip="Informe o título da solicitação.">
              <input nz-input id="titulo" formControlName="titulo" placeholder="Informe o título da solicitação" maxlength="200" />
            </nz-form-control>
          </nz-form-item>
          <nz-form-item>
            <nz-form-label nzRequired nzFor="lote">ID do Lote (do Taskflow)</nz-form-label>
            <nz-form-control nzExtra="Informe o ID gerado no Taskflow." nzErrorTip="Informe o ID do lote.">
              <input nz-input id="lote" formControlName="lote_id" placeholder="Informe o ID do lote" maxlength="40" />
            </nz-form-control>
          </nz-form-item>
          <nz-form-item>
            <nz-form-label nzRequired nzFor="solicitante">Nome do Solicitante</nz-form-label>
            <nz-form-control nzErrorTip="Informe o nome do solicitante.">
              <input nz-input id="solicitante" formControlName="solicitante" placeholder="Informe o nome do solicitante" maxlength="120" />
            </nz-form-control>
          </nz-form-item>
          <nz-form-item>
            <nz-form-label nzRequired nzFor="categoria">Categoria do Pedido</nz-form-label>
            <nz-form-control nzErrorTip="Selecione a categoria.">
              <nz-select nzId="categoria" formControlName="categoria" nzPlaceHolder="Selecione">
                @for (c of categorias(); track c) {<nz-option [nzValue]="c" [nzLabel]="c" />}
              </nz-select>
            </nz-form-control>
          </nz-form-item>
        </form>

        <hdi-secao titulo="2 · Arquivo da solicitação" [detalhe]="detalheArquivo()" />
        <div class="cartao arquivo">
          <div class="cab-arquivo">
            <span>Arquivo para cadastro de regras</span>
            <a nz-button nzType="link" [href]="api.urlModelo">Baixar modelo da planilha (.xlsx)</a>
          </div>
          @if (estado() === 'vazio') {
            <nz-upload nzType="drag" [nzBeforeUpload]="aoEscolher" [nzShowUploadList]="false" nzAccept=".xlsx,.xlsm" class="area">
              <span nz-icon nzType="inbox" class="icone-upload"></span>
              <p class="instrucao">Clique ou arraste o arquivo para esta área</p>
              <p class="texto-sm">Somente planilha XLSX do modelo oficial · até {{ limiteMb() }} MB</p>
            </nz-upload>
          } @else {
            <hdi-cartao-arquivo [nome]="arquivo()?.name ?? ''" [meta]="metaArquivo()">
              <hdi-status-tag [status]="tagArquivo().status" [label]="tagArquivo().label" />
              @if (estado() === 'validando' || estado() === 'enviando') {
                <button nz-button nzType="text" nzSize="small" (click)="remover()">Remover</button>
              } @else {
                <nz-upload [nzBeforeUpload]="aoEscolher" [nzShowUploadList]="false" nzAccept=".xlsx,.xlsm">
                  <button nz-button nzType="text" nzSize="small">Substituir arquivo</button>
                </nz-upload>
              }
            </hdi-cartao-arquivo>
            @if (estado() === 'validando' || estado() === 'enviando') {
              <p class="progresso"><span nz-icon nzType="loading"></span>Lendo as abas Módulo Subscrição e Módulo Oferta e conferindo modelos, variáveis e valores nas tabelas do IPOP…</p>
            }
            @if (estado() === 'falhou') {
              <hdi-caixa-problemas titulo="Não foi possível validar o arquivo" [itens]="[validacao()?.mensagem || erroEnvio() || 'Tente de novo em instantes.']" />
            }
          }
          <p class="texto-sm">Use o modelo oficial com as abas Módulo Subscrição e/ou Módulo Oferta preenchidas. O arquivo é validado antes do envio.</p>
        </div>

        @if (validacao(); as v) {
          @if (v.status === 'valido' || v.status === 'com_erros') {
            <hdi-secao titulo="3 · Pré-visualização das regras" [detalhe]="detalhePrevia()" />
            <div class="bloco">
              <div class="resumo">
                @if (v.status === 'valido') {
                  <hdi-status-tag status="success" [label]="v.avisos.length ? 'Nenhum erro · ' + v.avisos.length + (v.avisos.length === 1 ? ' aviso' : ' avisos') : 'Nenhum erro encontrado'" />
                  <p class="texto-sm">Confira as regras lidas do arquivo antes de enviar. A coluna Linha indica a linha correspondente na planilha.</p>
                } @else {
                  <hdi-status-tag status="error" [label]="resumoErros()" />
                  <p class="texto-sm">Corrija a planilha e substitua o arquivo. Nenhuma regra é enviada enquanto houver erros.</p>
                }
              </div>
              @if (v.erros.length) {
                <hdi-caixa-problemas titulo="Erros encontrados na planilha" [itens]="linhas(v.erros)" />
              }
              @if (v.avisos.length) {
                <hdi-caixa-problemas tipo="aviso" [titulo]="v.avisos.length + (v.avisos.length === 1 ? ' aviso' : ' avisos') + ' · não impedem o envio'" [itens]="linhas(v.avisos)" />
              }
              <hdi-tabela-regras [regras]="v.regras" />
            </div>
          }
        }

        <div class="barra-acoes">
          <p>{{ textoRodape() }}</p>
          <div class="acoes">
            <button nz-button nzType="text" (click)="cancelar()">Cancelar</button>
            <button nz-button nzType="primary" [disabled]="!podeEnviar()" [nzLoading]="enviando()" (click)="enviar()">Enviar solicitação</button>
          </div>
        </div>
      </section>
    </div>
  `,
  styles: `
    .campos { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: var(--hdi-size-base); margin: 0; }
    nz-select { width: 100%; }
    .arquivo { display: flex; flex-direction: column; gap: var(--hdi-size-xs); }
    .cab-arquivo { display: flex; align-items: center; justify-content: space-between; font: 400 14px/22px var(--hdi-font-family); color: var(--hdi-color-text-base); }
    .area { display: block; }
    :host ::ng-deep .area .ant-upload.ant-upload-drag { background: var(--hdi-color-bg-fill-alter); border: 1px dashed var(--hdi-color-border-base); border-radius: var(--hdi-radius-card); }
    :host ::ng-deep .area .ant-upload.ant-upload-drag:hover { border-color: var(--hdi-color-primary-default); }
    :host ::ng-deep .area .ant-upload-btn { padding: var(--hdi-size-lg) var(--hdi-size-base); }
    .icone-upload { font-size: 32px; color: var(--hdi-color-primary-default); }
    .instrucao { margin: var(--hdi-size-xs) 0 2px; font: 400 14px/22px var(--hdi-font-family); color: var(--hdi-color-text-base); }
    .progresso { margin: 0; display: flex; align-items: center; gap: var(--hdi-size-xs); font: 400 12px/20px var(--hdi-font-family); color: var(--hdi-color-text-secondary); }
    .progresso .anticon { color: var(--hdi-color-primary-default); }
    .resumo { display: flex; align-items: center; gap: var(--hdi-size-sm); }
    @media (max-width: 1100px) { .campos { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
    @media (max-width: 640px) { .campos { grid-template-columns: 1fr; } }
  `,
})
export class NovaSolicitacaoPage {
  protected readonly api = inject(IpopApi);
  private readonly fb = inject(NonNullableFormBuilder);
  private readonly router = inject(Router);
  private readonly mensagens = inject(NzMessageService);
  private readonly modal = inject(NzModalService);
  private readonly destroy = inject(DestroyRef);

  protected readonly form = this.fb.group({
    titulo: ['', [Validators.required, Validators.maxLength(200)]],
    lote_id: ['', [Validators.required, Validators.maxLength(40)]],
    solicitante: ['', [Validators.required, Validators.maxLength(120)]],
    categoria: ['', Validators.required],
  });

  protected readonly arquivo = signal<File | null>(null);
  protected readonly estado = signal<EstadoArquivo>('vazio');
  protected readonly validacao = signal<Validacao | null>(null);
  protected readonly erroEnvio = signal('');
  protected readonly enviando = signal(false);
  private acompanhamento?: Subscription;

  protected readonly categorias = computed(() => this.api.config()?.categorias ?? ['Renovação Ituran', 'Frota']);
  protected readonly limiteMb = computed(() => this.api.config()?.tamanho_maximo_mb ?? 20);
  protected readonly podeEnviar = computed(() => this.estado() === 'valido' && !this.enviando());

  protected readonly detalheArquivo = computed(() => ({
    vazio: 'Upload vazio', enviando: 'Enviando arquivo…', validando: 'Validando arquivo…',
    valido: 'Arquivo válido', com_erros: 'Arquivo com erros', falhou: 'Não foi possível validar',
  })[this.estado()]);

  protected readonly tagArquivo = computed(() => {
    switch (this.estado()) {
      case 'valido': return { status: 'success' as const, label: 'Arquivo válido' };
      case 'com_erros': return { status: 'error' as const, label: 'Arquivo com erros' };
      case 'falhou': return { status: 'error' as const, label: 'Falha na validação' };
      default: return { status: 'processing' as const, label: 'Validando arquivo' };
    }
  });

  protected readonly metaArquivo = computed(() => {
    const f = this.arquivo();
    if (!f) return '';
    const quando = this.validacao()?.arquivo.validado_em;
    return `${tamanho(f.size)} · ${quando && this.estado() !== 'validando' ? 'validado em ' + dataHora(quando) : 'anexado agora'}`;
  });

  protected readonly detalhePrevia = computed(() => {
    const v = this.validacao();
    if (!v) return '';
    if (v.status === 'com_erros') return this.resumoErros();
    const partes = [`${v.resumo.subscricao} ${v.resumo.subscricao === 1 ? 'regra' : 'regras'}`];
    if (v.resumo.oferta) partes.push(`${v.resumo.oferta} ${v.resumo.oferta === 1 ? 'agrupamento' : 'agrupamentos'}`);
    if (v.avisos.length) partes.push(`${v.avisos.length} ${v.avisos.length === 1 ? 'aviso' : 'avisos'}`);
    return partes.join(' · ');
  });

  protected readonly resumoErros = computed(() => {
    const erros = this.validacao()?.erros ?? [];
    const linhas = new Set(erros.map(e => `${e.aba}:${e.linha}`)).size;
    return `${erros.length} ${erros.length === 1 ? 'erro' : 'erros'} em ${linhas} ${linhas === 1 ? 'linha' : 'linhas'}`;
  });

  protected readonly textoRodape = computed(() => {
    const v = this.validacao();
    switch (this.estado()) {
      case 'enviando': case 'validando': return 'Aguarde a validação do arquivo para enviar a solicitação.';
      case 'com_erros': return 'Corrija os erros na planilha e substitua o arquivo para continuar.';
      case 'falhou': return 'Substitua o arquivo ou tente de novo para continuar.';
      case 'valido': {
        const r = v!.resumo;
        const partes = [r.subscricao && `${r.subscricao} ${r.subscricao === 1 ? 'regra' : 'regras'} de subscrição`,
                        r.oferta && `${r.oferta} ${r.oferta === 1 ? 'agrupamento' : 'agrupamentos'} de oferta`].filter(Boolean);
        return `Ao enviar, ${partes.join(' e ')} ${r.total === 1 ? 'entra' : 'entram'} na fila do robô para cadastro no IPOP.`;
      }
      default: return 'Campos com * são obrigatórios. Revise os dados antes de enviar.';
    }
  });

  constructor() {
    const primeira = this.categorias()[0];
    if (primeira) this.form.controls.categoria.setValue(primeira);
  }

  protected linhas(problemas: { linha: number; mensagem: string }[]) {
    return problemas.map(p => `Linha ${p.linha} · ${p.mensagem}`);
  }

  /** nz-upload: devolve false para não enviar sozinho; o arquivo vai para /api/validacoes. */
  protected readonly aoEscolher = (arquivo: NzUploadFile): boolean => {
    const f = arquivo as unknown as File;
    if (!/\.xls[xm]$/i.test(f.name)) {
      this.mensagens.error('Envie a planilha XLSX do modelo oficial.');
      return false;
    }
    if (f.size > this.limiteMb() * 1024 * 1024) {
      this.mensagens.error(`A planilha passa de ${this.limiteMb()} MB.`);
      return false;
    }
    this.validar(f);
    return false;
  };

  private validar(f: File) {
    this.acompanhamento?.unsubscribe();
    this.arquivo.set(f);
    this.validacao.set(null);
    this.erroEnvio.set('');
    this.estado.set('enviando');
    this.acompanhamento = this.api.validar(f).pipe(
      switchMap(({ id }) => { this.estado.set('validando'); return timer(0, 1500).pipe(switchMap(() => this.api.validacao(id))); }),
      filter(v => v.status !== 'validando'),
      take(1),
      takeUntilDestroyed(this.destroy),
    ).subscribe({
      next: v => { this.validacao.set(v); this.estado.set(v.status as EstadoArquivo); },
      error: e => { this.erroEnvio.set(e.message); this.estado.set('falhou'); },
    });
  }

  protected remover() {
    this.acompanhamento?.unsubscribe();
    this.arquivo.set(null);
    this.validacao.set(null);
    this.estado.set('vazio');
  }

  protected enviar() {
    if (this.form.invalid) {
      Object.values(this.form.controls).forEach(c => { c.markAsDirty(); c.updateValueAndValidity({ onlySelf: true }); });
      this.mensagens.warning('Preencha os campos obrigatórios.');
      return;
    }
    const v = this.validacao();
    if (!v || this.estado() !== 'valido') return;
    this.enviando.set(true);
    this.api.enviar({ validacao_id: v.id, ...this.form.getRawValue() }).subscribe({
      next: s => this.router.navigate(['/cadastro-regras/enviada', s.id]),
      error: e => { this.enviando.set(false); this.mensagens.error(e.message); },
    });
  }

  protected cancelar() {
    const sujo = this.form.dirty || this.arquivo();
    if (!sujo) { this.router.navigate(['/cadastro-regras']); return; }
    this.modal.confirm({
      nzTitle: 'Descartar esta solicitação?', nzContent: 'Os dados preenchidos e o arquivo anexado serão perdidos.',
      nzOkText: 'Descartar', nzOkDanger: true, nzCancelText: 'Continuar editando',
      nzOnOk: () => this.router.navigate(['/cadastro-regras']),
    });
  }
}
