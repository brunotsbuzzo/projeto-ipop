import { ChangeDetectionStrategy, Component, DestroyRef, OnDestroy, OnInit, computed, inject, input, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { RouterLink } from '@angular/router';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzModalModule, NzModalService } from 'ng-zorro-antd/modal';
import { Subject, startWith, switchMap, takeWhile, timer } from 'rxjs';

import { IpopApi } from '../data/api';
import { dataHora, tamanho } from '../data/formatos';
import { Solicitacao } from '../data/modelos';
import { Migalhas } from '../layout/migalhas';
import { CabecalhoPagina } from '../shared/cabecalho-pagina';
import { CaixaProblemas } from '../shared/caixa-problemas';
import { CartaoArquivo } from '../shared/cartao-arquivo';
import { LinhaDoTempo } from '../shared/linha-do-tempo';
import { Secao } from '../shared/secao';
import { StatusTag } from '../shared/status-tag';
import { TabelaRegras } from '../shared/tabela-regras';

/** Figma 04.1 · "Detalhe" (cadastrando, parou com erro, concluída). Atualiza sozinho enquanto o robô trabalha. */
@Component({
  selector: 'hdi-detalhe',
  imports: [RouterLink, NzButtonModule, NzIconModule, NzModalModule, CabecalhoPagina, CaixaProblemas, CartaoArquivo,
            LinhaDoTempo, Secao, StatusTag, TabelaRegras],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (s(); as s) {
      <div class="pagina">
        <hdi-cabecalho-pagina [titulo]="s.titulo" [descricao]="'Lote ' + s.lote_id + ' · enviada por ' + s.solicitante + ' em ' + dataHora(s.criada_em)">
          <a nz-button nzType="default" routerLink="/cadastro-regras/historico">Voltar ao histórico</a>
          @if (s.pode_cancelar) {
            <button nz-button nzType="default" nzDanger [nzLoading]="acao() === 'cancelar'" (click)="cancelar(s)">Cancelar execução</button>
          }
          @if (s.pode_retomar) {
            <button nz-button nzType="primary" [nzLoading]="acao() === 'retomar'" (click)="retomar(s)">Retomar da regra {{ s.retomar_de }}</button>
          }
        </hdi-cabecalho-pagina>

        <section class="bloco">
          <hdi-secao titulo="Dados da solicitação" detalhe="Status atual" />
          <div class="cartao dados">
            <div><span class="campo">ID do lote</span><span class="valor">{{ s.lote_id }}</span></div>
            <div><span class="campo">Solicitante</span><span class="valor">{{ s.solicitante }}</span></div>
            <div><span class="campo">Categoria</span><span class="valor">{{ s.categoria }}</span></div>
            <div><span class="campo">Enviada em</span><span class="valor">{{ dataHora(s.criada_em) }}</span></div>
            <div><span class="campo">Status</span><hdi-status-tag [status]="s.status.tag" [label]="s.status.rotulo" /></div>
          </div>
          @if (parada(); as p) {
            <hdi-caixa-problemas [titulo]="p.titulo" [itens]="p.itens" />
          }
        </section>

        <section class="bloco">
          <hdi-secao titulo="Arquivo enviado" detalhe="1 arquivo" />
          <hdi-cartao-arquivo [nome]="s.arquivo.nome" [meta]="tamanho(s.arquivo.tamanho) + ' · enviado em ' + dataHora(s.criada_em)">
            <hdi-status-tag status="success" label="Arquivo válido" />
            <a nz-button nzType="link" nzSize="small" [href]="s.arquivo.url" download>Baixar arquivo</a>
          </hdi-cartao-arquivo>
        </section>

        <section class="bloco">
          <hdi-secao titulo="Regras enviadas" [detalhe]="progresso()" />
          <hdi-tabela-regras [regras]="s.regras" [situacao]="true" />
        </section>

        <section class="bloco">
          <hdi-secao titulo="Andamento" [detalhe]="s.eventos.length + (s.eventos.length === 1 ? ' evento' : ' eventos')" />
          <hdi-linha-do-tempo [eventos]="s.eventos" />
        </section>
      </div>
    } @else {
      <p class="carregando">
        @if (erro()) { {{ erro() }} } @else { <span nz-icon nzType="loading"></span> Carregando a solicitação… }
      </p>
    }
  `,
  styles: `
    .dados { display: flex; gap: var(--hdi-size-lg); }
    .dados > div { flex: 1; min-width: 0; display: flex; flex-direction: column; align-items: flex-start; gap: var(--hdi-size-xxs); }
    .campo { font: 400 12px/20px var(--hdi-font-family); color: var(--hdi-color-text-secondary); }
    .valor { font: 500 14px/22px var(--hdi-font-family); color: var(--hdi-color-text-base); }
    @media (max-width: 1100px) { .dados { flex-wrap: wrap; } .dados > div { flex: 1 1 180px; } }
  `,
})
export class DetalhePage implements OnInit, OnDestroy {
  readonly id = input.required<string>();
  private readonly api = inject(IpopApi);
  private readonly mensagens = inject(NzMessageService);
  private readonly modal = inject(NzModalService);
  private readonly migalhas = inject(Migalhas);
  private readonly destroy = inject(DestroyRef);
  private readonly recarregar$ = new Subject<void>();

  protected readonly s = signal<Solicitacao | null>(null);
  protected readonly erro = signal('');
  protected readonly acao = signal<'cancelar' | 'retomar' | null>(null);
  protected readonly dataHora = dataHora;
  protected readonly tamanho = tamanho;

  protected readonly progresso = computed(() => {
    const s = this.s();
    if (!s) return '';
    const { total, cadastradas, subscricao, oferta } = s.resumo;
    if (s.status.codigo === 'recebida' || s.status.codigo === 'conferindo') {
      return [subscricao && `${subscricao} ${subscricao === 1 ? 'regra' : 'regras'}`, oferta && `${oferta} ${oferta === 1 ? 'agrupamento' : 'agrupamentos'}`].filter(Boolean).join(' · ');
    }
    const parada = s.regras.find(r => r.status === 'erro' || r.status === 'verificar');
    return `${cadastradas} de ${total} cadastradas${parada && !s.ativa ? ' · parou na regra ' + parada.n : ''}`;
  });

  /** Aviso vermelho quando o robô parou: motivo, o que já foi feito e o que conferir antes de retomar. */
  protected readonly parada = computed(() => {
    const s = this.s();
    if (!s || s.ativa || s.status.tag !== 'error') return null;
    const regra = s.regras.find(r => r.status === 'erro' || r.status === 'verificar');
    const feitas = s.regras.filter(r => r.status === 'confirmada' || r.status === 'salva_sem_confirmacao');
    const naoFeitas = s.regras.filter(r => r.status === 'não executada' || r.status === 'pendente');
    const itens: string[] = [];
    if (s.fase === 'erro_validacao') {
      return { titulo: 'A planilha tem erros e nenhuma regra foi cadastrada', itens: s.problemas.filter(p => p.nivel === 'erro').map(p => `Linha ${p.linha} · ${p.mensagem}`) };
    }
    if (regra) {
      itens.push(regra.status === 'verificar' ? regra.detalhe : `${regra.nome}: ${regra.detalhe || 'falha no IPOP'}`);
    } else if (s.mensagem) {
      itens.push(s.mensagem);
    }
    if (feitas.length) itens.push(`${feitas.length === 1 ? 'A regra' : 'As regras'} ${feitas.map(r => r.n).join(', ')} já ${feitas.length === 1 ? 'está cadastrada' : 'estão cadastradas'} e não ${feitas.length === 1 ? 'será criada' : 'serão criadas'} de novo.`);
    if (naoFeitas.length) itens.push(`${naoFeitas.length} ${naoFeitas.length === 1 ? 'regra não foi executada' : 'regras não foram executadas'}.`);
    if (regra) itens.push(`A cópia do modelo aberta para a regra ${regra.n} pode ter ficado no IPOP sem preenchimento. Confira e apague antes de retomar.`);
    return { titulo: regra ? `O robô parou na regra ${regra.n} (${regra.nome})` : `A execução terminou: ${s.status.rotulo}`, itens };
  });

  ngOnInit() {
    // Enquanto o robô trabalha, atualiza a cada 3 s; depois para.
    this.recarregar$.pipe(
      startWith(undefined),
      switchMap(() => timer(0, 3000).pipe(
        switchMap(() => this.api.solicitacao(this.id())),
        takeWhile(s => s.ativa, true),
      )),
      takeUntilDestroyed(this.destroy),
    ).subscribe({
      next: s => { this.s.set(s); this.migalhas.extra.set(s.lote_id); },
      error: e => this.erro.set(e.message),
    });
  }

  ngOnDestroy() { this.migalhas.extra.set(''); }

  protected cancelar(s: Solicitacao) {
    this.modal.confirm({
      nzTitle: 'Cancelar a execução?',
      nzContent: 'O robô termina a regra que está cadastrando agora e para. As regras seguintes não serão cadastradas.',
      nzOkText: 'Cancelar execução', nzOkDanger: true, nzCancelText: 'Voltar',
      nzOnOk: () => {
        this.acao.set('cancelar');
        this.api.cancelar(s.id).subscribe({
          next: () => { this.acao.set(null); this.mensagens.success('Cancelamento pedido.'); this.recarregar$.next(); },
          error: e => { this.acao.set(null); this.mensagens.error(e.message); },
        });
      },
    });
  }

  protected retomar(s: Solicitacao) {
    this.modal.confirm({
      nzTitle: `Retomar a partir da regra ${s.retomar_de}?`,
      nzContent: 'As regras já cadastradas não serão criadas de novo. Confira antes se a cópia do modelo que sobrou no IPOP foi apagada.',
      nzOkText: `Retomar da regra ${s.retomar_de}`, nzCancelText: 'Voltar',
      nzOnOk: () => {
        this.acao.set('retomar');
        this.api.retomar(s.id).subscribe({
          next: atual => { this.acao.set(null); this.s.set(atual); this.mensagens.success('A solicitação voltou para a fila do robô.'); this.recarregar$.next(); },
          error: e => { this.acao.set(null); this.mensagens.error(e.message); },
        });
      },
    });
  }
}
