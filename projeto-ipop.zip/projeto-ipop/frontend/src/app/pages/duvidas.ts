import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzCollapseModule } from 'ng-zorro-antd/collapse';

import { IpopApi } from '../data/api';
import { CabecalhoPagina } from '../shared/cabecalho-pagina';
import { Secao } from '../shared/secao';

/** Sem tela própria no Figma: usa os mesmos blocos do design system. */
@Component({
  selector: 'hdi-duvidas',
  imports: [RouterLink, NzButtonModule, NzCollapseModule, CabecalhoPagina, Secao],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="pagina">
      <hdi-cabecalho-pagina titulo="Dúvidas Frequentes" descricao="Orientações sobre o preenchimento da planilha e o andamento das solicitações.">
        <a nz-button nzType="default" [href]="api.urlModelo">Baixar modelo da planilha (.xlsx)</a>
        <a nz-button nzType="primary" routerLink="../nova">Nova solicitação</a>
      </hdi-cabecalho-pagina>
      <section class="bloco">
        <hdi-secao titulo="Perguntas" [detalhe]="perguntas.length + ' respostas'" />
        <nz-collapse nzExpandIconPosition="end">
          @for (p of perguntas; track p.pergunta; let primeiro = $first) {
            <nz-collapse-panel [nzHeader]="p.pergunta" [nzActive]="primeiro"><p>{{ p.resposta }}</p></nz-collapse-panel>
          }
        </nz-collapse>
      </section>
    </div>
  `,
  styles: `
    nz-collapse { border-radius: var(--hdi-radius-card); background: var(--hdi-color-bg-container); border-color: var(--hdi-color-border-secondary); }
    p { margin: 0; font: 400 14px/22px var(--hdi-font-family); color: var(--hdi-color-text-secondary); }
  `,
})
export class DuvidasPage {
  protected readonly api = inject(IpopApi);
  protected readonly perguntas = [
    { pergunta: 'Posso mandar Subscrição e Oferta no mesmo arquivo?', resposta: 'Sim. Preencha as abas Módulo Subscrição e Módulo Oferta da mesma planilha; o robô troca de módulo sozinho no IPOP.' },
    { pergunta: 'Como escrevo o Fator?', resposta: 'Na Subscrição o Fator é multiplicador: 1,58 aumenta 58% e 0,90 reduz 10%. Na Oferta, a coluna Fator (%) é o percentual como deve aparecer no IPOP.' },
    { pergunta: 'Como coloco vários valores numa variável?', resposta: 'Separe por ponto e vírgula (5; 6; 7). Variáveis contínuas usam faixas no formato “18 a 25”, também separadas por ponto e vírgula.' },
    { pergunta: 'Qual é a diferença entre erro e aviso na pré-visualização?', resposta: 'Erro impede o envio: corrija a planilha e substitua o arquivo. Aviso não impede: indica algo que o robô vai tratar sozinho, como um valor que ele vai procurar pelo texto na lista do IPOP.' },
    { pergunta: 'O que acontece depois que eu envio?', resposta: 'A solicitação entra na fila do robô (Recebida). Ele confere os dados de novo, cadastra as regras uma a uma (Cadastrando) e confere cada regra na lista do IPOP depois de salvar (Concluída).' },
    { pergunta: 'O robô parou numa regra. E agora?', resposta: 'O detalhe da solicitação mostra o motivo e o print da tela. Corrija o problema (na planilha ou no IPOP) e clique em “Retomar da regra N”: as regras já cadastradas não são criadas de novo. A cópia de modelo que ficou aberta na regra com erro pode ter sobrado no IPOP; confira e apague.' },
    { pergunta: 'Onde estão os modelos de regra e os nomes das variáveis?', resposta: 'Na planilha-modelo: as abas “Modelos de regras” e “Tabela de variáveis” listam o que o IPOP aceita.' },
  ];
}
