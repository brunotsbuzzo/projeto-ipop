import { ChangeDetectionStrategy, Component, OnInit, computed, inject, input, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzIconModule } from 'ng-zorro-antd/icon';

import { IpopApi } from '../data/api';
import { dataHora } from '../data/formatos';
import { Solicitacao } from '../data/modelos';
import { CabecalhoPagina } from '../shared/cabecalho-pagina';
import { StatusTag } from '../shared/status-tag';

/** Figma 04.1 · "Envio confirmado". */
@Component({
  selector: 'hdi-solicitacao-enviada',
  imports: [RouterLink, NzButtonModule, NzIconModule, CabecalhoPagina, StatusTag],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="pagina">
      <hdi-cabecalho-pagina titulo="Solicitação enviada" descricao="Acompanhe o cadastro regra por regra pelo Histórico de Solicitações." />
      <div class="cartao confirmacao">
        @if (s(); as s) {
          <span class="check" aria-hidden="true"><span nz-icon nzType="check"></span></span>
          <h2>Solicitação enviada com sucesso</h2>
          <p class="descricao">A solicitação do lote {{ s.lote_id }} entrou na fila do robô e já aparece no histórico com o status:</p>
          <hdi-status-tag [status]="s.status.tag" [label]="s.status.rotulo" />
          <dl class="dados">
            <dt>Título</dt><dd>{{ s.titulo }}</dd>
            <dt>ID do lote</dt><dd>{{ s.lote_id }}</dd>
            <dt>Solicitante</dt><dd>{{ s.solicitante }}</dd>
            <dt>Categoria</dt><dd>{{ s.categoria }}</dd>
            <dt>Arquivo</dt><dd>{{ s.arquivo.nome }}</dd>
            <dt>Regras</dt><dd>{{ regras() }}</dd>
            <dt>Enviada em</dt><dd>{{ dataHora(s.criada_em) }}</dd>
          </dl>
          <div class="acoes">
            <a nz-button nzType="default" routerLink="/cadastro-regras">Voltar ao início</a>
            <a nz-button nzType="primary" [routerLink]="['/cadastro-regras/historico', s.id]">Ver solicitação</a>
          </div>
        } @else {
          <p class="descricao">{{ erro() || 'Carregando…' }}</p>
        }
      </div>
    </div>
  `,
  styles: `
    .confirmacao { display: flex; flex-direction: column; align-items: center; gap: var(--hdi-size-base); padding: var(--hdi-size-xxl) var(--hdi-size-lg); text-align: center; }
    .check { width: 48px; height: 48px; border-radius: 50%; background: var(--hdi-color-success-default); color: var(--hdi-color-text-inverse); display: grid; place-items: center; font-size: 22px; }
    h2 { margin: 0; font: 600 20px/28px var(--hdi-font-family); color: var(--hdi-color-text-base); }
    .descricao { margin: 0; font: 400 14px/22px var(--hdi-font-family); color: var(--hdi-color-text-secondary); }
    .dados { display: grid; grid-template-columns: 156px minmax(0, 1fr); gap: var(--hdi-size-xs) 0; width: min(600px, 100%); margin: 0; padding: var(--hdi-size-lg); background: var(--hdi-color-bg-fill-alter); border: 1px solid var(--hdi-color-border-secondary); border-radius: var(--hdi-radius-card); text-align: left; font: 400 12px/20px var(--hdi-font-family); }
    dt { color: var(--hdi-color-text-secondary); } dd { margin: 0; color: var(--hdi-color-text-base); font-weight: 500; }
    .acoes { display: flex; gap: var(--hdi-size-xs); }
  `,
})
export class SolicitacaoEnviadaPage implements OnInit {
  readonly id = input.required<string>();
  private readonly api = inject(IpopApi);
  protected readonly s = signal<Solicitacao | null>(null);
  protected readonly erro = signal('');
  protected readonly dataHora = dataHora;
  protected readonly regras = computed(() => {
    const r = this.s()?.resumo;
    if (!r) return '';
    const partes = [];
    if (r.subscricao) partes.push(`${r.subscricao} de subscrição`);
    if (r.oferta) partes.push(`${r.oferta} ${r.oferta === 1 ? 'agrupamento' : 'agrupamentos'} de oferta`);
    return partes.join(' · ');
  });

  ngOnInit() {
    this.api.solicitacao(this.id()).subscribe({ next: s => this.s.set(s), error: e => this.erro.set(e.message) });
  }
}
