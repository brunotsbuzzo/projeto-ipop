import { ChangeDetectionStrategy, Component, DestroyRef, OnInit, computed, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { Subject, debounceTime, startWith, switchMap, timer } from 'rxjs';

import { IpopApi } from '../data/api';
import { SolicitacaoResumo, StatusSolicitacao } from '../data/modelos';
import { CabecalhoPagina } from '../shared/cabecalho-pagina';
import { Secao } from '../shared/secao';
import { StatusTag } from '../shared/status-tag';

const POR_PAGINA = 10;

/** Figma 04.1 · "Histórico de Solicitações". */
@Component({
  selector: 'hdi-historico',
  imports: [FormsModule, RouterLink, NzButtonModule, NzIconModule, NzInputModule, NzPaginationModule, NzSelectModule,
            CabecalhoPagina, Secao, StatusTag],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="pagina">
      <hdi-cabecalho-pagina titulo="Histórico de Solicitações"
        descricao="Consulte as solicitações enviadas e acompanhe o cadastro feito pelo robô, regra por regra.">
        <a nz-button nzType="primary" routerLink="../nova"><span nz-icon nzType="plus"></span>Nova solicitação</a>
      </hdi-cabecalho-pagina>
      <section class="bloco">
        <hdi-secao titulo="Solicitações enviadas" [detalhe]="itens().length + (itens().length === 1 ? ' solicitação' : ' solicitações')" />
        <div class="filtros">
          <label class="campo largo">
            <span class="rotulo">Buscar solicitação</span>
            <nz-input-wrapper>
              <input nz-input [ngModel]="busca()" (ngModelChange)="busca.set($event); buscar$.next()"
                     placeholder="Busque pelo ID do lote, título ou nome do solicitante" />
              <span nzInputSuffix nz-icon nzType="search"></span>
            </nz-input-wrapper>
          </label>
          <label class="campo">
            <span class="rotulo">Status da solicitação</span>
            <nz-select [ngModel]="status()" (ngModelChange)="status.set($event); buscar$.next()" nzPlaceHolder="Todos os status" nzAllowClear>
              @for (s of opcoesStatus; track s.valor) {<nz-option [nzValue]="s.valor" [nzLabel]="s.rotulo" />}
            </nz-select>
          </label>
        </div>
        <div class="tabela">
          <div class="linha cabecalho"><span class="c-id">ID solicitado</span><span class="c-titulo">Título da Solicitação</span><span class="c-nome">Nome do Solicitante</span><span class="c-status">Status da Solicitação</span></div>
          @for (s of pagina(); track s.id) {
            <a class="linha" [routerLink]="s.id">
              <span class="c-id forte">{{ s.lote_id }}</span>
              <span class="c-titulo">{{ s.titulo }}</span>
              <span class="c-nome">{{ s.solicitante }}</span>
              <span class="c-status"><hdi-status-tag [status]="s.status.tag" [label]="s.status.rotulo" /></span>
            </a>
          } @empty {
            <p class="vazio">{{ carregou() ? 'Nenhuma solicitação encontrada.' : 'Carregando…' }}</p>
          }
          <div class="rodape">
            <span class="texto-sm">Exibindo {{ faixa() }} de {{ itens().length }} solicitações</span>
            <nz-pagination [nzPageIndex]="indice()" (nzPageIndexChange)="indice.set($event)" [nzTotal]="itens().length"
                           [nzPageSize]="POR_PAGINA" [nzItemRender]="paginas" />
            <ng-template #paginas let-tipo let-pagina="page">
              @switch (tipo) {
                @case ('prev') { <a>Anterior</a> }
                @case ('next') { <a>Próxima</a> }
                @case ('page') { <a>{{ pagina }}</a> }
              }
            </ng-template>
          </div>
        </div>
        <p class="orientacao texto-sm"><span nz-icon nzType="info-circle" nzTheme="fill"></span>O ID solicitado corresponde ao ID do Lote do Taskflow informado no formulário.</p>
      </section>
    </div>
  `,
  styles: `
    .filtros { display: flex; gap: var(--hdi-size-base); align-items: flex-end; }
    .campo { display: flex; flex-direction: column; gap: var(--hdi-size-xs); width: 240px; }
    .campo.largo { flex: 1; width: auto; }
    .rotulo { font: 500 14px/22px var(--hdi-font-family); color: var(--hdi-color-text-base); }
    nz-select { width: 100%; }
    .tabela { border: 1px solid var(--hdi-color-border-secondary); border-radius: var(--hdi-radius-card); overflow: hidden; background: var(--hdi-color-bg-container); }
    .linha { display: flex; align-items: center; gap: var(--hdi-size-lg); min-height: 56px; padding: 0 var(--hdi-size-lg); border-bottom: 1px solid var(--hdi-color-border-secondary); font: 400 14px/22px var(--hdi-font-family); color: var(--hdi-color-text-base); text-decoration: none; }
    a.linha:hover { background: var(--hdi-color-bg-fill-alter); }
    a.linha:focus-visible { outline: 2px solid var(--hdi-color-primary-border); outline-offset: -2px; }
    .linha.cabecalho { min-height: 52px; background: var(--hdi-color-bg-fill-alter); font-weight: 600; }
    .forte { font-weight: 500; }
    .c-id { width: 128px; flex: none; } .c-titulo { flex: 1; min-width: 0; } .c-nome { width: 208px; flex: none; } .c-status { width: 176px; flex: none; }
    .rodape { display: flex; align-items: center; justify-content: space-between; min-height: 56px; padding: 0 var(--hdi-size-lg); }
    .vazio { margin: 0; padding: var(--hdi-size-xl); text-align: center; color: var(--hdi-color-text-secondary); border-bottom: 1px solid var(--hdi-color-border-secondary); }
    .orientacao { display: flex; gap: var(--hdi-size-xs); align-items: center; }
    :host ::ng-deep .ant-pagination-item-active { background: var(--hdi-color-primary-bg); border-color: var(--hdi-color-primary-border); }
    :host ::ng-deep .ant-pagination-prev a, :host ::ng-deep .ant-pagination-next a { font: 500 14px/32px var(--hdi-font-family); padding: 0 var(--hdi-control-padding-inline-button); color: var(--hdi-color-primary-text); }
    :host ::ng-deep .ant-pagination-disabled a { color: var(--hdi-color-text-disabled); }
    @media (max-width: 1100px) { .c-nome { display: none; } }
  `,
})
export class HistoricoPage implements OnInit {
  private readonly api = inject(IpopApi);
  private readonly destroy = inject(DestroyRef);
  protected readonly router = inject(Router);
  protected readonly POR_PAGINA = POR_PAGINA;
  protected readonly busca = signal('');
  protected readonly status = signal<StatusSolicitacao['codigo'] | null>(null);
  protected readonly itens = signal<SolicitacaoResumo[]>([]);
  protected readonly carregou = signal(false);
  protected readonly indice = signal(1);
  protected readonly buscar$ = new Subject<void>();
  protected readonly pagina = computed(() => this.itens().slice((this.indice() - 1) * POR_PAGINA, this.indice() * POR_PAGINA));
  protected readonly faixa = computed(() => {
    const total = this.itens().length;
    if (!total) return '0';
    const ini = (this.indice() - 1) * POR_PAGINA + 1;
    return `${ini}–${Math.min(total, ini + POR_PAGINA - 1)}`;
  });
  protected readonly opcoesStatus: { valor: StatusSolicitacao['codigo']; rotulo: string }[] = [
    { valor: 'recebida', rotulo: 'Recebida' }, { valor: 'conferindo', rotulo: 'Conferindo dados' },
    { valor: 'cadastrando', rotulo: 'Cadastrando' }, { valor: 'concluida', rotulo: 'Concluída' },
    { valor: 'erro', rotulo: 'Parou com erro' }, { valor: 'cancelada', rotulo: 'Cancelada' },
  ];

  ngOnInit() {
    // Atualiza a cada 10 s para acompanhar o robô; filtros disparam na hora (com debounce na busca).
    this.buscar$.pipe(
      debounceTime(250), startWith(undefined),
      switchMap(() => timer(0, 10_000).pipe(switchMap(() => this.api.listar(this.busca(), this.status() ?? '')))),
      takeUntilDestroyed(this.destroy),
    ).subscribe({
      next: itens => { this.itens.set(itens); this.carregou.set(true); if (this.indice() > Math.ceil(itens.length / POR_PAGINA)) this.indice.set(1); },
      error: () => this.carregou.set(true),
    });
  }
}
