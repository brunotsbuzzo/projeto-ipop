import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';

import { IpopApi } from '../data/api';
import { CabecalhoPagina } from '../shared/cabecalho-pagina';
import { Secao } from '../shared/secao';

interface Acesso { rota: string; icone: string; titulo: string; descricao: string; categoria: string; }

/** Figma 04.1 · "Início · Cadastro de Regras IPOP". */
@Component({
  selector: 'hdi-inicio',
  imports: [RouterLink, NzIconModule, CabecalhoPagina, Secao],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="pagina">
      <hdi-cabecalho-pagina titulo="Cadastro de Regras (IPOP)"
        descricao="Crie uma solicitação, consulte pedidos anteriores ou esclareça suas dúvidas. Escolha por onde começar." />
      <section class="bloco" style="gap: var(--hdi-size-xl)">
        <hdi-secao titulo="O que você deseja fazer?" detalhe="3 opções de acesso" />
        <div class="opcoes">
          @for (a of acessos; track a.rota; let primeiro = $first) {
            <a class="card" [class.destaque]="primeiro" [routerLink]="a.rota">
              <span class="icone" aria-hidden="true">{{ a.icone }}</span>
              <span class="info">
                <span class="titulo">{{ a.titulo }}</span>
                <span class="descricao">{{ a.descricao }}</span>
                <span class="categoria">{{ a.categoria }}</span>
              </span>
              <span nz-icon nzType="arrow-right" class="seta" aria-hidden="true"></span>
            </a>
          }
        </div>
      </section>
      <div class="orientacao">
        <span nz-icon nzType="info-circle" nzTheme="fill" aria-hidden="true"></span>
        <div>
          <p class="o-titulo">Antes de iniciar uma nova solicitação</p>
          <p class="o-texto">Tenha em mãos o ID do lote gerado no Taskflow e o arquivo com as regras. Depois do envio, o robô confere a planilha e cadastra as regras no IPOP.</p>
          <p class="texto-sm">Arquivo aceito: planilha XLSX do modelo oficial · até {{ api.config()?.tamanho_maximo_mb ?? 20 }} MB</p>
        </div>
      </div>
    </div>
  `,
  styles: `
    .opcoes { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: var(--hdi-size-base); }
    .card { display: flex; align-items: center; gap: var(--hdi-size-base); min-height: 196px; padding: 18px var(--hdi-size-md); border: 1px solid var(--hdi-color-border-secondary); border-radius: var(--hdi-radius-card); background: var(--hdi-color-bg-container); text-decoration: none; transition: border-color .15s, box-shadow .15s; }
    .card.destaque, .card:hover, .card:focus-visible { border-color: var(--hdi-color-primary-border); }
    .card:hover { box-shadow: var(--hdi-shadow-card); }
    .card:focus-visible { outline: 2px solid var(--hdi-color-primary-border); outline-offset: 2px; }
    .icone { width: 44px; height: 44px; flex: none; border-radius: var(--hdi-radius-card); background: var(--hdi-color-primary-bg); color: var(--hdi-color-primary-text); display: grid; place-items: center; font: 600 20px/28px var(--hdi-font-family); }
    .info { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 6px; }
    .titulo { font: 600 16px/24px var(--hdi-font-family); color: var(--hdi-color-text-base); }
    .descricao { font: 400 14px/22px var(--hdi-font-family); color: var(--hdi-color-text-secondary); }
    .categoria { align-self: flex-start; padding: 0 var(--hdi-control-padding-inline-tag); border: 1px solid var(--hdi-color-border-base); border-radius: var(--hdi-radius-tag); background: var(--hdi-color-bg-fill-alter); font: 400 12px/20px var(--hdi-font-family); color: var(--hdi-color-text-secondary); }
    .seta { color: var(--hdi-color-primary-text); font-size: 16px; }
    .orientacao { display: flex; gap: var(--hdi-size-sm); padding: var(--hdi-size-lg); border: 1px solid var(--hdi-color-border-secondary); border-radius: var(--hdi-radius-card); background: var(--hdi-color-bg-fill-alter); }
    .orientacao > .anticon { font-size: 16px; color: var(--hdi-color-text-secondary); margin-top: 3px; }
    .orientacao div { display: flex; flex-direction: column; gap: var(--hdi-size-xxs); }
    .orientacao p { margin: 0; }
    .o-titulo { font: 600 14px/22px var(--hdi-font-family); color: var(--hdi-color-text-base); }
    .o-texto { font: 400 14px/22px var(--hdi-font-family); color: var(--hdi-color-text-secondary); }
    @media (max-width: 1100px) { .opcoes { grid-template-columns: 1fr; } .card { min-height: 0; } }
  `,
})
export class InicioPage {
  protected readonly api = inject(IpopApi);
  protected readonly acessos: Acesso[] = [
    { rota: 'nova', icone: '+', titulo: 'Nova Solicitação', descricao: 'Informe os dados do pedido e anexe as regras para cadastro no IPOP.', categoria: 'Cadastro' },
    { rota: 'historico', icone: '≡', titulo: 'Histórico de Solicitações Anteriores', descricao: 'Consulte os pedidos enviados e acompanhe o cadastro regra por regra.', categoria: 'Consulta' },
    { rota: 'duvidas', icone: '?', titulo: 'Dúvidas Frequentes', descricao: 'Encontre orientações sobre o preenchimento e o envio de arquivos.', categoria: 'Ajuda' },
  ];
}
