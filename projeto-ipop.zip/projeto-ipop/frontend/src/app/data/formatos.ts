import { RegraTela, SituacaoRegra, TagStatus, VariavelRegra } from './modelos';

const dataBr = (iso: string | null | undefined) => {
  if (!iso) return '—';
  const [a, m, d] = iso.slice(0, 10).split('-');
  return `${d}/${m}/${a}`;
};

export const vigencia = (r: Pick<RegraTela, 'vigencia_inicio' | 'vigencia_fim'>) =>
  `${dataBr(r.vigencia_inicio)} – ${dataBr(r.vigencia_fim)}`;

/** Subscrição: multiplicador (×1,58). Oferta: percentual (6%). Com erro, mostra o texto da planilha. */
export function fator(r: RegraTela): string {
  if (r.fator === null || r.campos_com_erro?.includes('fator')) return r.fator_original || '—';
  const num = r.fator.toLocaleString('pt-BR', { minimumFractionDigits: r.modulo === 'Oferta' ? 0 : 2, maximumFractionDigits: 2 });
  return r.modulo === 'Oferta' ? `${num}%` : `×${num}`;
}

export const variavel = (v: VariavelRegra) =>
  `${v.nome}${v.codigo ? ` (${v.codigo})` : ''} · ${v.acao}: ${v.valores.join('; ')}`;

export function tamanho(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / 1024 / 1024).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} MB`;
}

export function dataHora(iso: string | null | undefined): string {
  if (!iso) return '—';
  const d = new Date(iso);
  const dia = d.toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' });
  const hora = d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', timeZone: 'America/Sao_Paulo' });
  return `${dia} às ${hora}`;
}

export const SITUACAO: Record<SituacaoRegra, { rotulo: string; tag: TagStatus }> = {
  pendente: { rotulo: 'Pendente', tag: 'default' },
  executando: { rotulo: 'Cadastrando', tag: 'processing' },
  confirmada: { rotulo: 'Cadastrada', tag: 'success' },
  salva_sem_confirmacao: { rotulo: 'Salva · conferir', tag: 'warning' },
  erro: { rotulo: 'Erro', tag: 'error' },
  verificar: { rotulo: 'Conferir no IPOP', tag: 'warning' },
  'não executada': { rotulo: 'Não executada', tag: 'default' },
  pulada: { rotulo: 'Pulada', tag: 'default' },
};
