import { describe, expect, it } from 'vitest';

import { fator, tamanho, variavel, vigencia } from './formatos';
import { RegraTela } from './modelos';

const regra = (parcial: Partial<RegraTela>): RegraTela => ({
  n: 1, aba: 'Módulo Subscrição', modulo: 'Subscrição', linha: 2, negocio: 'Automóvel',
  vigencia_inicio: '2026-10-27', vigencia_fim: '2026-10-29', nome: 'R', fator_original: '1.03', fator: 1.03,
  tipo: 'Agravo/Desconto', modelo: 'Ituran Compreensiva', variaveis: [], campos_com_erro: [],
  status: 'pendente', detalhe: '', print_url: null, ...parcial,
});

describe('formatos da tabela de regras', () => {
  it('mostra o fator como no Figma', () => {
    expect(fator(regra({ fator: 1.03 }))).toBe('×1,03');
    expect(fator(regra({ fator: 0.95 }))).toBe('×0,95');
    expect(fator(regra({ modulo: 'Oferta', fator: 6 }))).toBe('6%');
    expect(fator(regra({ fator: null, fator_original: '1,1O', campos_com_erro: ['fator'] }))).toBe('1,1O');
  });

  it('formata vigência, variáveis e tamanho', () => {
    expect(vigencia(regra({}))).toBe('27/10/2026 – 29/10/2026');
    expect(variavel({ nome: 'Classe de Bônus', codigo: 40, acao: 'Inclusão', valores: ['5', '6', '7'] }))
      .toBe('Classe de Bônus (40) · Inclusão: 5; 6; 7');
    expect(tamanho(48 * 1024)).toBe('48 KB');
  });
});
