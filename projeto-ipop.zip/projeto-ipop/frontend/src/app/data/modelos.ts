/** Contrato da API (backend/app/main.py). */

export type TagStatus = 'success' | 'processing' | 'warning' | 'error' | 'default' | 'info';

export interface StatusSolicitacao {
  codigo: 'recebida' | 'conferindo' | 'cadastrando' | 'concluida' | 'erro' | 'cancelada';
  rotulo: string;
  tag: TagStatus;
}

export interface VariavelRegra {
  nome: string;
  codigo: number | null;
  acao: 'Inclusão' | 'Exclusão';
  valores: string[];
}

export type SituacaoRegra =
  | 'pendente' | 'executando' | 'confirmada' | 'salva_sem_confirmacao' | 'erro' | 'verificar' | 'não executada' | 'pulada';

export interface RegraTela {
  n: number;
  aba: string;
  modulo: 'Subscrição' | 'Oferta';
  linha: number;
  negocio: string;
  vigencia_inicio: string;
  vigencia_fim: string;
  nome: string;
  fator_original: string;
  fator: number | null;
  tipo: string;
  modelo: string;
  variaveis: VariavelRegra[];
  campos_com_erro: string[];
  status: SituacaoRegra;
  detalhe: string;
  print_url: string | null;
}

export interface Problema {
  nivel: 'erro' | 'aviso';
  aba: string;
  linha: number;
  nome: string;
  campo: string;
  mensagem: string;
}

export interface ResumoRegras {
  subscricao: number;
  oferta: number;
  total: number;
  cadastradas: number;
}

export interface Validacao {
  id: string;
  status: 'validando' | 'valido' | 'com_erros' | 'falhou';
  mensagem: string;
  arquivo: { nome: string; tamanho: number; validado_em: string | null };
  resumo: ResumoRegras;
  regras: RegraTela[];
  erros: Problema[];
  avisos: Problema[];
}

export interface SolicitacaoResumo {
  id: string;
  lote_id: string;
  titulo: string;
  solicitante: string;
  categoria: string;
  criada_em: string;
  terminou_em: string | null;
  status: StatusSolicitacao;
  total_regras: number;
}

export interface EventoAndamento {
  criado_em: string;
  tipo: string;
  titulo: string;
  detalhe: string;
  responsavel: string;
}

export interface Solicitacao extends SolicitacaoResumo {
  usuario: string;
  ambiente: 'hml' | 'prd';
  fase: string;
  mensagem: string;
  ativa: boolean;
  pode_cancelar: boolean;
  pode_retomar: boolean;
  retomar_de: number | null;
  arquivo: { nome: string; tamanho: number; url: string };
  resumo: ResumoRegras;
  regras: RegraTela[];
  problemas: Problema[];
  eventos: EventoAndamento[];
}

export interface ConfigTela {
  usuario: string;
  categorias: string[];
  ambiente: 'hml' | 'prd';
  tamanho_maximo_mb: number;
  worker_online: boolean;
}

export interface NovaSolicitacao {
  validacao_id: string;
  titulo: string;
  lote_id: string;
  solicitante: string;
  categoria: string;
}
