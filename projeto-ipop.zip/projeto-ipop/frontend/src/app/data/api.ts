import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { Observable, catchError, tap, throwError } from 'rxjs';

import {
  ConfigTela, NovaSolicitacao, Solicitacao, SolicitacaoResumo, StatusSolicitacao, Validacao,
} from './modelos';

/** Acesso à API. Mesma origem: o nginx do frontend repassa /api para o serviço api. */
@Injectable({ providedIn: 'root' })
export class IpopApi {
  private readonly http = inject(HttpClient);
  readonly config = signal<ConfigTela | null>(null);

  carregarConfig(): Observable<ConfigTela> {
    return this.http.get<ConfigTela>('/api/config').pipe(tap(c => this.config.set(c)));
  }

  validar(arquivo: File): Observable<{ id: string }> {
    const dados = new FormData();
    dados.append('arquivo', arquivo, arquivo.name);
    return this.http.post<{ id: string }>('/api/validacoes', dados).pipe(catchError(tratarErro));
  }

  validacao(id: string): Observable<Validacao> {
    return this.http.get<Validacao>(`/api/validacoes/${id}`).pipe(catchError(tratarErro));
  }

  enviar(dados: NovaSolicitacao): Observable<Solicitacao> {
    return this.http.post<Solicitacao>('/api/solicitacoes', dados).pipe(catchError(tratarErro));
  }

  listar(busca = '', status: StatusSolicitacao['codigo'] | '' = ''): Observable<SolicitacaoResumo[]> {
    return this.http.get<SolicitacaoResumo[]>('/api/solicitacoes', { params: { busca, status } }).pipe(catchError(tratarErro));
  }

  solicitacao(id: string): Observable<Solicitacao> {
    return this.http.get<Solicitacao>(`/api/solicitacoes/${id}`).pipe(catchError(tratarErro));
  }

  cancelar(id: string): Observable<unknown> {
    return this.http.post(`/api/solicitacoes/${id}/cancelar`, {}).pipe(catchError(tratarErro));
  }

  retomar(id: string, inicio?: number): Observable<Solicitacao> {
    return this.http.post<Solicitacao>(`/api/solicitacoes/${id}/retomar`, inicio ? { inicio } : {}).pipe(catchError(tratarErro));
  }

  readonly urlModelo = '/api/modelo-planilha';
}

/** Converte o erro HTTP na mensagem que a API mandou em "detail". */
function tratarErro(erro: HttpErrorResponse) {
  const detalhe = erro.error?.detail;
  const mensagem = typeof detalhe === 'string' ? detalhe
    : Array.isArray(detalhe) ? detalhe.map((d: { msg: string }) => d.msg).join(' ')
    : erro.status === 0 ? 'Sem conexão com o servidor.' : `Erro ${erro.status} ao falar com o servidor.`;
  return throwError(() => new Error(mensagem));
}
