# Frontend · Cadastro de Regras IPOP

Angular 22 + NG-ZORRO 22, seguindo o Figma *Design-System-HDI---PAINEL* (Page 04.1).
Instruções completas no [README da raiz](../README.md).

```bash
npm ci
npx ng serve --proxy-config proxy.conf.json   # API em http://localhost:8000
npx ng test --watch=false
npx ng build
```
