#!/bin/sh
# Cria o arquivo de senha do nginx a partir de WEB_USUARIO / WEB_SENHA.
set -eu
: "${WEB_USUARIO:?Defina WEB_USUARIO}"
: "${WEB_SENHA:?Defina WEB_SENHA}"
printf '%s:{PLAIN}%s\n' "$WEB_USUARIO" "$WEB_SENHA" > /etc/nginx/htpasswd
chmod 640 /etc/nginx/htpasswd
