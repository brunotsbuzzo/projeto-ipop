"""Configuração lida de variáveis de ambiente (e de um arquivo .env, se existir).

Nenhuma senha fica no código. Veja .env.example para a lista completa.
"""
from __future__ import annotations

import os
import re
import socket
from dataclasses import dataclass, field
from pathlib import Path

try:  # python-dotenv é opcional: em Docker/systemd as variáveis já chegam prontas
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover
    load_dotenv = None

RAIZ_PROJETO = Path(__file__).resolve().parent.parent

if load_dotenv is not None:
    load_dotenv(os.getenv("ROBO_ENV_FILE", RAIZ_PROJETO / ".env"), override=False)


def _bool(nome: str, padrao: bool = False) -> bool:
    valor = os.getenv(nome)
    if valor is None or not valor.strip():
        return padrao
    return valor.strip().lower() in {"1", "true", "sim", "yes", "on"}


def _int(nome: str, padrao: int) -> int:
    valor = os.getenv(nome)
    return int(valor) if valor and valor.strip() else padrao


AMBIENTES = ("hml", "prd")


@dataclass(frozen=True)
class Config:
    # Pastas
    dados_dir: Path = field(default_factory=lambda: Path(os.getenv("DADOS_DIR", RAIZ_PROJETO / "dados")))

    # IPOP
    ipop_usuario: str = field(default_factory=lambda: os.getenv("IPOP_USUARIO", ""))
    ipop_senha: str = field(default_factory=lambda: os.getenv("IPOP_SENHA", ""))
    ipop_url_hml: str = field(
        default_factory=lambda: os.getenv("IPOP_URL_HML", "https://net.hdi.com.br/rosie/ipop_v4/login")
    )
    ipop_url_prd: str = field(
        default_factory=lambda: os.getenv("IPOP_URL_PRD", "https://www.hdi.com.br/rosie/ipop_v4/login")
    )
    permitir_producao: bool = field(default_factory=lambda: _bool("PERMITIR_PRODUCAO", False))
    # Ambiente em que as solicitações enviadas pela tela são cadastradas.
    robo_ambiente: str = field(default_factory=lambda: os.getenv("ROBO_AMBIENTE", "hml").strip().lower())

    # Tela
    categorias: tuple[str, ...] = field(default_factory=lambda: tuple(
        c.strip() for c in os.getenv("CATEGORIAS", "Renovação Ituran;Frota").split(";") if c.strip()))
    tamanho_maximo_mb: int = field(default_factory=lambda: _int("TAMANHO_MAXIMO_MB", 20))

    # Regra-modelo usada nas abas de Oferta que não informam modelo
    # (era fixa no robô Selenium de Oferta).
    oferta_modelo_id: int | None = field(
        default_factory=lambda: _int("OFERTA_MODELO_ID", 139278) or None
    )

    # SQL Server
    sql_driver: str = field(default_factory=lambda: os.getenv("SQL_DRIVER", "ODBC Driver 18 for SQL Server"))
    sql_servidor: str = field(default_factory=lambda: os.getenv("SQL_SERVIDOR", ""))
    sql_porta: int = field(default_factory=lambda: _int("SQL_PORTA", 1433))
    sql_banco: str = field(default_factory=lambda: os.getenv("SQL_BANCO", "RosieRep"))
    sql_usuario: str = field(default_factory=lambda: os.getenv("SQL_USUARIO", ""))
    sql_senha: str = field(default_factory=lambda: os.getenv("SQL_SENHA", ""))
    sql_trust_cert: bool = field(default_factory=lambda: _bool("SQL_TRUST_CERT", True))

    # Navegador
    headless: bool = field(default_factory=lambda: _bool("HEADLESS", True))
    # Vazio = Chromium do Playwright. "msedge" exige o Edge instalado no Linux.
    navegador_canal: str = field(default_factory=lambda: os.getenv("NAVEGADOR_CANAL", ""))
    timeout_padrao_ms: int = field(default_factory=lambda: _int("TIMEOUT_PADRAO_MS", 30_000))
    gravar_trace: bool = field(default_factory=lambda: _bool("GRAVAR_TRACE", True))

    # Web
    web_usuario: str = field(default_factory=lambda: os.getenv("WEB_USUARIO", ""))
    web_senha: str = field(default_factory=lambda: os.getenv("WEB_SENHA", ""))

    # Postgres (fila, status, log). As tabelas ficam num schema próprio,
    # então dá para usar o mesmo banco de outro sistema sem conflito.
    database_url: str = field(default_factory=lambda: os.getenv("DATABASE_URL", ""))
    db_schema: str = field(default_factory=lambda: os.getenv("DB_SCHEMA", "robo_ipop"))

    # Bucket S3 (MinIO ou qualquer S3 compatível): planilhas, prints, traces.
    s3_endpoint: str = field(default_factory=lambda: os.getenv("S3_ENDPOINT", ""))
    s3_access_key: str = field(default_factory=lambda: os.getenv("S3_ACCESS_KEY", ""))
    s3_secret_key: str = field(default_factory=lambda: os.getenv("S3_SECRET_KEY", ""))
    s3_bucket: str = field(default_factory=lambda: os.getenv("S3_BUCKET", "robo-ipop"))
    s3_regiao: str = field(default_factory=lambda: os.getenv("S3_REGIAO", "us-east-1"))

    # Worker
    worker_nome: str = field(default_factory=lambda: os.getenv("WORKER_NOME", "") or socket.gethostname())
    worker_intervalo_s: int = field(default_factory=lambda: _int("WORKER_INTERVALO_S", 5))

    @property
    def tbl_dim_dir(self) -> Path:
        return self.dados_dir / "tbl_dim"

    @property
    def execucoes_dir(self) -> Path:
        return self.dados_dir / "execucoes"

    def url_login(self, ambiente: str) -> str:
        if ambiente == "hml":
            return self.ipop_url_hml
        if ambiente == "prd":
            return self.ipop_url_prd
        raise ValueError(f"Ambiente inválido: {ambiente!r}. Use 'hml' ou 'prd'.")

    def string_conexao_sql(self) -> str:
        servidor = self.sql_servidor
        if self.sql_porta and "," not in servidor:
            servidor = f"{servidor},{self.sql_porta}"
        partes = [
            f"DRIVER={{{self.sql_driver}}}",
            f"SERVER={servidor}",
            f"DATABASE={self.sql_banco}",
            f"UID={self.sql_usuario}",
            f"PWD={{{self.sql_senha.replace('}', '}}')}}}",  # "}" dentro de {} vira "}}" no ODBC
            "Encrypt=yes",
            f"TrustServerCertificate={'yes' if self.sql_trust_cert else 'no'}",
            "Connection Timeout=15",
        ]
        return ";".join(partes) + ";"

    def __post_init__(self):
        if self.robo_ambiente not in AMBIENTES:
            raise ValueError(f"ROBO_AMBIENTE inválido: {self.robo_ambiente!r}. Use 'hml' ou 'prd'.")
        if self.robo_ambiente == "prd" and not self.permitir_producao:
            raise ValueError("ROBO_AMBIENTE=prd exige PERMITIR_PRODUCAO=true.")
        if not re.fullmatch(r"[a-z_][a-z0-9_]{0,62}", self.db_schema):
            raise ValueError(f"DB_SCHEMA inválido: {self.db_schema!r} (use letras minúsculas, números e _).")

    def faltando_infra(self) -> list[str]:
        """Variáveis que a API e o worker precisam para falar com o Postgres e o bucket."""
        obrigatorias = {
            "DATABASE_URL": self.database_url,
            "S3_ENDPOINT": self.s3_endpoint,
            "S3_ACCESS_KEY": self.s3_access_key,
            "S3_SECRET_KEY": self.s3_secret_key,
        }
        return [nome for nome, valor in obrigatorias.items() if not valor]

    def faltando(self, *, precisa_navegador: bool) -> list[str]:
        """Lista as variáveis obrigatórias que não foram preenchidas."""
        obrigatorias = {
            "SQL_SERVIDOR": self.sql_servidor,
            "SQL_USUARIO": self.sql_usuario,
            "SQL_SENHA": self.sql_senha,
        }
        if precisa_navegador:
            obrigatorias.update({"IPOP_USUARIO": self.ipop_usuario, "IPOP_SENHA": self.ipop_senha})
        return [nome for nome, valor in obrigatorias.items() if not valor]


def carregar() -> Config:
    return Config()
