"""Tela de lista de regras: pesquisar, copiar o modelo e abrir a cópia (antiga BasePage)."""
from __future__ import annotations

import logging
import re

from playwright.sync_api import Locator, Page, expect

logger = logging.getLogger(__name__)


class ListaRegrasPage:
    SELETORES_BUSCA_ID = (
        "#pesquisar_idregra_input",
        "input[placeholder='Pesquisar por código']",
        "input[placeholder*='Pesquisar por código']",
    )

    def __init__(self, page: Page):
        self.page = page
        self.busca_nome: Locator = page.locator('input[placeholder="Pesquisar"][aria-controls="regras_lista"]')
        self.tabela_linhas: Locator = page.locator("#regras_lista tbody tr")
        self.processando: Locator = page.locator("#regras_lista_processing")
        self.nova_btn: Locator = page.get_by_role("button", name="Nova", exact=True)
        self.copiar_btn: Locator = page.locator("button.btn.btn-primary:has-text('Copiar')")
        self.confirmar_btn: Locator = page.locator("button:has-text('Confirmar')")
        self.detalhes_btn: Locator = page.locator("button", has_text="Detalhes")
        self.editar_btn: Locator = page.locator("button", has_text="Editar")

    # ---------- esperas ----------
    def esperar_tabela(self, timeout: int = 60_000) -> None:
        if self.processando.count() > 0:
            expect(self.processando).to_be_hidden(timeout=timeout)

    def esperar_carregamento(self, timeout: int = 60_000) -> None:
        indicadores = self.page.locator(
            "div.dataTables_processing:visible, .loading:visible, .spinner:visible, "
            ".processing:visible, .overlay:visible"
        )
        try:
            expect(indicadores).to_have_count(0, timeout=timeout)
        except AssertionError:
            logger.warning("Indicador de carregamento ainda visível após %d ms; seguindo.", timeout)

    def esperar_lista_pronta(self, timeout: int = 60_000) -> None:
        expect(self.busca_nome).to_be_editable(timeout=timeout)
        self.esperar_carregamento(timeout)

    # ---------- busca ----------
    def pesquisar_por_id(self, id_regra: int) -> None:
        for seletor in self.SELETORES_BUSCA_ID:
            campo = self.page.locator(seletor)
            if campo.count() == 0:
                continue
            expect(campo.first).to_be_editable(timeout=5_000)
            campo.first.fill(str(id_regra))
            campo.first.press("Enter")
            self.esperar_tabela()
            return
        # Sem campo de código: a busca geral do DataTables também encontra o ID.
        self.pesquisar_por_nome(str(id_regra))

    def pesquisar_por_nome(self, nome: str) -> None:
        expect(self.busca_nome).to_be_editable(timeout=10_000)
        self.busca_nome.fill(str(nome))
        self.busca_nome.press("Enter")
        self.esperar_tabela()

    def selecionar_por_id(self, id_regra: int, timeout: int = 15_000) -> None:
        linha = self.page.locator(f'#regras_lista tbody tr[id="{id_regra}"], tr[id="{id_regra}"]').first
        try:
            expect(linha).to_be_visible(timeout=timeout)
        except AssertionError:
            celula = self.page.locator("td").filter(has_text=re.compile(rf"^\s*{id_regra}\s*$")).first
            expect(celula).to_be_visible(timeout=timeout)
            linha = celula.locator("xpath=ancestor::tr")
        linha.click()

    def selecionar_por_nome(self, nome: str, timeout: int = 15_000) -> None:
        celula = self.page.locator("#regras_lista td, td.text-center").filter(has_text=nome).first
        expect(celula).to_be_visible(timeout=timeout)
        celula.locator("xpath=ancestor::tr").click()

    def selecionar_primeira_linha(self, timeout: int = 15_000) -> None:
        expect(self.tabela_linhas.first).to_be_visible(timeout=timeout)
        self.tabela_linhas.first.click()

    def regra_existe(self, nome: str, timeout: int = 15_000) -> bool:
        self.pesquisar_por_nome(nome)
        celula = self.page.locator("#regras_lista td").filter(has_text=re.compile(rf"^\s*{re.escape(nome)}\s*$"))
        try:
            expect(celula.first).to_be_visible(timeout=timeout)
            return True
        except AssertionError:
            return False

    # ---------- ações ----------
    def abrir_nova_regra(self) -> None:
        self.nova_btn.click()

    def copiar_selecionada(self) -> None:
        self.copiar_btn.click()
        self.confirmar_btn.click()
        expect(self.confirmar_btn.first).to_be_hidden(timeout=30_000)
        self.esperar_tabela()

    def abrir_selecionada(self) -> None:
        """Abre a regra selecionada. Subscrição usa 'Detalhes'; a Oferta antiga usava 'Editar'."""
        for botao in (self.detalhes_btn, self.editar_btn):
            if botao.count() > 0 and botao.first.is_visible():
                botao.first.click()
                return
        self.detalhes_btn.first.click(timeout=10_000)
