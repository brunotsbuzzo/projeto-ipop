"""Uma execução completa: checar rede -> ler e validar o pedido -> cadastrar no IPOP.

`pasta` é a pasta de trabalho local (o pedido já baixado fica nela). O andamento
vai para `progresso`: status.json na linha de comando, Postgres + bucket no worker.
Arquivos produzidos:
    regras_enriquecidas.json
    erros/regra_NNN.png   print da tela quando uma regra falha
    trace.zip             gravação do Playwright (abra em https://trace.playwright.dev)
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from ipop.config import Config
from ipop.conectividade import como_dicts, verificar
from ipop.progresso import Progresso, agora
from ipop.services.construtor_regras import ConstrutorRegras, ErroValidacao

logger = logging.getLogger("ipop.robo")


class Parado(Exception):
    def __init__(self, fase: str, mensagem: str):
        super().__init__(mensagem)
        self.fase = fase


def _resumo_regra(indice: int, regra) -> dict[str, Any]:
    return {
        "n": indice + 1,
        "nome": regra.nome_regra,
        "aba": regra.nome_aba,
        "linha": regra.linha_planilha,
        "modulo": regra.modulo,
        "tipo": type(regra).__name__.replace("Regra", "") or "Base",
        "percentual": regra.ajuste,
        "vigencia": f"{regra.data_inicial} a {regra.data_final}",
        "modelo": regra.id_regra_modelo,
        "variaveis": len(regra.variaveis),
        "status": "pendente",
        "detalhe": "",
    }


def _resumo_previa(p: dict) -> dict[str, Any]:
    """Linha da tabela de regras quando a planilha tem erros (não há objeto de regra)."""
    return {
        "n": p["n"], "nome": p["nome"], "aba": p["aba"], "linha": p["linha"], "modulo": p["modulo"],
        "tipo": p["tipo"], "percentual": p["fator"], "vigencia": f"{p['vigencia_inicio']} a {p['vigencia_fim']}",
        "modelo": p["id_modelo"], "variaveis": len(p["variaveis"]), "status": "pendente", "detalhe": "", "dados": p,
    }


def _plural(n: int, um: str, varios: str) -> str:
    return f"{n} {um if n == 1 else varios}"


def _contagem(previa: list[dict]) -> str:
    subs = sum(1 for p in previa if p["modulo"] == "Subscrição")
    ofer = len(previa) - subs
    partes = []
    if subs:
        partes.append(_plural(subs, "regra de subscrição", "regras de subscrição"))
    if ofer:
        partes.append(_plural(ofer, "agrupamento de oferta", "agrupamentos de oferta"))
    return " e ".join(partes) or "nenhuma regra"


def _checar_parada(progresso: Progresso) -> None:
    pedido = progresso.deve_parar()
    if pedido:
        raise Parado(*pedido)


def executar(pasta: Path, config: Config, progresso: Progresso, parametros: dict[str, Any],
             *, tbl_dim_dir: Path | None = None) -> int:
    """Roda uma execução. `parametros["pedido"]` é o nome do Excel dentro de `pasta`.

    `tbl_dim_dir`: onde estão TblDePara/TblRegraModelo (padrão: dados/tbl_dim).

    Devolve o código de saída (0 = sucesso).
    """
    ambiente = parametros.get("ambiente", "hml")
    so_dados = bool(parametros.get("so_dados", True))

    try:
        # 1. Configuração e rede
        faltando = config.faltando(precisa_navegador=not so_dados)
        if faltando:
            progresso.fase("erro", f"Faltam variáveis no .env: {', '.join(faltando)}.")
            return 2
        if ambiente == "prd" and not so_dados and not config.permitir_producao:
            progresso.fase("erro", "Produção bloqueada. Defina PERMITIR_PRODUCAO=true no .env do servidor para liberar.")
            return 2

        progresso.fase("verificando_rede", "Testando acesso ao IPOP e ao SQL Server...")
        checagens = verificar(config, ambiente)
        progresso.registrar(conectividade=como_dicts(checagens))
        obrigatorias = [c for c in checagens if not (so_dados and c.nome.startswith("IPOP"))]
        falhas = [c for c in obrigatorias if not c.ok]
        for c in checagens:
            (logger.info if c.ok else logger.error)("[rede] %s %s: %s", c.nome, c.destino, c.detalhe)
        if falhas:
            progresso.fase("erro", "Sem acesso: " + "; ".join(f"{c.nome} ({c.detalhe})" for c in falhas))
            return 3

        # 2. Planilha
        progresso.fase("lendo_planilha", "Lendo o pedido e consultando o SQL Server...")
        construtor = ConstrutorRegras(
            config, pasta / parametros["pedido"], caminho_saida_json=pasta / "regras_enriquecidas.json",
            tbl_dim_dir=tbl_dim_dir,
        )
        try:
            regras = construtor.executar()
        except ErroValidacao as erro:
            _publicar_json(pasta, progresso)
            progresso.registrar(erros_validacao=erro.erros, avisos=erro.avisos, problemas=erro.problemas)
            progresso.definir_regras([_resumo_previa(p) for p in construtor.previa()])
            progresso.fase("erro_validacao", str(erro).splitlines()[0])
            return 4
        _publicar_json(pasta, progresso)
        progresso.registrar(avisos=construtor.avisos, problemas=construtor.problemas)
        previa = construtor.previa()
        progresso.definir_regras([{**_resumo_regra(i, r), "dados": previa[i]} for i, r in enumerate(regras)])
        progresso.evento("dados_conferidos", "Dados conferidos",
                         f"Planilha lida e conferida com as tabelas do IPOP: {_contagem(previa)}"
                         + (f", {_plural(len(construtor.avisos), 'aviso', 'avisos')}." if construtor.avisos else ", sem erros."))

        if so_dados:
            progresso.fase(
                "concluida_so_dados",
                f"{len(regras)} regra(s) conferidas. Nada foi cadastrado no IPOP (modo só dados).",
            )
            return 0

        # 3. Navegador
        _checar_parada(progresso)
        inicio = max(1, int(parametros.get("inicio", 1)))
        for i in range(min(inicio - 1, len(regras))):
            progresso.atualizar_regra(i, status="pulada", detalhe=f"Execução começou na regra {inicio}.")
        return _cadastrar(pasta, config, progresso, regras, ambiente, inicio, bool(parametros.get("continuar_em_erro")))

    except Parado as parada:
        progresso.marcar_restantes("não executada")
        progresso.evento(parada.fase, "Cancelada" if parada.fase == "cancelada" else "Interrompida", str(parada))
        progresso.fase(parada.fase, str(parada))
        return 130
    except Exception as erro:
        logger.exception("Erro inesperado")
        progresso.marcar_restantes("não executada")
        progresso.evento("erro", "Erro", f"{type(erro).__name__}: {str(erro)[:300]}")
        progresso.fase("erro", f"{type(erro).__name__}: {erro}")
        return 1


def _publicar_json(pasta: Path, progresso: Progresso) -> None:
    caminho = pasta / "regras_enriquecidas.json"
    if caminho.exists():
        progresso.guardar_arquivo(caminho, caminho.name)


def _cadastrar(pasta: Path, config: Config, progresso: Progresso, regras, ambiente: str,
               inicio: int, continuar_em_erro: bool) -> int:
    from playwright.sync_api import sync_playwright

    from ipop.pages.login_home import HomePage, LoginPage
    from ipop.services.cadastro import CadastroService

    pasta_erros = pasta / "erros"
    pasta_erros.mkdir(exist_ok=True)
    ok = falhas = 0

    with sync_playwright() as p:
        opcoes: dict[str, Any] = {"headless": config.headless}
        if config.navegador_canal:
            opcoes["channel"] = config.navegador_canal
        navegador = p.chromium.launch(**opcoes)
        contexto = navegador.new_context(
            locale="pt-BR", timezone_id="America/Sao_Paulo", viewport={"width": 1600, "height": 1000}
        )
        contexto.set_default_timeout(config.timeout_padrao_ms)
        if config.gravar_trace:
            contexto.tracing.start(screenshots=True, snapshots=True)
        page = contexto.new_page()
        teve_erro = False
        try:
            progresso.fase("login", f"Entrando no IPOP ({ambiente})...")
            LoginPage(page, config.url_login(ambiente)).entrar(config.ipop_usuario, config.ipop_senha)
            home = HomePage(page)
            servico = CadastroService(page)
            modulo_atual = None

            progresso.fase("cadastrando", f"Cadastrando a partir da regra {inicio} de {len(regras)}...")
            progresso.evento("cadastrando", "Cadastrando no IPOP",
                             f"O robô entrou no IPOP ({ambiente}) e começou pela regra {inicio} de {len(regras)}.")
            for indice in range(inicio - 1, len(regras)):
                _checar_parada(progresso)
                regra = regras[indice]
                progresso.atualizar_regra(indice, status="executando", inicio=agora())
                logger.info("=== Regra %d/%d: %s", indice + 1, len(regras), regra.nome_regra)
                try:
                    if regra.modulo != modulo_atual:
                        home.acessar_modulo(regra.modulo)
                        modulo_atual = regra.modulo
                    resultado = servico.cadastrar(regra)
                except Exception as erro:
                    teve_erro = True
                    falhas += 1
                    print_erro = pasta_erros / f"regra_{indice + 1:03d}.png"
                    nome_print = None
                    try:
                        page.screenshot(path=str(print_erro), full_page=True)
                        nome_print = progresso.guardar_arquivo(print_erro, f"erros/{print_erro.name}")
                    except Exception:
                        logger.warning("Não foi possível guardar o print da regra %d.", indice + 1)
                    logger.exception("Falhou a regra %d (%s)", indice + 1, regra.nome_regra)
                    progresso.atualizar_regra(
                        indice, status="erro", fim=agora(), detalhe=_resumir_erro(erro), print=nome_print,
                    )
                    if not continuar_em_erro:
                        progresso.marcar_restantes("não executada")
                        progresso.evento("parou", f"Parou na regra {indice + 1}",
                                         f"{regra.nome_regra}: {_resumir_erro(erro)} O print da tela foi guardado.")
                        progresso.fase(
                            "erro",
                            f"Parou na regra {indice + 1} ({regra.nome_regra}). {ok} cadastrada(s) antes dela. "
                            f"Corrija e rode de novo começando da regra {indice + 1}.",
                        )
                        return 5
                    modulo_atual = None
                    _recuperar_tela(page)
                    continue

                ok += 1
                progresso.atualizar_regra(
                    indice, status=resultado, fim=agora(),
                    detalhe="Encontrada na lista após salvar." if resultado == "confirmada"
                    else "Salva, mas não apareceu na busca. Confira no IPOP.",
                )

            fase = "concluida" if not falhas else "erro"
            if not falhas:
                progresso.evento("concluida", "Concluída",
                                 f"{_plural(ok, 'regra cadastrada e conferida', 'regras cadastradas e conferidas')} na lista do IPOP.")
            else:
                progresso.evento("parou", "Terminou com erros",
                                 f"{_plural(ok, 'regra cadastrada', 'regras cadastradas')}, {falhas} com erro.")
            progresso.fase(fase, f"{_plural(ok, 'regra cadastrada', 'regras cadastradas')}, {falhas} com erro.")
            return 0 if not falhas else 5
        except BaseException:
            teve_erro = True  # login falhou, parada pedida etc.: guarda o trace
            raise
        finally:
            if config.gravar_trace:
                guardar = teve_erro or falhas
                try:
                    contexto.tracing.stop(path=str(pasta / "trace.zip") if guardar else None)
                    if guardar:
                        progresso.guardar_arquivo(pasta / "trace.zip", "trace.zip")
                except Exception:
                    logger.warning("Não foi possível salvar o trace.")
            navegador.close()


def _resumir_erro(erro: Exception) -> str:
    """Frase curta para a tela; o texto técnico completo fica no log e no trace."""
    nome = type(erro).__name__
    texto = (str(erro).strip().splitlines() or [""])[0]
    if nome == "AssertionError" or "expected to be" in texto:
        return "Um campo ou valor esperado não apareceu na tela do IPOP."
    if nome == "TimeoutError" or "Timeout" in texto:
        return "O IPOP demorou demais para responder."
    if nome in {"RuntimeError", "ErroLogin"} and texto:
        return texto[:300] if texto.endswith(".") else texto[:300] + "."
    return f"{nome}: {texto[:280]}"


def _recuperar_tela(page) -> None:
    """Depois de um erro, tenta fechar o formulário aberto sem salvar."""
    try:
        botao_fechar = page.locator("button.btn.btn-outline-light.btn-sm:not(.position-absolute)")
        if botao_fechar.count() and botao_fechar.first.is_visible():
            botao_fechar.first.click(timeout=5_000)
        page.keyboard.press("Escape")
    except Exception:
        logger.warning("Não consegui fechar a tela da regra com erro.")
