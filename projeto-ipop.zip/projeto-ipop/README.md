# Cadastro de Regras IPOP

Tela para pedir o cadastro de regras de preço no IPOP (HDI) e robô que faz o
cadastro sozinho. A pessoa envia a planilha do pedido, confere a pré-visualização
e acompanha o cadastro regra por regra. As telas seguem o Figma
*Design-System-HDI---PAINEL*, Page **04.1 - Cadastro de Regras IPOP · fluxo com robô**.

```
 navegador ──▶ web (nginx + Angular) ──/api──▶ api (FastAPI) ──▶ MinIO   (planilhas, prints, traces, logs)
                                                    │          └▶ Postgres (fila, andamento, eventos)
                                                    ▼
                                       worker (robô Playwright) ──▶ IPOP (Chromium headless)
                                                                 └▶ SQL Server RosieRep (consulta)
```

| Serviço | O que faz |
|---|---|
| `web` | Serve o Angular (NG-ZORRO) e repassa `/api` para a API. Pede login (HTTP Basic). |
| `api` | Recebe a planilha, grava no MinIO, cria a execução no Postgres e responde à tela. |
| `worker` | Pega execuções no Postgres. **Validação** (confere a planilha, sem abrir o IPOP) roda ao lado do **cadastro** (abre o IPOP). Só há um cadastro por vez em todo o sistema, garantido por advisory lock do Postgres. |
| `postgres`, `pgadmin`, `minio` | Os mesmos do seu compose. As tabelas do robô ficam no schema `robo_ipop`. |

Não há RabbitMQ: a fila é a própria tabela `execucoes` (`FOR UPDATE SKIP LOCKED` + `LISTEN/NOTIFY`).
Assim a fila e o andamento ficam no mesmo lugar, e uma execução nunca volta
sozinha para a fila, o que poderia cadastrar regras em dobro.

## Como subir

```bash
cp .env.example .env        # preencha IPOP_*, SQL_* e WEB_*
docker compose up -d --build
docker compose logs -f worker
```

- Tela: <http://localhost:8080> (usuário e senha de `WEB_USUARIO`/`WEB_SENHA`)
- pgAdmin: <http://localhost:5050> · MinIO: <http://localhost:9001>

A API cria sozinha o schema `robo_ipop` e o bucket `robo-ipop` na primeira subida.

**O worker precisa enxergar a rede da HDI** (IPOP na porta 443 e SQL Server na
1433). Para testar o acesso de dentro do container:

```bash
docker compose run --rm worker python -m ipop.cli --checar-rede --ambiente hml
```

Se o nome `HDIWROSIE01` não resolver, use o nome completo ou o IP em
`SQL_SERVIDOR`, ou descomente `extra_hosts`/`dns` no serviço `worker`.

## Fluxo na tela

1. **Nova solicitação:** título, ID do lote (Taskflow), solicitante, categoria e a planilha.
2. **Validação:** a planilha vai para o MinIO e o worker a confere com as tabelas do IPOP e com o SQL Server, sem abrir o navegador. A tela mostra cada regra, os **erros** (bloqueiam o envio, com a célula marcada em vermelho) e os **avisos** (não bloqueiam).
3. **Envio:** a solicitação entra na fila com o status *Recebida*.
4. **Cadastro:** o worker confere de novo (*Conferindo dados*), cadastra uma regra por vez (*Cadastrando · 2 de 4*) e confere cada regra na lista do IPOP depois de salvar.
5. **Se parar:** o detalhe mostra o motivo, o print da tela e o botão **Retomar da regra N**. As regras já cadastradas não são criadas de novo.

| Status na tela | Fase técnica | Status Tag |
|---|---|---|
| Recebida | na fila | info |
| Conferindo dados | lendo planilha / testando rede | processing |
| Cadastrando · N de M | login / cadastrando | processing |
| Concluída | concluída | success |
| Parou na regra N / Planilha com erros / Interrompida | erro, erro de validação, interrompida | error |
| Cancelada | cancelada | default |

**Ambiente:** o IPOP em que as solicitações são cadastradas vem de `ROBO_AMBIENTE`
(`hml` por padrão). Usar `prd` exige também `PERMITIR_PRODUCAO=true`.

## Operação

- **Atualizar as tabelas de modelos e variáveis** (`TblRegraModelo.xlsx`, `TblDePara.xlsx`): envie as duas pelo console do MinIO para `robo-ipop/config/tbl_dim/`. O worker usa as do bucket quando existem e, se não, as que vêm na imagem (`backend/dados/tbl_dim`). A planilha-modelo (botão "Baixar modelo") é gerada a partir delas.
- **Arquivos de cada solicitação:** ficam no MinIO em `robo-ipop/execucoes/<id>/`: `pedido.xlsx`, `regras_enriquecidas.json`, `erros/regra_NNN.png`, `trace.zip` (abra em <https://trace.playwright.dev>) e `execucao.log`.
- **Worker caiu no meio:** depois de 2 minutos sem sinal de vida, a execução vira *Interrompida* e a regra que estava no meio fica como **Conferir no IPOP**, porque ela pode ter sido salva. Confira no IPOP e clique em Retomar.
- **Parar o worker** (`docker compose stop worker`): o robô termina a regra atual e sai (`stop_grace_period: 5m`). A execução fica *Interrompida* e pode ser retomada.
- **Cancelar:** pelo botão no detalhe. O robô para depois da regra que está cadastrando.
- **Logs:** `docker compose logs -f api worker`. O log de cada execução também fica no Postgres (`robo_ipop.logs`) e no MinIO.

## Estrutura

```
docker-compose.yml   .env.example
backend/
  Dockerfile               uma imagem para api e worker (Chromium + ODBC 18)
  app/main.py              API REST usada pela tela
  app/modelo_planilha.py   planilha-modelo para download
  ipop/worker.py           worker: filas de validação e de cadastro, batimento, órfãs
  ipop/robo.py             uma execução: rede → planilha → SQL → validação → IPOP
  ipop/infra/              Postgres (db.py), MinIO/S3 (armazenamento.py), andamento (progresso_banco.py)
  ipop/services/           leitura do Excel, enriquecimento SQL, validação, cadastro na tela
  ipop/pages/              seletores das telas do IPOP (Playwright)
  ipop/cli.py              linha de comando para depurar uma planilha sem Postgres/MinIO
  dados/tbl_dim/           tabelas auxiliares padrão
  tests/                   pytest (inclui um IPOP falso para testar o navegador)
frontend/
  Dockerfile, nginx/       build do Angular + nginx com login e proxy /api
  src/styles/_hdi-tokens.scss   tokens --hdi-* do design system (Figma)
  src/app/shared/          Status Tag, título de seção, cartão de arquivo, tabela de regras, linha do tempo
  src/app/pages/           Início, Nova solicitação, Envio confirmado, Histórico, Detalhe, Dúvidas
```

## API

Documentação interativa em `/api/docs` (pela porta do `web`, já autenticado).

| Método | Rota | Uso |
|---|---|---|
| GET | `/api/config` | usuário, categorias, ambiente, limite de tamanho, worker online |
| GET | `/api/modelo-planilha` | planilha-modelo |
| POST | `/api/validacoes` | multipart `arquivo` → `{id}` |
| GET | `/api/validacoes/{id}` | `validando` · `valido` · `com_erros` · `falhou`, com regras, erros e avisos |
| POST | `/api/solicitacoes` | `{validacao_id, titulo, lote_id, solicitante, categoria}` |
| GET | `/api/solicitacoes?busca=&status=` | histórico |
| GET | `/api/solicitacoes/{id}` | detalhe, regras com situação, eventos |
| POST | `/api/solicitacoes/{id}/cancelar` | cancela (na fila: na hora; em andamento: após a regra atual) |
| POST | `/api/solicitacoes/{id}/retomar` | `{inicio?}`, padrão: a primeira regra não cadastrada |
| GET | `/api/solicitacoes/{id}/arquivo` · `/arquivos/{caminho}` · `/log` | planilha, prints e trace, log |
| GET/POST | `/api/workers` · `/api/workers/checar` | workers online e teste de rede |

## Desenvolvimento e testes

```bash
# backend
cd backend
pip install -r requirements-dev.txt && playwright install chromium
python -m pytest -q          # usa um Postgres local temporário (ou TEST_DATABASE_URL) e S3 do moto

# pilha completa local, sem Docker (Postgres + S3 falso + IPOP falso + API + worker)
cd ../frontend && npm ci && npx ng build && cd ../backend
python -m tests.demo.pilha_demo    # http://127.0.0.1:8090  usuário renata / senha demo

# frontend com recarga automática contra uma API rodando
cd frontend && npx ng serve --proxy-config proxy.conf.json
```

Os testes do backend sobem o robô de verdade no Chromium headless contra
`tests/ipop_falso/`, uma imitação das telas do IPOP com os mesmos seletores. Eles
cobrem validação, envio, cadastro, parada no erro, retomada sem duplicar,
cancelamento, órfãs e a trava "Cópia de". Isso prova o fluxo, não as telas
reais: **o primeiro lote no IPOP de homologação deve ter uma regra só.**

## Pontos de atenção

- **Senhas:** troque as senhas padrão (`analise`, `minioadmin`, `admin`) antes de expor o servidor. A porta 5432 do Postgres está publicada como no seu compose original; feche-a se não precisar.
- **HTTPS:** o login é HTTP Basic. Fora de uma rede confiável, coloque HTTPS na frente do `web`.
- **MinIO:** a imagem `bitnamilegacy/minio` está congelada (a Bitnami parou de atualizar essas imagens) e o MinIO Community virou só código-fonte. O backend fala S3 puro (boto3), então trocar por outro S3 compatível é só mudar `S3_ENDPOINT` e as chaves.
- **Oferta:** o fluxo de Oferta ainda não foi testado no IPOP real; teste uma regra em homologação antes de um lote.
- **Conta do robô:** as senhas que estavam no código antigo continuam válidas até serem trocadas. Use uma conta de serviço do IPOP em `IPOP_USUARIO`.
