# API REST (`backend/app/main.py`)

FastAPI, servida por `uvicorn app.main:app --host 0.0.0.0 --port 8000 --proxy-headers`. A documentação interativa (Swagger) fica em **`/api/docs`** e o OpenAPI em `/api/openapi.json`. O ReDoc está desligado.

## Ciclo de vida

`ciclo_de_vida()` (lifespan):

1. exige `WEB_USUARIO`/`WEB_SENHA` e as variáveis de infraestrutura (`Config.faltando_infra()`); sem elas, levanta `RuntimeError` e a API não sobe;
2. cria `Repositorio` (pool de 5 conexões) e `Armazenamento`;
3. `garantir_schema()` e `garantir_bucket()`;
4. no desligamento, fecha o pool.

`CONFIG = config_mod.carregar()` roda no import: uma configuração inválida (por exemplo `prd` sem liberação) derruba o processo.

## Autenticação

Todas as rotas `/api/*` dependem de `usuario_logado` (HTTP Basic). A comparação usa `secrets.compare_digest`. Uma falha devolve `401` com `WWW-Authenticate: Basic realm="Cadastro de Regras IPOP"`. O tipo anotado `Usuario` injeta o nome do usuário.

## Identificadores

`novo_id()` gera `AAAAMMDD-HHMMSS-xxxxxx` (horário de São Paulo + 3 bytes aleatórios em hex). `_obter(id, tipo)` valida o formato com `^\d{8}-\d{6}-[0-9a-f]{6}$` e exige que o `tipo` da execução bata com a rota (uma validação não abre em `/solicitacoes`). Qualquer falha dá 404.

## Rotas

### Saúde e configuração

| Método | Rota | Login | Resposta |
|---|---|---|---|
| GET | `/saude` | não | `{"ok": true}` |
| GET | `/api/config` | sim | `{usuario, categorias[], ambiente, tamanho_maximo_mb, worker_online}` |
| GET | `/api/workers` | sim | Lista de workers: `nome, iniciado_em, visto_em, executando, conectividade[], checado_em, checagem_pedida_em, online` |
| POST | `/api/workers/checar` | sim | 202 `{"ok": true}`: pede um teste de rede a todos os workers (atendido no próximo batimento) |
| GET | `/api/modelo-planilha` | sim | Arquivo `ModeloRegras-SubseOferta.xlsx` (veja [Planilha-modelo](planilha-modelo.md)) |

### Validação

#### `POST /api/validacoes`

Multipart com o campo `arquivo`.

1. Checa a extensão (`.xlsx`/`.xlsm`), senão 422.
2. Grava num diretório temporário em blocos de 1 MB, conferindo o limite (`TAMANHO_MAXIMO_MB`), senão 413.
3. Confere a assinatura ZIP `PK\x03\x04`, senão 422.
4. Envia para `execucoes/<id>/pedido.xlsx` (numa thread, `run_in_threadpool`).
5. Cria a execução `tipo=validacao`, `so_dados=true`, `ambiente=ROBO_AMBIENTE`, e notifica a fila.

Resposta `201`:

```json
{"id": "20261105-141500-ab12cd", "status": "validando"}
```

#### `GET /api/validacoes/{id}`

```json
{
  "id": "20261105-141500-ab12cd",
  "status": "validando | valido | com_erros | falhou",
  "mensagem": "3 regra(s) conferidas. Nada foi cadastrado no IPOP (modo só dados).",
  "arquivo": {"nome": "Lote.xlsx", "tamanho": 48213, "validado_em": "2026-11-05T14:15:09-03:00"},
  "resumo": {"subscricao": 2, "oferta": 1, "total": 3, "cadastradas": 0},
  "regras": [ /* RegraTela, veja abaixo */ ],
  "erros":  [ {"nivel": "erro", "aba": "Módulo Subscrição", "linha": 3, "nome": "R_X", "campo": "fator", "mensagem": "Fator: “1,1O” não é um número."} ],
  "avisos": [ /* mesmo formato, nivel = aviso */ ]
}
```

| `status` | Fase |
|---|---|
| `valido` | `concluida_so_dados` |
| `com_erros` | `erro_validacao` |
| `falhou` | outra fase final |
| `validando` | não final |

### Solicitações

#### `POST /api/solicitacoes`

Corpo (`NovaSolicitacao`):

| Campo | Regras |
|---|---|
| `validacao_id` | Uma validação existente, com fase `concluida_so_dados` (senão 409) |
| `titulo` | 1–200 caracteres |
| `lote_id` | 1–40 |
| `solicitante` | 1–120 |
| `categoria` | 1–80 e presente em `CATEGORIAS` (senão 422) |

Também recusa (409) uma validação já usada por outra solicitação. A busca olha as últimas 500 solicitações.

Efeitos:

- cria a execução `tipo=cadastro`, com `so_dados=false`, o mesmo `objeto_pedido`, `nome_original` e `tamanho_arquivo` da validação, e `validacao_id`;
- grava o evento *Recebida* e faz `pg_notify`;
- copia as regras da validação para a nova execução com status `pendente`, para a tabela já aparecer no detalhe (o robô regrava ao conferir de novo).

Resposta `201`: a mesma de `GET /api/solicitacoes/{id}`.

#### `GET /api/solicitacoes?busca=&status=&limite=200`

- `busca`: `ILIKE` em `lote_id`, `titulo` e `solicitante`;
- `status`: código da tela (`recebida`, `conferindo`, `cadastrando`, `concluida`, `erro`, `cancelada`). O filtro é aplicado **depois** da consulta;
- `limite`: entre 1 e 500.

Cada item:

```json
{"id": "…", "lote_id": "784530", "titulo": "…", "solicitante": "…", "categoria": "…",
 "criada_em": "…", "terminou_em": null,
 "status": {"codigo": "cadastrando", "rotulo": "Cadastrando · 2 de 4", "tag": "processing"},
 "total_regras": 4}
```

#### `GET /api/solicitacoes/{id}`

```json
{
  "id": "…", "lote_id": "…", "titulo": "…", "solicitante": "…", "categoria": "…",
  "usuario": "ipop", "ambiente": "hml",
  "criada_em": "…", "terminou_em": "…", "fase": "erro", "mensagem": "Parou na regra 2 (…)…",
  "status": {"codigo": "erro", "rotulo": "Parou na regra 2", "tag": "error"},
  "ativa": false,
  "pode_cancelar": false,
  "pode_retomar": true,
  "retomar_de": 2,
  "arquivo": {"nome": "Lote.xlsx", "tamanho": 48213, "url": "/api/solicitacoes/…/arquivo"},
  "resumo": {"subscricao": 3, "oferta": 1, "total": 4, "cadastradas": 1},
  "regras": [ /* RegraTela */ ],
  "problemas": [ /* erros e avisos */ ],
  "eventos": [ {"criado_em": "…", "tipo": "parou", "titulo": "Parou na regra 2", "detalhe": "…", "responsavel": "Robô IPOP"} ]
}
```

| Campo calculado | Regra |
|---|---|
| `ativa` | `fase` não final |
| `pode_cancelar` | `ativa` e `cancelar = false` |
| `retomar_de` | Primeira regra que não está `confirmada`/`salva_sem_confirmacao` |
| `pode_retomar` | `fase ∈ {erro, interrompida, cancelada}` e `retomar_de` existe |

#### `POST /api/solicitacoes/{id}/cancelar`

| Situação | Resultado |
|---|---|
| `na_fila` | `{"resultado": "cancelada"}`: muda na hora e grava o evento *Cancelada* |
| Fase ativa | `{"resultado": "pedido"}`: liga `cancelar`; o robô para antes da próxima regra |
| Outra | 409 *Esta solicitação não está na fila nem em andamento.* |

#### `POST /api/solicitacoes/{id}/retomar`

Corpo opcional: `{"inicio": N}` (N ≥ 1). Sem corpo, usa `retomar_de`. Volta a execução para `na_fila`, com `inicio=N`, `cancelar=false` e os campos de worker e tempo limpos. Grava o evento *Retomada da regra N* e notifica a fila. Responde 409 se não puder retomar.

#### Arquivos e log

| Rota | Conteúdo |
|---|---|
| `GET /api/solicitacoes/{id}/arquivo` | Planilha original (`Content-Disposition: inline; filename*=UTF-8''…`) |
| `GET /api/solicitacoes/{id}/arquivos/{caminho}` | Qualquer arquivo em `execucoes/<id>/`. Recusa `..` e `/` inicial |
| `GET /api/solicitacoes/{id}/log?linhas=400` | Texto, uma linha por registro: data `dd/mm HH:MM:SS`, nível e mensagem separados por barra vertical (1–5000 linhas); `(ainda sem log)` se vazio |

Os downloads usam `StreamingResponse`, lendo o objeto do S3 em pedaços. Objeto inexistente responde 404.

## Objeto `RegraTela`

`regra_para_tela()` junta as colunas da tabela `regras` com o JSON `dados` (a linha da pré-visualização):

| Campo | Origem |
|---|---|
| `n`, `status`, `detalhe`, `inicio`, `fim` | Colunas |
| `nome`, `modulo`, `linha` | `dados`, com *fallback* para a coluna |
| `aba`, `negocio`, `vigencia_inicio`, `vigencia_fim`, `fator_original`, `fator`, `tipo`, `modelo`, `id_modelo`, `variaveis[]`, `campos_com_erro[]` | `dados` (veja `ConstrutorRegras.previa()`) |
| `print_url` | `/api/solicitacoes/{id}/arquivos/<print>` ou `null` |

## Cálculo do status da tela

`status_da_solicitacao(e, regras=None)` traduz a fase técnica (veja a tabela em [Status](../../negocio/status.md)). Com `regras`, conta na hora. Sem elas (lista do histórico), usa os agregados `total_regras`, `contagem` e `parada`, calculados em SQL por `listar_execucoes` com `LEFT JOIN LATERAL`.

## Erros

Todos os erros de negócio usam `HTTPException(status, "mensagem em português")`, e o frontend mostra o `detail`. Erros do Pydantic (422) chegam como lista. O `tratarErro` do frontend junta os `msg`.
