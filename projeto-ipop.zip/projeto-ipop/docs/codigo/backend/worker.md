# Worker e fila (`ipop/worker.py`, `ipop/infra/db.py`)

## Inicialização (`main()`)

1. `configurar_log()`: log no stdout, nível INFO.
2. Exige `DATABASE_URL` e `S3_*`, senão sai com código **2**.
3. Cria `Repositorio(cfg, tamanho_pool=6)` e `Armazenamento(cfg)`.
4. Até 30 tentativas, a cada 2 s, de `garantir_schema()` + `garantir_bucket()`. Se esgotar, sai com código **3**.
5. `Worker(cfg, repo, armazenamento).rodar()`.

## `Worker.rodar()`

```mermaid
flowchart TB
    R[rodar] --> S[instalar_sinais<br/>SIGTERM/SIGINT]
    S --> REG[registrar_worker]
    REG --> ORF[recuperar_orfas 120 s]
    ORF --> T1[thread 'batimento']
    ORF --> T2[thread 'validacao' → _laco validacao]
    ORF --> T3[thread principal → _laco cadastro]
    T3 -->|parada_solicitada| FIM[join threads, descarregar logs,<br/>worker_saiu]
```

### `_laco(tipo)`

```python
controle = repo.conexao_dedicada()          # fora do pool
controle.execute("LISTEN robo_ipop_fila")
while not parada_solicitada():
    processou = processar_uma(tipo, controle)
    if not processou:
        # espera um NOTIFY ou WORKER_INTERVALO_S (5 s)
        for _ in controle.notifies(timeout=5, stop_after=1): pass
```

Uma exceção no laço é registrada e o laço espera `WORKER_INTERVALO_S` antes de tentar de novo, sem derrubar o worker.

### `processar_uma(tipo, controle=None) -> bool`

| Passo | Validação | Cadastro |
|---|---|---|
| Trava do robô | — | `pg_try_advisory_lock(hashtext('robo_ipop:robo'))` na conexão `controle`. Se outro worker está com ela, devolve `False` |
| Reserva | `reservar_proxima(nome, 'validacao')` | `reservar_proxima(nome, 'cadastro')` |
| Fila vazia | `False` | `False` (solta a trava) |
| Execução | `_executar(execucao)` | idem, e depois solta a trava |

A trava é **por sessão** e fica na conexão dedicada. Se o processo morrer, o Postgres solta a trava sozinho.

`processar_uma` também é chamada diretamente nos testes, para processar uma execução de forma síncrona.

### `reservar_proxima`

```sql
UPDATE robo_ipop.execucoes
   SET fase='reservada', worker=%s, iniciou_em=now(), heartbeat=now(), mensagem='Preparando...'
 WHERE id = (SELECT id FROM robo_ipop.execucoes
              WHERE fase='na_fila' AND NOT cancelar AND tipo=%s
              ORDER BY criada_em, id
              FOR UPDATE SKIP LOCKED LIMIT 1)
RETURNING *;
```

A ordem é **FIFO** por `criada_em`. Uma retomada mantém o `criada_em` original, então volta para a frente da fila.

### `_executar(execucao)`

1. Cria um diretório temporário `ipop-<id>-*`.
2. Instala dois handlers de log no logger raiz, **filtrados pela thread atual** (validação e cadastro rodam juntos):
    - `HandlerLogBanco`, que acumula os registros para o Postgres;
    - um `FileHandler` para `execucao.log`.
3. Registra a execução em `self.ativas[tipo]` (para o batimento).
4. Cria `ProgressoBanco(repo, armazenamento, id, inicio=…, registrar_eventos=(tipo=='cadastro'))`.
5. Baixa `pedido.xlsx` e as tabelas auxiliares do bucket (`config/tbl_dim/`).
6. Chama `robo.executar(pasta, config, progresso, parametros, tbl_dim_dir=…)`, com:

    ```python
    {"pedido": "pedido.xlsx", "ambiente": e["ambiente"], "so_dados": e["so_dados"],
     "inicio": e["inicio"], "continuar_em_erro": e["continuar_em_erro"]}
    ```

7. Se houver exceção ao preparar (por exemplo, a planilha sumiu do bucket), grava `fase='erro'` com a mensagem *"Não foi possível preparar a execução: …"*.
8. No `finally`: remove os handlers, descarrega o log no banco e envia `execucao.log` para o bucket.

## Batimento (`_laco_batimento`, a cada 5 s)

1. `repo.batimento(nome, executando=ativas['cadastro'], ativas=[…])`:
    - `workers.visto_em = now()` e `executando = <id do cadastro>`;
    - `execucoes.heartbeat = now()` para **todas** as execuções ativas do worker;
    - devolve `True` se `checagem_pedida_em > checado_em`.
2. `_descarregar_logs()`: grava em lote os logs pendentes de cada execução ativa. Em caso de falha, os registros voltam para a fila do handler e são tentados de novo no ciclo seguinte.
3. `_checar_rede()` se foi pedida ou se passaram 15 min desde a última: testa `hml` (e `prd`, se `PERMITIR_PRODUCAO`) e grava em `workers.conectividade`. O SQL Server é testado só uma vez, no primeiro ambiente.
4. `recuperar_orfas(120)`.

## Execuções órfãs (`recuperar_orfas`)

```sql
UPDATE execucoes SET fase='interrompida', terminou_em=now(),
       mensagem='O worker parou de responder no meio da execução. Confira a regra marcada "verificar" no IPOP e retome.'
 WHERE fase = ANY('{reservada,verificando_rede,lendo_planilha,login,cadastrando}')
   AND (heartbeat IS NULL OR heartbeat < now() - interval '120 seconds')
RETURNING id;
-- nas regras dessas execuções:
--   executando → verificar  ("O worker caiu durante esta regra. Ela pode ter sido salva: confira no IPOP.")
--   pendente   → não executada
```

Roda na subida de **qualquer** worker e a cada batimento, então um worker vivo recupera as órfãs de outro que caiu.

## Cancelamento

`Repositorio.pedir_cancelamento(id)`:

- `fase='na_fila'`: muda para `cancelada` na hora (`cancelar=true`);
- fase ativa e `NOT cancelar`: liga `cancelar=true` e acrescenta *"(cancelamento pedido: para depois da regra atual)"* à mensagem.

O robô consulta `Progresso.deve_parar()` **antes de cada regra** (e antes de abrir o navegador). Com o cancelamento pedido, levanta `Parado('cancelada', 'Cancelada pelo usuário.')`.

## Desligamento (SIGTERM)

`instalar_sinais()` troca os handlers de SIGTERM e SIGINT:

- **1º sinal:** liga o evento `_parar`. Os laços de fila param de pegar trabalho, e o robô levanta `Parado('interrompida', …)` antes da próxima regra;
- **2º sinal:** `SystemExit(130)`, saída imediata.

A thread principal espera as outras (até 30 s), descarrega os logs e marca o worker como offline (`visto_em = now() - 1h`).

## Métodos do `Repositorio`

| Grupo | Método | Uso |
|---|---|---|
| Schema | `garantir_schema()` | DDL idempotente com advisory lock transacional |
| Conexão | `conexao()` (pool), `conexao_dedicada()` | — |
| Fila | `criar_execucao(...)` | INSERT + evento *Recebida* (cadastro) + `pg_notify` |
| | `reservar_proxima(worker, tipo)` | `SKIP LOCKED` |
| | `retomar(id, inicio, usuario)` | Volta para `na_fila` (só de `erro`/`interrompida`/`cancelada`) + evento + notify |
| | `posicao_na_fila(id)` | Posição na fila (não é usado pela API atual) |
| | `tentar_trava_do_robo`, `soltar_trava_do_robo` | Advisory lock de sessão |
| | `recuperar_orfas(limite_s)` | Veja acima |
| Andamento | `atualizar_execucao(id, fase=, mensagem=, conectividade=, avisos=, erros_validacao=, problemas=)` | `terminou_em=now()` automático em fase final; campo desconhecido levanta `ValueError` |
| | `definir_regras(id, regras, preservar_ate)` | Regrava as regras, preservando as já feitas antes de `preservar_ate` |
| | `atualizar_regra(id, n, **campos)` | Não rebaixa uma regra feita para `pulada` |
| | `inserir_evento`, `listar_eventos` | Linha do tempo |
| | `cancelamento_pedido(id)` | Lê a flag |
| | `gravar_logs(id, registros)` | `executemany` |
| Workers | `registrar_worker`, `batimento`, `salvar_checagem`, `worker_saiu`, `listar_workers`, `pedir_checagem` | — |
| Leitura | `listar_execucoes(limite, tipo, busca)` | Com agregados de regras (total, contagem por status, primeira parada) |
| | `obter_execucao(id)` | Execução + `regras` ordenadas |
| | `ler_logs(id, linhas)` | Últimas N, em ordem cronológica |
| | `saude()` | `SELECT 1` |
| Util | `para_json(valor)` | `json.loads(json.dumps(v, default=str))`: datas viram string |
