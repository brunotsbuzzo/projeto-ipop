# Estrutura do repositório

```text
projeto-ipop/
├── docker-compose.yml          # pilha completa: postgres, pgadmin, minio, api, worker, web
├── .env.example                # modelo de configuração (copiar para .env)
├── mkdocs.yml                  # esta documentação
├── docs/                       # fontes da documentação (Markdown)
├── README.md
│
├── backend/
│   ├── Dockerfile              # uma imagem para api e worker (Python 3.13 + Chromium + ODBC 18)
│   ├── requirements.txt        # dependências de produção
│   ├── requirements-dev.txt    # + pytest, httpx, moto
│   ├── app/
│   │   ├── main.py             # API REST (FastAPI) usada pela tela
│   │   └── modelo_planilha.py  # gera a planilha-modelo para download
│   ├── ipop/
│   │   ├── config.py           # Config (dataclass) lida do ambiente/.env
│   │   ├── conectividade.py    # testes de rede (TCP, driver ODBC, login SQL)
│   │   ├── progresso.py        # interface Progresso + ProgressoArquivo + sinais (SIGTERM)
│   │   ├── robo.py             # UMA execução: rede → planilha → SQL → validação → IPOP
│   │   ├── worker.py           # worker: filas, threads, batimento, órfãs
│   │   ├── cli.py              # linha de comando (sem Postgres/MinIO)
│   │   ├── infra/
│   │   │   ├── db.py               # Repositorio (Postgres): schema, fila, travas, leitura
│   │   │   ├── armazenamento.py    # cliente S3/MinIO
│   │   │   └── progresso_banco.py  # ProgressoBanco + HandlerLogBanco (log em lote)
│   │   ├── models/
│   │   │   └── regra.py        # dataclasses RegraBase/Agravo/Desconto/Recusa/…/Oferta e variáveis
│   │   ├── services/
│   │   │   ├── leitor_pedido.py      # lê o Excel → dicts de regra
│   │   │   ├── construtor_regras.py  # enriquece, valida, gera prévia e objetos de regra
│   │   │   ├── enriquecedor_sql.py   # consultas ao SQL Server (RosieRep)
│   │   │   └── cadastro.py           # passo a passo do cadastro de UMA regra
│   │   └── pages/              # Page Objects (Playwright) das telas do IPOP
│   │       ├── login_home.py       # login e troca de módulo
│   │       ├── lista_regras.py     # lista: pesquisar, copiar, abrir, conferir
│   │       └── formulario_regra.py # formulário: seção regra, variáveis, grid, salvar
│   ├── dados/tbl_dim/          # TblDePara.xlsx, TblRegraModelo.xlsx (padrão da imagem)
│   └── tests/
│       ├── conftest.py             # fixtures: config, Postgres temporário, S3 (moto), SQL falso
│       ├── infra_local.py          # PostgresTemporario (initdb/pg_ctl) e S3 moto
│       ├── test_*.py               # testes (veja a página Testes)
│       ├── ipop_falso/             # imitação das telas do IPOP (app.html + servidor HTTP)
│       └── demo/                   # pilha completa local sem Docker (pilha_demo.py)
│
└── frontend/
    ├── Dockerfile              # build Angular + nginx
    ├── nginx/
    │   ├── default.conf.template   # login Basic, proxy /api, cache
    │   └── 40-htpasswd.sh          # gera htpasswd a partir de WEB_USUARIO/WEB_SENHA
    ├── angular.json, package.json, tsconfig*.json, proxy.conf.json, .prettierrc
    ├── public/favicon.ico
    └── src/
        ├── index.html, main.ts, styles.scss
        ├── styles/_hdi-tokens.scss # tokens --hdi-* do Design System HDI (Figma)
        └── app/
            ├── app.ts, app.config.ts, app.routes.ts
            ├── layout/   shell.ts (moldura), migalhas.ts
            ├── data/     api.ts (HTTP), modelos.ts (contrato), formatos.ts (+ spec)
            ├── shared/   status-tag, secao, cabecalho-pagina, cartao-arquivo,
            │             caixa-problemas, tabela-regras, linha-do-tempo
            └── pages/    inicio, nova-solicitacao, solicitacao-enviada,
                          historico, detalhe, duvidas
```

## Arquivos ignorados

`.gitignore`: `.env`, `__pycache__/`, `.pytest_cache/`, `backend/dados/execucoes/`, `frontend/node_modules/`, `frontend/dist/`, `frontend/.angular/`, `site/` (build desta documentação).

## Origem do código

O backend foi portado do projeto Selenium `RoboIPOP-Subs-Oferta`. Os docstrings registram o que mudou em cada módulo:

| Módulo novo | Origem | Mudanças principais |
|---|---|---|
| `services/leitor_pedido.py` | `services/leitor_pedido.py` | Detecta abas pelo nome/colunas; módulo sempre "Subscrição"/"Oferta"; pula linhas vazias; `10.0` → `10` |
| `services/enriquecedor_sql.py` | `services/enriquecedor_sql_service.py` | Credenciais do `.env`; consultas parametrizadas em lotes; sem `IN ()` vazio; erro claro sem conexão |
| `services/cadastro.py` | `RegraService` | Trava "Cópia de"; confirmação na lista |
| `pages/lista_regras.py` | `BasePage` | Busca por código com *fallbacks*; Detalhes/Editar |
| `models/regra.py` | `models/*.py` | Mesmas classes, com `ids_dominio` |
| `construtor_regras.criar_regra` | `FabricaRegra.criar` | — |
