# Código

| Parte | Linguagem / stack | Páginas |
|---|---|---|
| Backend: API | Python 3.13, FastAPI, Pydantic | [API REST](backend/api.md) |
| Backend: worker | Python, psycopg 3, threads | [Worker e fila](backend/worker.md) |
| Backend: robô | Python, pandas, pyodbc, Playwright | [Robô](backend/robo.md), [Leitura](backend/leitura.md), [Enriquecimento e validação](backend/enriquecimento-validacao.md), [Modelos](backend/modelos.md), [Automação do IPOP](backend/automacao-ipop.md) |
| Backend: suporte | Python | [Progresso e logs](backend/progresso.md), [Configuração](backend/config.md), [Planilha-modelo](backend/planilha-modelo.md) |
| Frontend | Angular 22 (standalone, signals), NG-ZORRO 22, SCSS | [Frontend](frontend/index.md) |
| Testes | pytest, moto, Playwright, Vitest | [Testes](testes.md) |

## Convenções

- **Português** em nomes de variáveis, funções, classes, mensagens e comentários. Os nomes seguem o vocabulário do negócio (`regra`, `execucao`, `solicitacao`, `validacao`).
- Backend sem framework de ORM: SQL escrito à mão em `ipop/infra/db.py`.
- Dependências pesadas (`playwright`, `pyodbc`) são importadas **dentro** das funções que as usam, para a API e os testes de leitura não precisarem delas.
- Frontend com componentes *standalone*, `ChangeDetectionStrategy.OnPush`, *signals* e templates/estilos inline. Prefixo de seletor `hdi-`.
- Formatação do frontend com Prettier (`printWidth: 100`, aspas simples).
- A linha de comando, o worker e os testes rodam o **mesmo** `ipop.robo.executar()`. Só muda a implementação de `Progresso`.

## Mapa de dependências do backend

```mermaid
flowchart TD
    main["app/main.py<br/>(API)"] --> db["ipop/infra/db.py"]
    main --> arm["ipop/infra/armazenamento.py"]
    main --> mp["app/modelo_planilha.py"]
    worker["ipop/worker.py"] --> db
    worker --> arm
    worker --> pb["ipop/infra/progresso_banco.py"]
    worker --> robo["ipop/robo.py"]
    worker --> con["ipop/conectividade.py"]
    cli["ipop/cli.py"] --> robo
    cli --> prog["ipop/progresso.py"]
    robo --> con
    robo --> cr["services/construtor_regras.py"]
    robo --> cad["services/cadastro.py"]
    cr --> lp["services/leitor_pedido.py"]
    cr --> es["services/enriquecedor_sql.py"]
    cr --> mod["models/regra.py"]
    cad --> lr["pages/lista_regras.py"]
    cad --> fr["pages/formulario_regra.py"]
    robo --> lh["pages/login_home.py"]
    pb --> prog
    db --> prog
    all["(todos)"] -.-> cfg["ipop/config.py"]
```
