# Infraestrutura

| Página | Conteúdo |
|---|---|
| [Arquitetura](arquitetura.md) | Componentes, responsabilidades e decisões de projeto (por que não há RabbitMQ) |
| [Docker Compose e imagens](docker.md) | Serviços, portas, volumes, healthchecks, Dockerfiles e nginx |
| [Variáveis de ambiente](configuracao.md) | Referência completa do `.env` |
| [Banco de dados](banco-de-dados.md) | Schema `robo_ipop`: tabelas, índices, fila, travas e consultas úteis |
| [Armazenamento](armazenamento.md) | Bucket `robo-ipop`: organização dos arquivos |
| [Rede, acesso e segurança](rede-e-seguranca.md) | Requisitos de rede, autenticação, segredos e endurecimento |
| [Operação (runbook)](operacao.md) | Tarefas do dia a dia: subir, parar, atualizar tabelas, retomar, logs, backup |
| [Solução de problemas](solucao-de-problemas.md) | Sintomas, causas e correções |
