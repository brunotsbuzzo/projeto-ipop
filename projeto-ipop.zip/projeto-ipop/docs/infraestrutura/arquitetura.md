# Arquitetura

## Visão de componentes

```mermaid
flowchart LR
    subgraph Cliente
        B[Navegador]
    end

    subgraph Docker Compose
        WEB["web<br/>nginx 1.27 + build Angular<br/>:80 → host :8080"]
        API["api<br/>FastAPI / uvicorn :8000<br/>(sem porta publicada)"]
        WK["worker<br/>python -m ipop.worker<br/>Chromium headless"]
        PG[("postgres 16<br/>:5432")]
        MI[("minio<br/>:9000 S3 · :9001 console")]
        PGA["pgadmin<br/>:5050"]
    end

    subgraph Rede HDI
        IPOP["IPOP hml/prd<br/>HTTPS 443"]
        SQL[("SQL Server RosieRep<br/>1433")]
    end

    B -- "HTTP Basic" --> WEB
    WEB -- "/api/* (proxy)" --> API
    API --> PG
    API --> MI
    WK --> PG
    WK --> MI
    WK -- "Playwright" --> IPOP
    WK -- "ODBC 18" --> SQL
    PGA --> PG
```

| Serviço | Imagem | Responsabilidade |
|---|---|---|
| `web` | `ipop-frontend:latest` (build de `frontend/`) | Serve o Angular. Pede o login HTTP Basic. Repassa `/api/` para a API. Expõe `/saude` sem login |
| `api` | `ipop-backend:latest` (build de `backend/`) | Recebe a planilha, grava no bucket, cria execuções, monta a resposta da tela. Na subida, cria o schema e o bucket |
| `worker` | `ipop-backend:latest` (a mesma imagem) | Consome a fila: validações e cadastros. Batimento, detecção de órfãs, checagem de rede |
| `postgres` | `postgres:16-alpine` | Fila, andamento por regra, eventos, logs e workers (schema `robo_ipop`) |
| `minio` | `bitnamilegacy/minio:latest` | Armazenamento S3: planilhas, JSON enriquecido, prints, traces, logs, tabelas auxiliares |
| `pgadmin` | `dpage/pgadmin4` | Administração do Postgres (opcional) |

## Fluxo de dados

```mermaid
sequenceDiagram
    participant T as Tela
    participant A as API
    participant S as MinIO
    participant P as Postgres
    participant W as Worker

    T->>A: POST /api/validacoes (multipart)
    A->>S: put execucoes/<id>/pedido.xlsx
    A->>P: INSERT execucoes (tipo=validacao, fase=na_fila)
    A->>P: pg_notify('robo_ipop_fila', 'validacao')
    P-->>W: NOTIFY acorda a thread de validação
    W->>P: UPDATE … FOR UPDATE SKIP LOCKED (reserva)
    W->>S: get pedido.xlsx e config/tbl_dim/*
    W->>W: ler → enriquecer (SQL) → validar
    W->>S: put regras_enriquecidas.json
    W->>P: regras, problemas, fase=concluida_so_dados|erro_validacao
    T->>A: GET /api/validacoes/{id} (polling 1,5 s)
    A->>P: SELECT
    T->>A: POST /api/solicitacoes
    A->>P: INSERT execucoes (tipo=cadastro) + regras "pendente" + evento "Recebida" + NOTIFY
    W->>P: pg_try_advisory_lock (trava do robô) + reserva
    W->>W: Chromium → IPOP, regra por regra
    W->>P: status de cada regra, eventos, logs (em lote)
    W->>S: prints, trace.zip, execucao.log
```

## Decisões de projeto

### Fila no Postgres, sem broker

Não há RabbitMQ nem Redis. A fila é a própria tabela `execucoes`:

- **Reserva:** `UPDATE … WHERE id = (SELECT … WHERE fase='na_fila' … ORDER BY criada_em FOR UPDATE SKIP LOCKED LIMIT 1)`. Dois workers nunca pegam a mesma execução.
- **Despertar:** `LISTEN robo_ipop_fila` / `pg_notify`. Sem notificação, o worker consulta a fila a cada `WORKER_INTERVALO_S` (5 s).
- **Motivo:** a fila e o andamento ficam no mesmo lugar e na mesma transação. Num broker, uma mensagem sem *ack* volta sozinha para a fila. Aqui isso significaria **cadastrar regras em dobro** no IPOP. Uma execução só volta para a fila quando uma pessoa clica em **Retomar**.

### Um robô por vez (advisory lock)

O laço de cadastro pega `pg_try_advisory_lock(hashtext('robo_ipop:robo'))` numa conexão dedicada antes de reservar. Assim, mesmo com vários workers (várias máquinas), só um fica no IPOP. Se o processo morrer, a trava cai junto com a conexão.

### Validação e cadastro em paralelo

O worker roda três threads:

| Thread | Função |
|---|---|
| `cadastro` (principal) | Fila de cadastro, com a trava do robô |
| `validacao` | Fila de validação, sem trava e sem navegador |
| `batimento` | Batimento a cada 5 s, gravação dos logs, checagem de rede (a cada 15 min ou sob pedido), recuperação de órfãs |

Assim, uma pessoa consegue validar uma planilha nova enquanto outro lote está sendo cadastrado.

### Uma imagem para API e worker

`backend/Dockerfile` gera uma imagem com Python 3.13, Chromium do Playwright e ODBC Driver 18. O compose muda só o `command`. Isso simplifica o build e garante que as duas partes rodam com o mesmo código.

### S3 genérico

O backend fala S3 puro (boto3, *path-style*, assinatura v4). Trocar o MinIO por AWS S3, Ceph ou outro serviço compatível é só mudar `S3_ENDPOINT` e as chaves.

### Schema próprio

As tabelas ficam no schema `DB_SCHEMA` (padrão `robo_ipop`), então o sistema pode dividir o banco `analise_cotacao` com outras aplicações sem conflito.

## Limites e capacidade

| Item | Valor | Onde |
|---|---|---|
| Cadastros simultâneos no IPOP | 1 | advisory lock |
| Validações simultâneas por worker | 1 | thread `validacao` |
| Tamanho da planilha | `TAMANHO_MAXIMO_MB` (20); nginx aceita até 25 MB | `.env`, `client_max_body_size` |
| Pool do Postgres | API: 5 conexões; worker: 6 + 2 dedicadas (LISTEN/trava) | `Repositorio(tamanho_pool)` |
| Timeout padrão do Playwright | `TIMEOUT_PADRAO_MS` (30 s) | `.env` |
| Timeout do grid pesado (CPF/CNPJ) | 180 s fetch / 200 s espera | `CadastroDeRegraPage` |
| Execução órfã depois de | 120 s sem batimento | `SEGUNDOS_ORFA` |
| Worker considerado online | visto nos últimos 30 s | `SEGUNDOS_ONLINE` |
| Histórico na tela | até 200 solicitações (máx. 500 pela API) | `limite` |
