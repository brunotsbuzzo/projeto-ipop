# Banco de dados (Postgres)

A API e o worker criam o schema na subida, de forma idempotente (`CREATE … IF NOT EXISTS`), sob `pg_advisory_xact_lock(hashtext('<schema>:schema'))` para que duas subidas simultâneas não disputem. Não há ferramenta de migração: mudanças no schema precisam ser compatíveis com `IF NOT EXISTS` ou aplicadas à mão.

Todas as conexões usam `autocommit=True` e `row_factory=dict_row`.

## Modelo de dados

```mermaid
erDiagram
    execucoes ||--o{ regras : "tem"
    execucoes ||--o{ eventos : "tem"
    execucoes ||--o{ logs : "tem"
    execucoes |o--o{ execucoes : "validacao_id / origem"
    workers ||--o{ execucoes : "worker (texto)"

    execucoes {
        text id PK "AAAAMMDD-HHMMSS-xxxxxx"
        text tipo "validacao | cadastro"
        timestamptz criada_em
        text usuario "login HTTP Basic"
        text solicitante
        text titulo
        text lote_id "ID do Taskflow"
        text categoria
        text validacao_id FK
        text nome_original
        bigint tamanho_arquivo
        text objeto_pedido "chave no bucket"
        text ambiente "hml | prd"
        boolean so_dados
        int inicio "regra inicial (>=1)"
        boolean continuar_em_erro
        text origem FK
        text fase
        text mensagem
        text worker
        timestamptz iniciou_em
        timestamptz terminou_em
        timestamptz heartbeat
        boolean cancelar
        jsonb conectividade
        jsonb avisos
        jsonb erros_validacao
        jsonb problemas
        timestamptz atualizada_em
    }
    regras {
        text execucao_id PK,FK
        int n PK "ordem 1..N"
        text nome
        text aba
        int linha
        text modulo
        text tipo
        float percentual
        text vigencia
        bigint modelo
        int variaveis "quantidade"
        text status
        text detalhe
        text print "caminho relativo no bucket"
        timestamptz inicio
        timestamptz fim
        jsonb dados "linha da pré-visualização"
    }
    eventos {
        bigserial id PK
        text execucao_id FK
        timestamptz criado_em
        text tipo
        text titulo
        text detalhe
        text responsavel
    }
    logs {
        bigserial id PK
        text execucao_id FK
        timestamptz criado_em
        text nivel
        text origem "logger"
        text mensagem "até 20 mil caracteres"
    }
    workers {
        text nome PK
        timestamptz iniciado_em
        timestamptz visto_em
        text executando
        jsonb conectividade
        timestamptz checado_em
        timestamptz checagem_pedida_em
    }
```

### `execucoes`

Uma linha por **validação** ou por **cadastro (solicitação)**. A solicitação aponta para a validação de origem por `validacao_id` e reaproveita o mesmo `objeto_pedido`: a planilha não é copiada.

| Coluna | Observação |
|---|---|
| `tipo` | `CHECK (tipo IN ('validacao','cadastro'))` |
| `ambiente` | `CHECK (ambiente IN ('hml','prd'))` |
| `inicio` | `CHECK (inicio >= 1)`. A retomada muda esse valor |
| `fase` | Veja [Status](../negocio/status.md#maquina-de-estados-da-execucao) |
| `cancelar` | Flag que o robô lê antes de cada regra |
| `heartbeat` | Atualizado pelo batimento do worker a cada 5 s |
| `conectividade` | Lista de checagens (`nome`, `destino`, `ok`, `detalhe`, `ms`) |
| `avisos`, `erros_validacao` | Listas de texto (formato da linha de comando) |
| `problemas` | Lista de `{nivel, aba, linha, nome, campo, mensagem}` (usada pela tela) |
| `origem` | Reservado (FK para outra execução). Não é usado pela API atual |

Índices:

- `execucoes_na_fila (tipo, criada_em) WHERE fase = 'na_fila'`: índice parcial que deixa a reserva rápida;
- `execucoes_criada_em (criada_em DESC)`: histórico.

### `regras`

O andamento de cada regra. A chave é `(execucao_id, n)`. A coluna `dados` guarda a linha completa da pré-visualização (negócio, vigência, fator original, variáveis com valores, `campos_com_erro`), e a tela usa esse conteúdo diretamente.

`definir_regras()` apaga e regrava as regras da execução. Numa **retomada** (`preservar_ate = inicio > 1`), as regras com `n < inicio` que já estavam `confirmada` ou `salva_sem_confirmacao` **mantêm** `status`, `detalhe`, `print`, `inicio` e `fim`. `atualizar_regra(status='pulada')` nunca rebaixa uma regra já feita.

### `eventos`

A linha do tempo mostrada na tela (o mais recente primeiro). Só as execuções do tipo `cadastro` registram eventos.

| `tipo` | Título | Quem grava |
|---|---|---|
| `recebida` | Recebida | API (ao criar) |
| `dados_conferidos` | Dados conferidos | Robô |
| `cadastrando` | Cadastrando no IPOP | Robô |
| `concluida` | Concluída | Robô |
| `parou` | Parou na regra N / Terminou com erros | Robô |
| `erro` | Erro | Robô (exceção inesperada) |
| `interrompida` | Interrompida | Robô (SIGTERM) |
| `cancelada` | Cancelada | Robô ou API (cancelada na fila) |
| `retomada` | Retomada da regra N | API |

### `logs`

O log de cada execução, gravado em lote pelo worker (a cada ~5 s e ao terminar). A API devolve as últimas N linhas em `/api/solicitacoes/{id}/log`.

### `workers`

Um registro por `WORKER_NOME`. O worker conta como **online** se `visto_em` está nos últimos 30 s. Ao sair normalmente, o worker volta `visto_em` uma hora para trás, para aparecer offline na hora.

## Mecanismos de concorrência

| Mecanismo | SQL | Para quê |
|---|---|---|
| Reserva da fila | `FOR UPDATE SKIP LOCKED` | Dois workers nunca reservam a mesma execução |
| Despertar | `LISTEN robo_ipop_fila` / `pg_notify(canal, tipo)` | O worker acorda na hora quando há trabalho |
| Trava do robô | `pg_try_advisory_lock(hashtext('robo_ipop:robo'))` | Um cadastro no IPOP por vez |
| Trava do schema | `pg_advisory_xact_lock(hashtext('robo_ipop:schema'))` | Criação concorrente do schema |
| Órfãs | `UPDATE … WHERE fase = ANY(ativas) AND heartbeat < now() - 120s` | O worker que caiu não deixa execuções presas |

## Consultas úteis

```sql
SET search_path = robo_ipop;

-- Fila atual
SELECT id, tipo, lote_id, fase, criada_em FROM execucoes
 WHERE fase NOT IN ('concluida','concluida_so_dados','erro','erro_validacao','cancelada','interrompida')
 ORDER BY criada_em;

-- Andamento de uma solicitação
SELECT n, nome, status, detalhe, print FROM regras WHERE execucao_id = '20261105-141500-ab12cd' ORDER BY n;

-- Workers e última checagem de rede
SELECT nome, visto_em, executando, visto_em > now() - interval '30 seconds' AS online,
       jsonb_pretty(conectividade) FROM workers;

-- Últimas linhas de log de uma execução
SELECT criado_em, nivel, mensagem FROM logs WHERE execucao_id = '…' ORDER BY id DESC LIMIT 50;

-- Quem segura a trava do robô
SELECT pid, application_name, state, query_start FROM pg_stat_activity
 WHERE pid IN (SELECT pid FROM pg_locks WHERE locktype = 'advisory');

-- Solicitações por status no mês
SELECT fase, count(*) FROM execucoes
 WHERE tipo = 'cadastro' AND criada_em >= date_trunc('month', now()) GROUP BY fase;
```

## Retenção

Nada é apagado automaticamente: execuções, regras, eventos e logs ficam para sempre. As FKs usam `ON DELETE CASCADE`, então apagar uma linha de `execucoes` apaga as regras, os eventos e os logs dela. Os arquivos no bucket precisam ser apagados à parte (veja [Armazenamento](armazenamento.md)).
