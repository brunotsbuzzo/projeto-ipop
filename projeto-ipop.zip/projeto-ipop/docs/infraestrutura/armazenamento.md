# Armazenamento (MinIO / S3)

Um único bucket (`S3_BUCKET`, padrão `robo-ipop`), criado pela API ou pelo worker na subida se não existir.

## Organização

```text
robo-ipop/
├── execucoes/
│   └── <id>/                          # id da VALIDAÇÃO (a solicitação reaproveita o pedido)
│       ├── pedido.xlsx                # planilha enviada
│       ├── regras_enriquecidas.json   # regras depois do enriquecimento (antes da validação)
│       └── execucao.log               # log da validação
│   └── <id-da-solicitação>/
│       ├── regras_enriquecidas.json
│       ├── erros/regra_NNN.png        # print de página inteira da regra que falhou
│       ├── trace.zip                  # gravação do Playwright (só quando houve erro)
│       └── execucao.log               # log completo da execução
└── config/
    └── tbl_dim/
        ├── TblDePara.xlsx             # opcional: substitui a tabela da imagem
        └── TblRegraModelo.xlsx        # opcional
```

!!! info "Onde fica a planilha de uma solicitação"
    `execucoes.objeto_pedido` guarda a chave exata. Para uma solicitação, é a chave da validação de origem: `execucoes/<id-da-validação>/pedido.xlsx`.

## Arquivos de cada execução

| Arquivo | Quando é gravado | Como baixar pela tela/API |
|---|---|---|
| `pedido.xlsx` | Upload (API) | *Baixar arquivo* no detalhe → `GET /api/solicitacoes/{id}/arquivo` |
| `regras_enriquecidas.json` | Depois de ler e enriquecer (worker), mesmo com erros de validação | `GET /api/solicitacoes/{id}/arquivos/regras_enriquecidas.json` |
| `erros/regra_NNN.png` | Regra com falha | Link *print* na tabela de regras → `/arquivos/erros/regra_NNN.png` |
| `trace.zip` | Fim do cadastro, **só se houve erro** e `GRAVAR_TRACE=true` | `/arquivos/trace.zip`, depois abra em <https://trace.playwright.dev> |
| `execucao.log` | Fim da execução | `/arquivos/execucao.log`. O mesmo conteúdo fica no Postgres (`/log`) |

## Cliente S3

- `boto3` com `signature_version=s3v4` e `addressing_style=path` (`http://host:9000/bucket/chave`, o formato que o MinIO usa).
- Até 5 tentativas (modo `standard`), `connect_timeout` de 5 s e `read_timeout` de 60 s.
- O Content-Type vem da extensão (`.xlsx` registrado à mão).
- Os downloads da API são *streaming*, em pedaços de 256 KB.

## Console do MinIO

<http://localhost:9001>, com `MINIO_ROOT_USER` / `MINIO_ROOT_PASSWORD`. Pelo console dá para:

- navegar em `robo-ipop/execucoes/<id>/` e baixar prints e traces;
- enviar novas tabelas auxiliares para `robo-ipop/config/tbl_dim/`.

## Retenção

Não há política de expiração configurada. Para limitar o espaço, crie uma regra de ciclo de vida no MinIO, por exemplo para expirar `execucoes/` depois de N dias, ou use `mc ilm`. Os registros do Postgres continuam existindo, mas os links de arquivo passam a responder 404.

!!! warning "Imagem do MinIO"
    `bitnamilegacy/minio` está congelada (a Bitnami parou de atualizar essas imagens) e o MinIO Community virou só código-fonte. Como o backend fala S3 puro, trocar por outro S3 compatível é só mudar `S3_ENDPOINT`, `S3_ACCESS_KEY` e `S3_SECRET_KEY`.
