# Docker Compose e imagens

O `docker-compose.yml` da raiz sobe a pilha inteira. O compose precisa rodar **numa máquina com acesso à rede da HDI** (IPOP e SQL Server).

## Serviços

| Serviço | Porta no host | Depende de | Healthcheck | Reinício |
|---|---|---|---|---|
| `postgres` | `5432` | — | `pg_isready` a cada 5 s | `unless-stopped` |
| `pgadmin` | `5050` | postgres saudável | — | `unless-stopped` |
| `minio` | `9000` (S3), `9001` (console) | — | — | `unless-stopped` |
| `api` | — (só rede interna, `8000`) | postgres saudável, minio iniciado | `GET http://127.0.0.1:8000/saude` a cada 15 s, `start_period` 20 s | `unless-stopped` |
| `worker` | — | api saudável | — | `unless-stopped` |
| `web` | `${WEB_PORTA:-8080}` → `80` | api saudável | — | `unless-stopped` |

### Volumes

| Volume | Montado em | Conteúdo |
|---|---|---|
| `pgdata` | `/var/lib/postgresql/data` | Banco Postgres |
| `miniodata` | `/data` | Objetos do MinIO |

### Particularidades do `worker`

```yaml
shm_size: "1gb"          # o Chromium precisa de mais /dev/shm que o padrão (64 MB)
stop_grace_period: 5m    # tempo para terminar a regra atual ao parar
environment:
  WORKER_NOME: worker-1  # nome mostrado em /api/workers e gravado nas execuções
```

Se o nome do SQL Server não resolver dentro do container, descomente:

```yaml
extra_hosts:
  - "HDIWROSIE01.dominio.local:10.0.0.20"
dns:
  - 10.0.0.10
```

### Variáveis montadas pelo compose

`api` e `worker` recebem o `.env` inteiro (`env_file`), mais este bloco (âncora `&infra`):

```yaml
DATABASE_URL: postgresql://${POSTGRES_USER}:${POSTGRES_PASSWORD}@postgres:5432/${POSTGRES_DB}
DB_SCHEMA: ${DB_SCHEMA:-robo_ipop}
S3_ENDPOINT: http://minio:9000
S3_ACCESS_KEY: ${MINIO_ROOT_USER}
S3_SECRET_KEY: ${MINIO_ROOT_PASSWORD}
S3_BUCKET: ${S3_BUCKET:-robo-ipop}
```

O `web` recebe só `API_UPSTREAM=api:8000`, `WEB_USUARIO` e `WEB_SENHA`.

## Imagem do backend (`backend/Dockerfile`)

| Camada | Detalhe |
|---|---|
| Base | `python:3.13-slim-bookworm` |
| Ambiente | `PYTHONUNBUFFERED=1`, `PLAYWRIGHT_BROWSERS_PATH=/ms-playwright`, `TZ=America/Sao_Paulo` |
| ODBC | Repositório oficial da Microsoft (Debian 12), `msodbcsql18` + `unixodbc` (`ACCEPT_EULA=Y`) |
| Python | `pip install -r requirements.txt` |
| Navegador | `playwright install --with-deps chromium` |
| Código | `ipop/`, `app/`, `dados/tbl_dim/` (os testes ficam fora, via `.dockerignore`) |
| Usuário | `robo` (uid 1000), sem root |
| Comando padrão | `uvicorn app.main:app --host 0.0.0.0 --port 8000 --proxy-headers --forwarded-allow-ips *` |

O `worker` usa a mesma imagem, com `command: ["python", "-m", "ipop.worker"]`.

### Dependências Python (`requirements.txt`)

| Pacote | Uso |
|---|---|
| `playwright==1.63.0` | Automação do Chromium (versão fixa: os navegadores baixados dependem dela) |
| `pandas`, `openpyxl` | Leitura e geração de Excel |
| `pyodbc` | SQL Server |
| `fastapi`, `uvicorn[standard]`, `python-multipart` | API e upload |
| `python-dotenv` | Lê o `.env` fora do Docker |
| `psycopg[binary]`, `psycopg-pool` | Postgres |
| `boto3` | S3/MinIO |

`requirements-dev.txt` acrescenta `pytest`, `httpx` e `moto[server]`.

## Imagem do frontend (`frontend/Dockerfile`)

Build em dois estágios:

1. `node:22-alpine`: `npm ci` e `ng build --configuration production`;
2. `nginx:1.27-alpine`: copia `dist/ipop-cadastro-regras/browser` para `/usr/share/nginx/html`.

### nginx (`frontend/nginx/default.conf.template`)

O template passa por `envsubst` quando o container inicia (`${API_UPSTREAM}`).

| Location | Comportamento |
|---|---|
| (servidor inteiro) | `auth_basic "Cadastro de Regras IPOP"` com `/etc/nginx/htpasswd`; `client_max_body_size 25m` |
| `/api/` | `proxy_pass http://${API_UPSTREAM}`; repassa `Host`, `X-Forwarded-For` e `X-Forwarded-Proto`; `proxy_read_timeout 120s`; `proxy_buffering off` (downloads em streaming) |
| `= /saude` | **Sem login**, repassa para a API (para monitoramento) |
| estáticos (`.js`, `.css`, `.woff`, `.woff2`, `.ttf`, `.svg`, `.png`, `.ico`) | Cache de 30 dias, `immutable` (os arquivos têm hash no nome) |
| `/` | `no-cache`, *fallback* SPA para `index.html` |

### Script `40-htpasswd.sh`

Roda no `docker-entrypoint.d` do nginx. Exige `WEB_USUARIO` e `WEB_SENHA` (o container não sobe sem elas) e grava `/etc/nginx/htpasswd` no formato `usuario:{PLAIN}senha`.

O navegador manda o cabeçalho `Authorization` em toda chamada `/api`. O nginx o repassa, e a API **confere de novo** o mesmo usuário e senha.

## Comandos úteis

```bash
docker compose up -d --build              # sobe/atualiza tudo
docker compose ps                         # estado e saúde
docker compose logs -f api worker         # logs
docker compose restart worker             # reinicia o robô (termina a regra atual)
docker compose stop worker                # para o robô com segurança
docker compose run --rm worker python -m ipop.cli --checar-rede --ambiente hml
docker compose exec postgres psql -U analise analise_cotacao
docker compose down                       # derruba (mantém os volumes)
docker compose down -v                    # derruba E APAGA banco e bucket
```
