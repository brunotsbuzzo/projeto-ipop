# Operação (runbook)

## Subir pela primeira vez

```bash
cp .env.example .env
# preencha IPOP_*, SQL_*, WEB_* e troque as senhas padrão
docker compose up -d --build
docker compose ps                       # api deve ficar "healthy"
docker compose logs -f worker           # "Worker worker-1 no ar (ambiente padrão hml)."
docker compose run --rm worker python -m ipop.cli --checar-rede --ambiente hml
```

| Endereço | Uso |
|---|---|
| <http://localhost:8080> | Tela (login `WEB_USUARIO` / `WEB_SENHA`) |
| <http://localhost:8080/api/docs> | Swagger da API (já autenticado pelo navegador) |
| <http://localhost:5050> | pgAdmin |
| <http://localhost:9001> | Console do MinIO |

Na primeira subida, a API cria o schema `robo_ipop` e o bucket `robo-ipop`.

## Atualizar a versão

```bash
git pull
docker compose up -d --build
```

O worker recebe `SIGTERM`, termina a regra atual (até 5 min) e sai. Se uma solicitação estava em andamento, ela fica **Interrompida**: abra o detalhe e clique em **Retomar**.

!!! tip "Melhor momento"
    Atualize quando não houver solicitação *Cadastrando* (veja o histórico ou `GET /api/workers` → `executando`).

## Atualizar as tabelas auxiliares

Para trocar `TblRegraModelo.xlsx` e/ou `TblDePara.xlsx` **sem nova imagem**:

1. abra o console do MinIO (<http://localhost:9001>);
2. entre em `robo-ipop` e crie a pasta `config/tbl_dim/`, se ela não existir;
3. envie **os dois** arquivos, com estes nomes exatos: `TblDePara.xlsx` e `TblRegraModelo.xlsx`.

A próxima validação ou cadastro já usa as tabelas novas, e a planilha-modelo para download também.

!!! warning "Envie sempre as duas"
    Se só uma estiver no bucket, o worker registra um aviso e usa **as duas da imagem**.

Colunas obrigatórias (veja [Tabelas auxiliares](../negocio/tabelas-auxiliares.md)):

- `TblRegraModelo.xlsx`: `Modelos de regras`, `Descrição`, `ID`, `NomeRegraIPOP`
- `TblDePara.xlsx`: `IDVariavel`, `Nome Ipop`, `NomeDW`

Para voltar às tabelas da imagem, apague os arquivos do bucket. Para mudar as tabelas **da imagem**, edite `backend/dados/tbl_dim/` e reconstrua.

## Liberar produção

1. Teste o lote com **uma regra** em homologação.
2. No `.env`: `ROBO_AMBIENTE=prd` e `PERMITIR_PRODUCAO=true`.
3. `docker compose up -d` (recria a API e o worker).
4. A barra lateral da tela passa a mostrar **IPOP produção**.

O ambiente vale para **todas** as solicitações novas. Cada execução grava o seu ambiente, e uma retomada usa o ambiente original.

## Parar e retomar o robô

| Ação | Comando | Efeito |
|---|---|---|
| Parar com segurança | `docker compose stop worker` | Termina a regra atual. A execução fica *Interrompida* |
| Reiniciar | `docker compose restart worker` | Igual, e volta a consumir a fila |
| Forçar | `docker compose kill worker` | Mata na hora. Depois de 2 min, a execução vira *Interrompida* e a regra em andamento fica *Conferir no IPOP* |

Com o worker parado, a tela mostra a faixa amarela *"O robô (worker) está fora do ar"* e as solicitações ficam na fila.

## Tratar uma solicitação parada

1. Abra o detalhe da solicitação no histórico.
2. Leia a caixa vermelha: o motivo e quais regras já foram feitas.
3. Abra o **print** da regra com erro (link na tabela de regras).
4. Se precisar, baixe o `trace.zip` (`/api/solicitacoes/<id>/arquivos/trace.zip`) e abra em <https://trace.playwright.dev>.
5. Corrija a causa.
6. **No IPOP**: procure uma "Cópia de <modelo>" sem preenchimento e apague.
7. Se a regra estiver como **Conferir no IPOP**, procure-a pelo nome no IPOP:
    - se existe e está correta, retome **a partir da próxima** (`POST /retomar` com `{"inicio": N+1}`);
    - se não existe, retome dela mesma (o padrão do botão).
8. Clique em **Retomar da regra N**.

!!! note "Erro na planilha depois do envio"
    Se o problema estiver nos dados da planilha, a solicitação não tem como ser editada. Retomar reprocessa o **mesmo arquivo**. Crie uma **nova solicitação** com a planilha corrigida, contendo só as regras que faltam.

## Logs

```bash
docker compose logs -f api worker
docker compose logs --since 1h worker | grep -i erro
```

| Onde | Conteúdo |
|---|---|
| stdout do `api` | Requisições e erros da API |
| stdout do `worker` | Tudo do worker, em todas as execuções |
| `robo_ipop.logs` | Log de **cada** execução, linha a linha |
| `GET /api/solicitacoes/{id}/log?linhas=400` | Últimas linhas (máx. 5000) em texto |
| Bucket `execucoes/<id>/execucao.log` | Arquivo completo, gravado no fim |

Formato: `AAAA-MM-DD HH:MM:SS | NIVEL | logger | mensagem`. Os passos do formulário registram o tempo (`Selecionar grupo executado em 0.42s`), útil para achar lentidão no IPOP.

## Monitoramento

| Verificação | Como |
|---|---|
| Tela/API no ar | `GET http://host:8080/saude` → `{"ok": true}` (sem login) |
| Worker online | `GET /api/workers` → `online: true` (visto nos últimos 30 s); `GET /api/config` → `worker_online` |
| Rede do worker | `GET /api/workers` → `conectividade[]` e `checado_em`; forçar com `POST /api/workers/checar` |
| Fila parada | Execuções em `na_fila` há muito tempo (consulta em [Banco de dados](banco-de-dados.md#consultas-uteis)) |

## Backup e restauração

```bash
# Postgres (só o schema do robô)
docker compose exec -T postgres pg_dump -U analise -n robo_ipop analise_cotacao > robo_ipop.sql
# restaurar
docker compose exec -T postgres psql -U analise analise_cotacao < robo_ipop.sql

# Bucket (com o cliente mc)
mc alias set local http://localhost:9000 minioadmin minioadmin
mc mirror local/robo-ipop ./backup-robo-ipop
```

## Vários workers

É possível rodar mais de um worker, por exemplo em outra máquina com acesso à rede da HDI, apontando para o mesmo Postgres e S3:

- dê um `WORKER_NOME` diferente a cada um;
- as **validações** se dividem entre eles;
- os **cadastros** continuam um por vez (advisory lock): o segundo worker só serve de reserva.
