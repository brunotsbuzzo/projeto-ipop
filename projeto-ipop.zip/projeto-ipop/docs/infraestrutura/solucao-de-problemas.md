# Solução de problemas

## Subida

| Sintoma | Causa provável | Correção |
|---|---|---|
| `web` reinicia com `Defina WEB_USUARIO` | `WEB_USUARIO`/`WEB_SENHA` vazios | Preencha no `.env` |
| `api` não fica *healthy*; log `Faltam variáveis de ambiente` | `DATABASE_URL`/`S3_*` faltando (fora do compose) | Confira o ambiente |
| `api` cai com `ROBO_AMBIENTE=prd exige PERMITIR_PRODUCAO=true` | Produção sem liberação | Defina `PERMITIR_PRODUCAO=true` ou volte para `hml` |
| `api` cai com `DB_SCHEMA inválido` | Schema com maiúscula, hífen etc. | Use `[a-z_][a-z0-9_]*` |
| Worker: `Postgres/bucket ainda indisponível… Tentativa N/30` e sai com código 3 | Postgres ou MinIO fora | `docker compose ps`; confira as credenciais |
| `docker compose build` falha no ODBC | Sem acesso a `packages.microsoft.com` | Libere o proxy/firewall para o build |

## Tela

| Sintoma | Causa | Correção |
|---|---|---|
| Faixa amarela *"O robô (worker) está fora do ar"* | Worker sem batimento há mais de 30 s | `docker compose logs worker`; `docker compose up -d worker` |
| Arquivo fica em *Validando* para sempre | Worker parado ou preso | Mesmo procedimento acima. A validação continua na fila e roda quando ele voltar |
| *Sem conexão com o servidor.* | API fora ou nginx sem upstream | `docker compose ps api` |
| 413 ao enviar | Planilha acima do limite | Reduza o arquivo ou aumente `TAMANHO_MAXIMO_MB` (e `client_max_body_size` se passar de 25 MB) |
| *Esta planilha já foi enviada…* | A mesma validação foi enviada duas vezes | Abra a solicitação existente no histórico |

## Validação

| Mensagem | Causa | Correção |
|---|---|---|
| `Sem acesso: SQL Server (DNS não resolveu o nome…)` | Nome curto do SQL Server | Use o FQDN/IP, ou `extra_hosts`/`dns` |
| `…mas a porta não respondeu` | Firewall | Libere a 1433 a partir do host do Docker |
| `Login SQL … Login failed` | Usuário ou senha SQL errados | Confira `SQL_USUARIO`/`SQL_SENHA` |
| `Driver ODBC … Não instalado` | Rodando fora da imagem | Instale o `msodbcsql18` ou use o container |
| `Faltam variáveis no .env: SQL_SERVIDOR…` | `.env` incompleto | Preencha e recrie o worker |
| `Nenhuma aba de regras encontrada` | Abas renomeadas | Use `Módulo Subscrição` / `Módulo Oferta` ou mantenha as colunas do modelo |
| `… não está na tabela de variáveis do IPOP` | NomeDW errado ou ausente no De-Para | Corrija o cabeçalho ou atualize `TblDePara.xlsx` |
| `… sem grupo de variáveis no IPOP` | Variável sem `GrupoVariavelDetalhe` | Confira a variável no IPOP/RosieRep |

## Cadastro

| Detalhe da regra / mensagem | Causa provável | O que fazer |
|---|---|---|
| `Login no IPOP não concluiu (usuário/senha errados, conta sem acesso ou IPOP fora do ar).` | Credenciais, conta bloqueada ou IPOP fora | Teste o login à mão; confira `IPOP_*` |
| `O IPOP demorou demais para responder.` | Lentidão do IPOP ou grid grande | Retome. Se repetir, aumente `TIMEOUT_PADRAO_MS` |
| `Um campo ou valor esperado não apareceu na tela do IPOP.` | Tela mudou, valor de domínio ausente ou opção de grupo/variável inexistente | Veja o print e o trace. Pode exigir ajuste de seletor |
| `Regra-modelo N não encontrada na lista do IPOP.` | ID do modelo não existe naquele ambiente/módulo | Corrija `TblRegraModelo.xlsx` |
| `A regra aberta se chama 'X' e não é uma 'Cópia de ...'` | A cópia não abriu; a tela abriu outra regra | Confira a lista no IPOP e apague cópias soltas; retome |
| `A linha com IdDominio N não contém o valor esperado` | Domínio no SQL diferente do grid | Confira o valor no IPOP |
| `A API não retornou uma lista em 'Grid' dentro de 200000 ms` | Grid de CPF/CNPJ não respondeu | Retome. Veja [Filtro do grid pesado](../codigo/backend/automacao-ipop.md#filtro-do-grid-pesado) |
| Regra **Salva · conferir** | Salvou, mas a busca por nome não achou | Procure no IPOP. Pode ser atraso de indexação ou um nome com caracteres especiais |
| Regra **Conferir no IPOP** | O worker caiu no meio dela | Veja [Tratar uma solicitação parada](operacao.md#tratar-uma-solicitacao-parada) |
| Execução *Interrompida* sem regra marcada | Worker parado antes de começar a cadastrar | Retome |

## Depurar uma planilha fora do Docker

```bash
cd backend
python -m ipop.cli --pedido "/caminho/ID3422 - Lote.xlsx" --so-dados
# resultado em dados/execucoes/<carimbo>/ (status.json, regras_enriquecidas.json, execucao.log)
```

Para ver o navegador: `HEADLESS=false python -m ipop.cli --pedido … --ambiente hml`. Veja [Linha de comando](../uso/linha-de-comando.md).

## Ler o trace

1. Baixe `trace.zip` (`/api/solicitacoes/<id>/arquivos/trace.zip` ou pelo console do MinIO).
2. Abra <https://trace.playwright.dev> e arraste o arquivo. Nada é enviado: o trace é aberto no próprio navegador.
3. Use a linha do tempo para ver cada ação, o DOM antes e depois, as chamadas de rede (por exemplo `RecuperaGridIndicadores`) e o console.
