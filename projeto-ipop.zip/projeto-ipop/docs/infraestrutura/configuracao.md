# Variáveis de ambiente

Toda a configuração vem de variáveis de ambiente. Fora do Docker, ela também é lida de um arquivo `.env`: o caminho vem de `ROBO_ENV_FILE`, com padrão `backend/.env`, e as variáveis já definidas não são sobrescritas. **Nenhuma senha fica no código.**

```bash
cp .env.example .env    # na raiz do projeto, ao lado do docker-compose.yml
```

!!! danger "Nunca coloque o `.env` no Git"
    O `.gitignore` e os `.dockerignore` já excluem o arquivo.

Valores booleanos aceitam `1`, `true`, `sim`, `yes` ou `on` (sem diferença de maiúsculas). Qualquer outro valor conta como falso.

## Tela e login

| Variável | Padrão | Obrigatória | Usada por | Descrição |
|---|---|---|---|---|
| `WEB_USUARIO` | — | **sim** (api, web) | nginx, API | Usuário do login HTTP Basic |
| `WEB_SENHA` | — | **sim** (api, web) | nginx, API | Senha do login |
| `WEB_PORTA` | `8080` | não | compose | Porta publicada da tela |
| `CATEGORIAS` | `Renovação Ituran;Frota` | não | API, tela | Categorias do pedido, separadas por `;` |
| `TAMANHO_MAXIMO_MB` | `20` | não | API, tela | Limite da planilha (o nginx aceita até 25 MB) |

## IPOP

| Variável | Padrão | Obrigatória | Descrição |
|---|---|---|---|
| `IPOP_USUARIO` | — | **sim** para cadastro | Conta de **serviço** do IPOP |
| `IPOP_SENHA` | — | **sim** para cadastro | Senha da conta |
| `IPOP_URL_HML` | `https://net.hdi.com.br/rosie/ipop_v4/login` | não | Login do IPOP de homologação |
| `IPOP_URL_PRD` | `https://www.hdi.com.br/rosie/ipop_v4/login` | não | Login do IPOP de produção |
| `ROBO_AMBIENTE` | `hml` | não | Ambiente em que as solicitações da tela são cadastradas: `hml` ou `prd` |
| `PERMITIR_PRODUCAO` | `false` | para `prd` | Precisa ser `true` para `ROBO_AMBIENTE=prd`; sem isso, a configuração é **inválida** e a API e o worker não sobem |
| `OFERTA_MODELO_ID` | `139278` | não | Regra-modelo das linhas de Oferta sem modelo. `0` desliga (a Oferta sem modelo é criada do zero) |

## SQL Server (RosieRep)

| Variável | Padrão | Obrigatória | Descrição |
|---|---|---|---|
| `SQL_SERVIDOR` | — | **sim** | Nome completo (FQDN) ou IP. O nome curto do Windows (`HDIWROSIE01`) costuma não resolver no Linux. Aceita `host,porta` e `host\instancia` |
| `SQL_PORTA` | `1433` | não | Ignorada se `SQL_SERVIDOR` já tiver `,porta` |
| `SQL_BANCO` | `RosieRep` | não | Banco |
| `SQL_USUARIO` | — | **sim** | Usuário SQL (só leitura basta) |
| `SQL_SENHA` | — | **sim** | Senha (`}` é escapado automaticamente na string ODBC) |
| `SQL_DRIVER` | `ODBC Driver 18 for SQL Server` | não | Nome do driver ODBC instalado |
| `SQL_TRUST_CERT` | `true` | não | `TrustServerCertificate`. A conexão usa sempre `Encrypt=yes` |

A string de conexão gerada fica assim:

```text
DRIVER={ODBC Driver 18 for SQL Server};SERVER=host,1433;DATABASE=RosieRep;UID=…;PWD={…};
Encrypt=yes;TrustServerCertificate=yes;Connection Timeout=15;
```

!!! note "O SQL é necessário até para validar"
    A validação consulta grupos e domínios das variáveis. Sem `SQL_*`, a validação termina como **falhou** com *"Faltam variáveis no .env"*.

## Robô (navegador)

| Variável | Padrão | Descrição |
|---|---|---|
| `HEADLESS` | `true` | `false` abre a janela do Chromium (útil fora do Docker para depurar) |
| `NAVEGADOR_CANAL` | vazio | Vazio usa o Chromium do Playwright. `msedge` usa o Edge instalado |
| `TIMEOUT_PADRAO_MS` | `30000` | Timeout padrão de cada ação do Playwright |
| `GRAVAR_TRACE` | `true` | Grava o `trace.zip`. Ele só é **guardado** quando há erro |

## Postgres

| Variável | Padrão | Descrição |
|---|---|---|
| `DATABASE_URL` | — (o compose monta) | `postgresql://user:senha@host:5432/banco`. **Obrigatória** para a API e o worker |
| `DB_SCHEMA` | `robo_ipop` | Schema das tabelas. Só aceita `[a-z_][a-z0-9_]{0,62}`. Também define o canal `<schema>_fila` e a trava `<schema>:robo` |
| `POSTGRES_USER` | `analise` | Usado pelo compose (container e `DATABASE_URL`) |
| `POSTGRES_PASSWORD` | `analise` | Idem. **Troque** |
| `POSTGRES_DB` | `analise_cotacao` | Idem |

## MinIO / S3

| Variável | Padrão | Descrição |
|---|---|---|
| `S3_ENDPOINT` | — (o compose usa `http://minio:9000`) | **Obrigatória** para a API e o worker |
| `S3_ACCESS_KEY` / `S3_SECRET_KEY` | — (o compose usa `MINIO_ROOT_*`) | **Obrigatórias** |
| `S3_BUCKET` | `robo-ipop` | Criado automaticamente se não existir |
| `S3_REGIAO` | `us-east-1` | Região (o MinIO ignora) |
| `MINIO_ROOT_USER` / `MINIO_ROOT_PASSWORD` | `minioadmin` / `minioadmin` | Credenciais do MinIO. **Troque** |

## Worker

| Variável | Padrão | Descrição |
|---|---|---|
| `WORKER_NOME` | hostname | Identificação do worker (o compose usa `worker-1`). Com vários workers, use nomes diferentes |
| `WORKER_INTERVALO_S` | `5` | Intervalo para consultar a fila sem notificação, e espera depois de uma falha no laço |

## pgAdmin

| Variável | Padrão |
|---|---|
| `PGADMIN_EMAIL` | `admin@admin.com` |
| `PGADMIN_SENHA` | `admin` (**troque**) |

## Outras

| Variável | Padrão | Descrição |
|---|---|---|
| `DADOS_DIR` | `backend/dados` | Pasta das tabelas auxiliares padrão (`tbl_dim/`) e das execuções da linha de comando (`execucoes/`) |
| `ROBO_ENV_FILE` | `backend/.env` | Arquivo `.env` lido fora do Docker |

## O que cada processo exige ao subir

| Processo | Falha ao subir se faltar |
|---|---|
| API | `WEB_USUARIO`, `WEB_SENHA`, `DATABASE_URL`, `S3_ENDPOINT`, `S3_ACCESS_KEY`, `S3_SECRET_KEY`; configuração inválida (`ROBO_AMBIENTE`, `DB_SCHEMA`) |
| Worker | `DATABASE_URL`, `S3_*` (código de saída 2); Postgres/bucket inacessível depois de 30 tentativas a cada 2 s (código 3) |
| nginx (`web`) | `WEB_USUARIO`, `WEB_SENHA` |
| Validação | `SQL_SERVIDOR`, `SQL_USUARIO`, `SQL_SENHA` |
| Cadastro | o mesmo da validação, mais `IPOP_USUARIO` e `IPOP_SENHA` |
