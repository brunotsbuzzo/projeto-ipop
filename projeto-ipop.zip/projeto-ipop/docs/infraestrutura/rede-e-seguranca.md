# Rede, acesso e segurança

## Requisitos de rede

| Origem | Destino | Porta | Para quê |
|---|---|---|---|
| Navegador | `web` | `WEB_PORTA` (8080) | Tela e API |
| Operação | `pgadmin` / `minio` console | 5050 / 9001 | Administração |
| `worker` | IPOP hml (`net.hdi.com.br`) | 443 | Cadastro |
| `worker` | IPOP prd (`www.hdi.com.br`) | 443 | Só com `PERMITIR_PRODUCAO=true` |
| `worker` | SQL Server RosieRep | 1433 | Variáveis, grupos e domínios |
| `api`, `worker` | `postgres` / `minio` | 5432 / 9000 | Rede interna do compose |
| build | `packages.microsoft.com`, PyPI, CDN do Playwright, npm | 443 | Só no `docker compose build` |

A **API não precisa** de acesso à rede da HDI: só o worker precisa.

### Testar o acesso

```bash
docker compose run --rm worker python -m ipop.cli --checar-rede --ambiente hml
```

Saída esperada:

```text
[OK ] IPOP (hml)     net.hdi.com.br:443                       Conectou (x.x.x.x).
[OK ] SQL Server     hdiwrosie01.dominio.local:1433           Conectou (10.x.x.x).
[OK ] Driver ODBC    ODBC Driver 18 for SQL Server            Instalado.
[OK ] Login SQL      RosieRep como usuario                    Consulta de teste OK.
```

O worker também faz essa checagem sozinho **a cada 15 minutos** e quando alguém chama `POST /api/workers/checar`. O resultado fica em `GET /api/workers` (campo `conectividade`).

### DNS

No Linux, o nome curto do Windows (`HDIWROSIE01`) costuma não resolver. As opções são:

1. usar o FQDN ou o IP em `SQL_SERVIDOR`;
2. descomentar `extra_hosts` no serviço `worker`;
3. descomentar `dns` com o DNS interno da HDI.

## Autenticação e autorização

| Camada | Mecanismo |
|---|---|
| nginx | `auth_basic` com `WEB_USUARIO` / `WEB_SENHA` (arquivo `htpasswd`, formato `{PLAIN}`) |
| API | `HTTPBasic` do FastAPI. Confere o mesmo usuário e senha com `secrets.compare_digest` (tempo constante). Toda rota `/api/*` exige o login |
| Sem login | Só `/saude` (`{"ok": true}`), para healthcheck |

- Há **um** usuário e senha compartilhados. O usuário logado é gravado em `execucoes.usuario`. O "solicitante" é um campo digitado.
- Não existem papéis: quem entra pode enviar, cancelar e retomar qualquer solicitação.

## Segredos

| Segredo | Onde fica | Recomendação |
|---|---|---|
| Conta do IPOP | `IPOP_USUARIO` / `IPOP_SENHA` | Use uma **conta de serviço**, não a de uma pessoa. As senhas que estavam no código antigo continuam válidas até serem trocadas: troque |
| SQL Server | `SQL_USUARIO` / `SQL_SENHA` | Usuário só de leitura no schema `var` |
| Login da tela | `WEB_USUARIO` / `WEB_SENHA` | Senha forte; troque `troque-esta-senha` |
| Postgres | `POSTGRES_PASSWORD` | Troque `analise` |
| MinIO | `MINIO_ROOT_PASSWORD` | Troque `minioadmin` |
| pgAdmin | `PGADMIN_SENHA` | Troque `admin` |

## Proteções no código

| Risco | Proteção |
|---|---|
| SQL injection no SQL Server | Todas as consultas usam parâmetros `?`. As listas vão em lotes de 1000 (o limite do SQL Server é 2100 parâmetros) |
| SQL injection no Postgres | Parâmetros `%s`. O nome do schema só aceita `[a-z_][a-z0-9_]{0,62}` |
| *Path traversal* em `/arquivos/{caminho}` | Recusa `..` e caminhos absolutos; sempre prefixa `execucoes/<id>/` |
| ID manipulado | IDs validados pela regex `^\d{8}-\d{6}-[0-9a-f]{6}$`. O `tipo` da execução precisa bater com a rota |
| Upload malicioso | Só aceita extensão `.xlsx`/`.xlsm` **e** a assinatura ZIP; limite de tamanho checado durante o streaming |
| Container | Roda como usuário `robo` (uid 1000), não root |
| Produção acidental | `ROBO_AMBIENTE=prd` exige `PERMITIR_PRODUCAO=true` |

## Endurecimento recomendado

- [ ] **HTTPS na frente do `web`.** O login é HTTP Basic e a senha vai em base64 a cada requisição. Fora de uma rede confiável, use um proxy reverso com TLS.
- [ ] **Fechar portas desnecessárias.** `5432` (Postgres), `9000`/`9001` (MinIO) e `5050` (pgAdmin) estão publicadas no host. Remova os `ports:` que não forem usados, ou restrinja a `127.0.0.1:5432:5432`.
- [ ] **Trocar todas as senhas padrão.**
- [ ] **Remover o pgAdmin em produção**, se não for usado.
- [ ] Trocar o MinIO por um S3 mantido (veja o aviso em [Armazenamento](armazenamento.md)).
- [ ] Backups do volume `pgdata` e do bucket (veja [Operação](operacao.md#backup-e-restauracao)).
