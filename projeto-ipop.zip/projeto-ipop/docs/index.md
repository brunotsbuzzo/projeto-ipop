# Cadastro de Regras IPOP

O sistema tem duas partes. A primeira é uma **tela web**, onde a área de negócio pede o cadastro de regras de preço no **IPOP** (sistema de precificação da HDI). A segunda é um **robô**, que faz esse cadastro sozinho no IPOP.

Na tela, a pessoa envia a planilha do pedido, confere a pré-visualização das regras e acompanha o cadastro regra por regra. As regras saem da planilha e são cadastradas pelo robô, que abre o IPOP num navegador automatizado (Playwright/Chromium).

```mermaid
flowchart LR
    U([Pessoa da área de negócio]) -->|planilha .xlsx| W[Tela web<br/>Angular + nginx]
    W -->|/api| A[API<br/>FastAPI]
    A --> PG[(Postgres<br/>fila, andamento, eventos, logs)]
    A --> S3[(MinIO / S3<br/>planilhas, prints, traces, logs)]
    WK[Worker<br/>robô Playwright] --> PG
    WK --> S3
    WK -->|consulta| SQL[(SQL Server<br/>RosieRep)]
    WK -->|Chromium headless| IPOP[IPOP<br/>hml / prd]
```

## Por onde começar

<div class="grid cards" markdown>

- **Negócio**

    ---

    O problema que o sistema resolve, a jornada da solicitação, o formato da planilha, os tipos de regra e as regras de validação.

    [:octicons-arrow-right-24: Negócio](negocio/index.md)

- **Infraestrutura**

    ---

    Arquitetura, Docker Compose, variáveis de ambiente, banco, bucket, rede, segurança e runbook de operação.

    [:octicons-arrow-right-24: Infraestrutura](infraestrutura/index.md)

- **Código**

    ---

    Cada módulo do backend (API, worker, robô, leitura, validação, Playwright) e do frontend (Angular + NG-ZORRO), mais os testes.

    [:octicons-arrow-right-24: Código](codigo/index.md)

- **Como utilizar**

    ---

    O guia da tela para quem pede o cadastro, a instalação, o desenvolvimento local, a linha de comando e exemplos de uso da API.

    [:octicons-arrow-right-24: Como utilizar](uso/index.md)

</div>

## Resumo em uma página

| Item | Valor |
|---|---|
| Usuários | Analistas que pedem cadastro de regras de Subscrição e Oferta no IPOP |
| Entrada | Planilha XLSX do modelo oficial (abas *Módulo Subscrição* e/ou *Módulo Oferta*) |
| Saída | Regras cadastradas no IPOP, cada uma conferida na lista do IPOP depois de salva |
| Ambientes do IPOP | `hml` (homologação, padrão) e `prd` (produção, exige liberação explícita) |
| Backend | Python 3.13, FastAPI, Playwright, pandas, psycopg 3, boto3, pyodbc |
| Frontend | Angular 22, NG-ZORRO 22, tokens do Design System HDI (Figma) |
| Persistência | Postgres 16 (schema `robo_ipop`) + MinIO (bucket `robo-ipop`) |
| Fila | A própria tabela `execucoes` (`FOR UPDATE SKIP LOCKED` + `LISTEN/NOTIFY`), sem broker |
| Concorrência | Um único cadastro no IPOP por vez em todo o sistema (advisory lock do Postgres) |
| Autenticação da tela | HTTP Basic (nginx e API, mesmo usuário e senha) |

!!! warning "Antes do primeiro lote real"
    Os testes automatizados rodam o robô contra uma **imitação** das telas do IPOP. Eles provam o fluxo, não as telas reais. **O primeiro lote no IPOP de homologação deve ter uma regra só.** O fluxo de **Oferta** ainda não foi testado no IPOP real.

## Ler esta documentação localmente

```bash
pip install -r docs/requirements.txt
mkdocs serve          # http://127.0.0.1:8000
mkdocs build          # gera o site estático em site/
```
