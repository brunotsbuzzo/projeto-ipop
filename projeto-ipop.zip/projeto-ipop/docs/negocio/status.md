# Status e situações

Existem três níveis de estado:

1. o **status da solicitação**, que a pessoa vê no histórico e no detalhe;
2. a **fase técnica** da execução, gravada no banco;
3. a **situação de cada regra**.

## Status da solicitação (tela)

| Status na tela | Código | Fase(s) técnica(s) | Cor (Status Tag) |
|---|---|---|---|
| Recebida | `recebida` | `na_fila`, `reservada` | info (azul-petróleo) |
| Conferindo dados | `conferindo` | `verificando_rede`, `lendo_planilha` | processing (amarelo) |
| Cadastrando · N de M | `cadastrando` | `login`, `cadastrando` | processing (amarelo) |
| Concluída | `concluida` | `concluida` | success (verde) |
| Planilha com erros | `erro` | `erro_validacao` | error (vermelho) |
| Parou na regra N | `erro` | `erro`/`interrompida` com uma regra em *Erro* ou *Conferir no IPOP* | error |
| Interrompida | `erro` | `interrompida` sem regra marcada | error |
| Erro | `erro` | `erro` sem regra marcada (rede, login, configuração) | error |
| Cancelada | `cancelada` | `cancelada` | default (cinza) |

Em *Cadastrando · N de M*, N é o número de regras já feitas mais 1, limitado ao total.

## Máquina de estados da execução

```mermaid
stateDiagram-v2
    [*] --> na_fila: criada / retomada
    na_fila --> reservada: worker pega
    na_fila --> cancelada: cancelar (na fila)
    reservada --> verificando_rede
    verificando_rede --> lendo_planilha
    verificando_rede --> erro: sem acesso / falta configuração
    lendo_planilha --> erro_validacao: planilha com erros
    lendo_planilha --> concluida_so_dados: validação (só dados)
    lendo_planilha --> login: cadastro
    login --> cadastrando
    login --> erro: login falhou
    cadastrando --> concluida: todas OK
    cadastrando --> erro: parou na regra N
    cadastrando --> cancelada: cancelamento pedido
    cadastrando --> interrompida: worker desligado (SIGTERM)
    reservada --> interrompida: worker sem sinal > 2 min
    cadastrando --> interrompida: worker sem sinal > 2 min
    erro --> na_fila: Retomar
    interrompida --> na_fila: Retomar
    cancelada --> na_fila: Retomar
    concluida --> [*]
    concluida_so_dados --> [*]
    erro_validacao --> [*]
```

| Fase | Final? | Significado |
|---|---|---|
| `na_fila` | não | Aguardando um worker |
| `reservada` | não | Um worker pegou e está preparando (baixando a planilha) |
| `verificando_rede` | não | Testando o acesso ao IPOP, ao SQL Server e ao driver ODBC |
| `lendo_planilha` | não | Lendo, enriquecendo e validando |
| `login` | não | Entrando no IPOP |
| `cadastrando` | não | Cadastrando regra por regra |
| `concluida` | sim | Cadastro terminado sem falhas |
| `concluida_so_dados` | sim | Validação terminada sem erros (nada foi cadastrado) |
| `erro` | sim | Parou: regra com falha, rede, login, configuração ou erro inesperado |
| `erro_validacao` | sim | Planilha com erros: nada foi cadastrado |
| `cancelada` | sim | Cancelada pela pessoa |
| `interrompida` | sim | O worker foi desligado ou parou de responder |

## Validação (antes do envio)

| Status da validação | Quando |
|---|---|
| `validando` | Ainda não terminou |
| `valido` | Fase `concluida_so_dados`: pode enviar |
| `com_erros` | Fase `erro_validacao`: precisa corrigir |
| `falhou` | Qualquer outra fase final (sem acesso ao SQL, configuração faltando etc.) |

## Situação de cada regra

| Situação | Rótulo na tela | Cor | Significado |
|---|---|---|---|
| `pendente` | Pendente | default | Ainda não chegou a vez |
| `executando` | Cadastrando | processing | O robô está nela agora |
| `confirmada` | Cadastrada | success | Salva **e** encontrada na lista do IPOP |
| `salva_sem_confirmacao` | Salva · conferir | warning | Salva, mas não apareceu na busca da lista. Confira no IPOP |
| `erro` | Erro | error | Falhou. O motivo e o print aparecem no detalhe |
| `verificar` | Conferir no IPOP | warning | O worker caiu durante esta regra. **Ela pode ter sido salva** |
| `não executada` | Não executada | default | O robô parou antes de chegar nela |
| `pulada` | Pulada | default | A execução começou depois dela (retomada) e ela não tinha sido cadastrada antes |

`confirmada` e `salva_sem_confirmacao` contam como **feitas**: entram no total de cadastradas e nunca são refeitas numa retomada.

## Quando os botões aparecem

| Botão | Condição |
|---|---|
| **Cancelar execução** | A solicitação não está numa fase final e ainda não houve pedido de cancelamento |
| **Retomar da regra N** | Fase `erro`, `interrompida` ou `cancelada` **e** pelo menos uma regra não feita. N é a primeira regra não feita |
