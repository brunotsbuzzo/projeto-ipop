# Tipos de regra e módulos

## Módulos do IPOP

| Módulo | Aba da planilha | Campo de percentual no IPOP | Exemplo de uso |
|---|---|---|---|
| **Subscrição** | Módulo Subscrição | `Percentual de ajuste` (`#percentual_ajuste_input`) | Agravo/desconto por parceiro, CPF/CNPJ, bônus, idade |
| **Oferta** | Módulo Oferta | `Percentual de desconto` (`#percentual_desconto_input`) | Desconto para um agrupamento de CPF/CNPJ |

## Tipos de regra de Subscrição

| Tipo de regra (texto exato) | Classe no código | O que o Fator vira no IPOP |
|---|---|---|
| `Agravo/Desconto` com Fator **> 1** | `RegraAgravo` | `(Fator − 1) × 100` → `1,58` vira **58** |
| `Agravo/Desconto` com Fator **≤ 1** | `RegraDesconto` | `(Fator − 1) × 100` → `0,90` vira **−10** |
| `Não exibe prêmio` | `RegraRecusa` | O Fator vai **como está** |
| `Ajuste por relac. IS` | `RegraEngenhariaReversa` | O Fator vai **como está** |

Qualquer outro texto é **erro de validação**: *"Tipo de regra: 'X' não é suportado."* A comparação ignora maiúsculas e minúsculas, mas não acentos.

O resultado é arredondado em 2 casas decimais. Inteiros vão sem casa decimal (`58`, não `58.0`).

!!! info "Não exibe prêmio"
    Para esse tipo, o robô também preenche:

    - **Subscrição balanceada** = `False` (a planilha não tem coluna para isso; o valor padrão é sempre *não*);
    - **Mensagem HDI Digital** = `Motivos técnicos.`

    Se a subscrição balanceada estivesse ligada, o robô também escreveria *"Encaminhar para mesa de Subscrição Balanceada."*, mas esse caminho não é usado pela planilha hoje.

## Oferta

| Classe | Percentual |
|---|---|
| `RegraOferta` | O `Fator (%)` vai **como está** (`6` → `6`) |

O tipo de regra da Oferta é `Oferta` por padrão. O robô só o seleciona se o IPOP mostrar o campo *Tipo* com essa opção.

## Regra-modelo × regra do zero

```mermaid
flowchart TD
    A[Regra da planilha] --> B{Tem modelo?}
    B -- "id_regra_modelo / ID" --> C[Usa o ID informado]
    B -- "Modelos de regras = nome" --> D{Nome está na<br/>tabela de modelos?}
    D -- sim --> C
    D -- não --> E[ERRO: modelo não está<br/>na lista oficial]
    B -- vazio / Não se aplica --> F{Módulo Oferta?}
    F -- sim --> G[Usa OFERTA_MODELO_ID<br/>padrão 139278]
    F -- não --> H[AVISO: criada do zero<br/>botão 'Nova']
    C --> I[Copia o modelo no IPOP<br/>e edita a 'Cópia de …']
    G --> I
```

- **Com modelo:** o robô procura a regra-modelo pelo ID na lista do IPOP (se não achar pelo ID, tenta pelo nome), clica em **Copiar → Confirmar** e abre a cópia. A cópia já traz as variáveis do modelo (produto, fluxo, roteiro…). O robô só acrescenta as da planilha.
- **Sem modelo (Subscrição):** o robô usa **Nova** e a regra fica só com as variáveis da planilha.
- O nome do modelo é comparado sem acentos, espaços, pontuação ou diferença de maiúsculas: `Ituran Não Compreensiva` = `ituran nao compreensiva`.

## Variáveis

| Tipo | Como o robô preenche no IPOP |
|---|---|
| **Categórica** | Seleciona o grupo, a variável e o tipo de lista (sempre `3`). Marca no grid as linhas dos valores e clica em **Igual** (inclusão) ou **Diferente** (exclusão) |
| **Contínua** | Para cada faixa, preenche *valor inicial* e *valor final* e clica em adicionar. Depois seleciona todas as faixas e aplica a ação |

Para variáveis categóricas, o robô localiza cada valor no grid do IPOP:

1. **pelo IdDominio**, quando o SQL Server encontrou o domínio. A linha precisa ainda **mostrar o texto esperado**: se não mostrar, o robô para para não cadastrar o valor errado;
2. **pelo texto exato** da célula, quando não há ID (assim `10` não casa com `100`).

`CodGrpModelo` é exceção: é sempre selecionado pelo texto exibido.
