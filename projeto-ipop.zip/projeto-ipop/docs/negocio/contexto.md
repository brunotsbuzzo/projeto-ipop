# Contexto e objetivos

## O problema

As regras de preço do seguro auto da HDI ficam no **IPOP**, nos módulos **Subscrição** e **Oferta**. Exemplos: agravos, descontos, recusas e ofertas por parceiro, CPF/CNPJ, classe de bônus ou faixa de idade. Cada campanha ou renovação (por exemplo, *Renovação Ituran* ou *Frota*) gera um **lote** de regras, registrado no **Taskflow** com um ID de lote.

Antes deste sistema, o cadastro era feito por robôs Selenium separados para Subscrição e Oferta (o projeto `RoboIPOP-Subs-Oferta`), rodados à mão, ou digitado regra a regra na tela do IPOP. Esse processo tinha alguns problemas:

- dava para cadastrar regras **em dobro** quando uma execução era repetida;
- os erros de preenchimento só apareciam no meio do cadastro, com parte do lote já salva;
- não havia histórico de quem pediu o quê, nem do que de fato foi cadastrado;
- as senhas do IPOP e do SQL Server ficavam no código.

## A solução

| Objetivo | Como o sistema atende |
|---|---|
| Pedido rastreável | Toda solicitação tem título, **ID do lote do Taskflow**, solicitante, categoria, planilha original e linha do tempo de eventos |
| Erro antes do cadastro | A planilha é **validada antes do envio**, com as tabelas do IPOP e o SQL Server. Erros bloqueiam o envio e apontam a linha e a célula |
| Sem cadastro em dobro | A fila não reenvia nada sozinha. A retomada pula as regras já cadastradas. Uma regra interrompida no meio fica marcada como **Conferir no IPOP** |
| Sem alterar regra existente | O robô só edita uma regra cujo nome começa com **"Cópia de"** |
| Transparência | A tela mostra cada regra (*Pendente → Cadastrando → Cadastrada*), o motivo de uma parada e o print da tela do IPOP no momento do erro |
| Segurança | As credenciais ficam em variáveis de ambiente, numa conta de serviço do IPOP. Produção fica bloqueada por padrão |

## Quem usa

| Papel | O que faz |
|---|---|
| **Solicitante** (analista de pricing/subscrição) | Preenche a planilha, envia pela tela, acompanha e retoma quando o robô para |
| **Operação/TI** | Sobe e mantém os serviços, atualiza as tabelas auxiliares, confere logs, prints e traces |
| **Robô** (worker) | Confere a planilha, entra no IPOP com a conta de serviço e cadastra as regras uma a uma |

## Categorias de pedido

A categoria é escolhida no formulário e configurada em `CATEGORIAS`. Os valores padrão são:

- **Renovação Ituran**
- **Frota**

Hoje a categoria serve só para classificar a solicitação: ela não muda o comportamento do robô.

## Escopo

**Faz parte do sistema:**

- cadastrar regras novas de **Subscrição** (Agravo/Desconto, Não exibe prêmio, Ajuste por relac. IS) e de **Oferta**;
- criar a regra a partir de uma **regra-modelo** (cópia) ou **do zero** ("Não se aplica");
- incluir variáveis categóricas e contínuas com ação de inclusão (igual) ou exclusão (diferente).

**Fica de fora:**

- alterar, aprovar, retificar, encerrar ou excluir regras já existentes no IPOP;
- apagar a "Cópia de…" que pode sobrar no IPOP quando uma regra falha (isso é conferência manual);
- integração automática com o Taskflow (o ID do lote é digitado).
