# Negócio

Esta seção explica o sistema do ponto de vista de quem pede e de quem aprova o cadastro de regras. Ela não depende de conhecer o código.

| Página | O que responde |
|---|---|
| [Contexto e objetivos](contexto.md) | Por que o sistema existe, quem usa e o que muda em relação ao processo antigo |
| [Jornada da solicitação](jornada.md) | O caminho da planilha, do envio até a regra cadastrada no IPOP |
| [Status e situações](status.md) | O que cada status da solicitação e cada situação da regra significa |
| [A planilha do pedido](planilha.md) | Como preencher as abas, as colunas e as variáveis |
| [Tipos de regra e módulos](tipos-de-regra.md) | Subscrição × Oferta, Agravo/Desconto, Recusa, Ajuste por relac. IS, e como o Fator vira percentual |
| [Regras de validação](validacao.md) | A lista completa de erros (bloqueiam) e avisos (não bloqueiam) |
| [Tabelas auxiliares](tabelas-auxiliares.md) | Modelos de regra e tabela de variáveis (De-Para) |
| [Salvaguardas](salvaguardas.md) | As travas que impedem cadastro em dobro, alteração de regra existente e uso acidental de produção |
| [Glossário](glossario.md) | Termos usados nas telas e no código |
