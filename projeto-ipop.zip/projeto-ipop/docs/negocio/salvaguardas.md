# Salvaguardas do negócio

Um erro no IPOP afeta preço de apólice de verdade. Por isso o sistema prefere **parar e pedir conferência** a adivinhar o que fazer. Estas são as travas e o motivo de cada uma.

## 1. Nada é cadastrado com erro na planilha

A validação junta todos os problemas antes de abrir o navegador. Com qualquer **erro**, nenhuma regra do lote é cadastrada, nem as regras certas. Isso evita lotes cadastrados pela metade.

## 2. Um cadastro por vez

Só um robô fica no IPOP por vez, em todo o sistema, mesmo com vários workers (advisory lock do Postgres). Dois robôs ao mesmo tempo poderiam se confundir na lista do IPOP, por exemplo selecionando a "Cópia de…" do outro.

A **validação** não abre o IPOP, então roda em paralelo ao cadastro.

## 3. Nada volta sozinho para a fila

Se o worker cair no meio de uma regra, a execução **não** é reenviada automaticamente:

- depois de **2 minutos** sem sinal de vida do worker, a execução vira **Interrompida**;
- a regra que estava em andamento vira **Conferir no IPOP**, porque **pode ter sido salva**;
- as regras pendentes viram **Não executada**.

Uma pessoa confere no IPOP e decide retomar. Repetir sozinho poderia cadastrar a regra em dobro.

## 4. Retomada sem duplicar

A retomada começa da regra escolhida (padrão: a primeira não feita). As regras já feitas (**Cadastrada** ou **Salva · conferir**) **mantêm a situação** e nunca são refeitas, nem quando estão antes do ponto de retomada.

## 5. Só edita "Cópia de…"

Depois de copiar a regra-modelo, o robô confere o nome da regra aberta. Se não começar com **"Cópia de"**, ele para **sem salvar**:

> A regra aberta se chama 'X' e não é uma 'Cópia de ...'. Parei sem salvar para não alterar uma regra existente.

Sem essa trava, um clique na linha errada renomearia e alteraria uma regra que já está em produção no IPOP.

## 6. Conferência do valor do domínio

Quando o valor categórico é selecionado pelo ID do domínio, o robô confere se a linha do grid **mostra o texto esperado**. Se não mostrar, para:

> A linha com IdDominio N não contém o valor esperado 'X'. Parando para não cadastrar valor errado.

Na busca por texto, a comparação é **exata**: `10` não casa com `100`.

## 7. Confirmação depois de salvar

Depois de salvar, o robô procura a regra pelo nome na lista do IPOP:

- se encontra, a regra fica **Cadastrada**;
- se não encontra, fica **Salva · conferir**: foi salva, mas alguém precisa confirmar no IPOP.

## 8. Para na primeira falha

Por padrão (e sempre, quando a execução vem da tela), o robô **para na primeira regra que falha**. Assim a causa é corrigida antes de repetir o mesmo erro em todo o lote. A linha de comando aceita `--continuar-em-erro`, só para depuração.

## 9. Produção bloqueada por padrão

- O ambiente das solicitações vem de `ROBO_AMBIENTE` (padrão `hml`).
- `ROBO_AMBIENTE=prd` só funciona com `PERMITIR_PRODUCAO=true`. Sem isso, a API e o worker **nem sobem**.
- Mesmo pela linha de comando, `--ambiente prd` sem `PERMITIR_PRODUCAO=true` termina com *"Produção bloqueada"*.

## 10. Desligamento seguro

Ao receber `SIGTERM` (por exemplo `docker compose stop worker`), o robô **termina a regra atual** e só então sai. O compose dá até 5 minutos para isso. A execução fica **Interrompida** e pode ser retomada. Um segundo sinal força a saída na hora.

## 11. Uma planilha validada vira uma solicitação só

A mesma validação não pode ser enviada duas vezes. Um clique duplo em *Enviar* não cria dois lotes.

## O que continua manual

!!! warning "Cópia órfã no IPOP"
    Quando uma regra falha **depois** de o modelo ter sido copiado, a "Cópia de…" pode ficar no IPOP sem preenchimento. O robô **não apaga nada** no IPOP. Antes de retomar, confira e apague essa cópia à mão. A tela lembra disso na caixa vermelha do detalhe e no diálogo de retomada.
