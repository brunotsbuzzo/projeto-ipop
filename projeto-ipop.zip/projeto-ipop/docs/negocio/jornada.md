# Jornada da solicitação

```mermaid
sequenceDiagram
    autonumber
    actor P as Solicitante
    participant T as Tela
    participant API
    participant W as Worker (robô)
    participant SQL as SQL Server
    participant I as IPOP

    P->>T: Preenche identificação e anexa a planilha
    T->>API: POST /api/validacoes (arquivo)
    API-->>T: id da validação (status "validando")
    W->>API: (via Postgres) pega a validação
    W->>SQL: consulta variáveis, grupos e domínios
    W-->>T: regras + erros + avisos (pré-visualização)
    alt Planilha com erros
        T-->>P: Mostra os erros por linha/célula, bloqueia o envio
        P->>T: Corrige e substitui o arquivo
    else Sem erros
        P->>T: Enviar solicitação
        T->>API: POST /api/solicitacoes
        API-->>T: Solicitação "Recebida" (na fila)
        W->>W: Confere a planilha de novo ("Conferindo dados")
        W->>I: Login com a conta de serviço
        loop Para cada regra
            W->>I: Copia o modelo (ou "Nova"), preenche, salva
            W->>I: Procura a regra na lista (confirmação)
            W-->>T: Regra N "Cadastrada"
        end
        W-->>T: "Concluída"
    end
```

## Passo a passo

### 1. Nova solicitação

A pessoa informa os **4 campos obrigatórios**:

| Campo | Limite | Observação |
|---|---|---|
| Título da solicitação | 200 caracteres | Texto livre |
| ID do lote (do Taskflow) | 40 caracteres | É o "ID solicitado" que aparece no histórico |
| Nome do solicitante | 120 caracteres | Quem pediu (pode não ser quem está logado) |
| Categoria do pedido | Lista | Vem de `CATEGORIAS` |

Depois anexa a **planilha** (`.xlsx` ou `.xlsm`, até `TAMANHO_MAXIMO_MB`, padrão 20 MB). O botão **Baixar modelo da planilha** gera o modelo oficial a partir das [tabelas auxiliares](tabelas-auxiliares.md) em uso.

### 2. Validação (antes do envio)

Ao anexar, o arquivo é gravado no bucket e o worker o confere **sem abrir o IPOP**:

1. testa o acesso ao SQL Server (a falta de acesso ao IPOP não bloqueia a validação);
2. lê as abas de regra;
3. completa cada regra com a regra-modelo e o código das variáveis (tabelas auxiliares);
4. consulta no SQL Server os grupos de variável e os domínios de cada valor;
5. aplica as [regras de validação](validacao.md).

A tela mostra a **pré-visualização**: uma aba por módulo, uma linha por regra, com a linha da planilha. Ela aparece em três situações:

- **Nenhum erro:** o botão *Enviar solicitação* é liberado.
- **Erros:** a linha fica com fundo vermelho e a célula errada em vermelho. *Nenhuma regra é enviada enquanto houver erros.* A pessoa corrige e usa *Substituir arquivo*.
- **Avisos:** aparecem numa caixa amarela, mas **não impedem o envio**.

### 3. Envio

A solicitação entra na fila com o status **Recebida** e a tela de **Envio confirmado** aparece. Cada validação só pode ser enviada **uma vez**: um segundo envio da mesma validação é recusado com a mensagem *"Esta planilha já foi enviada na solicitação do lote X"*.

### 4. Cadastro

Quando chega a vez dessa solicitação (só existe **um cadastro por vez** no sistema inteiro), o robô segue estes passos:

1. **Conferindo dados:** testa a rede, relê e revalida a planilha (as tabelas podem ter mudado desde a validação);
2. **Cadastrando · N de M:** entra no IPOP e, para cada regra:
    - entra no módulo certo (Subscrição ou Oferta);
    - copia a regra-modelo ou abre uma regra nova;
    - confere se a regra aberta é mesmo uma **"Cópia de…"**;
    - preenche nome, vigência, percentual, tipo e variáveis;
    - salva, fecha e **procura a regra na lista** para confirmar;
3. **Concluída:** todas as regras foram cadastradas e conferidas.

### 5. Se o robô parar

Na primeira regra que falha, o robô **para** e:

- marca a regra como **Erro**, com o motivo e o **print da tela**;
- marca as seguintes como **Não executada**;
- guarda a gravação completa da sessão (`trace.zip`) para a TI.

O detalhe da solicitação mostra o motivo e o botão **Retomar da regra N**. Antes de retomar, a pessoa:

1. corrige a causa (na planilha, no IPOP ou na rede);
2. confere no IPOP se sobrou uma **"Cópia de…"** sem preenchimento e a apaga.

As regras já cadastradas **não são criadas de novo** na retomada.

### 6. Cancelamento

- **Na fila:** cancela na hora.
- **Em andamento:** o robô termina a regra atual e para. As seguintes ficam como *Não executada* e a solicitação pode ser retomada depois.

## Tempos de atualização da tela

| Tela | Atualiza a cada |
|---|---|
| Validação do arquivo | 1,5 s, até sair de "validando" |
| Detalhe da solicitação | 3 s, enquanto a solicitação está ativa |
| Histórico | 10 s |
