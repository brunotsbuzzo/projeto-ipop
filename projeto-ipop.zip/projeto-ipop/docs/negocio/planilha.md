# A planilha do pedido

!!! tip "Comece pelo modelo"
    Use o botão **Baixar modelo da planilha (.xlsx)** (na tela ou em `GET /api/modelo-planilha`). O modelo é gerado na hora a partir das tabelas auxiliares em uso, então as abas *Modelos de regras* e *Tabela de variáveis* estão sempre atualizadas.

## Regra geral

- **Uma linha = uma regra.**
- As regras são cadastradas **na ordem**: primeiro as abas na ordem do arquivo, depois as linhas de cima para baixo. O número **N** de cada regra (1, 2, 3…) segue essa ordem.
- Linhas totalmente vazias (sem *Nome da ação*, *Tipo de regra* e *Fator*) são ignoradas.
- A coluna **Linha** da pré-visualização é a linha do Excel (o cabeçalho é a linha 1).

## Abas do modelo oficial

| Aba | Para quê | Lida pelo robô? |
|---|---|---|
| **Módulo Subscrição** | Regras de Subscrição | Sim |
| **Módulo Oferta** | Agrupamentos de Oferta | Sim |
| Tabela de variáveis | Consulta: nomes aceitos nas colunas de variável | Não |
| Modelos de regras | Consulta: modelos aceitos | Não |
| Como preencher | Instruções | Não |

### Como o robô reconhece uma aba de regras

| Tipo | A aba é lida quando |
|---|---|
| Oferta | o nome, sem acento e em minúsculas, é `oferta`, `modulo oferta` ou `modulo de oferta`, **ou** a aba tem as colunas `Nome Agrupamento`, `Fator (%)`, `Data Inicial` e `Data Final` |
| Subscrição | a aba tem as colunas `Nome da ação`, `Tipo de regra`, `Fator` e `Data inicial`, **ou** o nome começa com "Módulo" e há a coluna `Nome da ação` |

Abas que não se encaixam são ignoradas. Se nenhuma aba de regras for encontrada, a validação falha com: *"Nenhuma aba de regras encontrada. O nome da aba precisa começar com 'Módulo' (ex.: 'Módulo Subscrição') ou ser 'Oferta'."*

---

## Aba Módulo Subscrição

### Colunas fixas

| Coluna | Obrigatória | Formato | Uso |
|---|---|---|---|
| `Negócio` | não | texto | Só informativo (aparece na pré-visualização) |
| `Data inicial` | não¹ | data do Excel, `AAAA-MM-DD`, `DD/MM/AAAA` ou `DDMMAAAA` | Início da vigência (hora 00:00) |
| `Data final` | não¹ | idem | Fim da vigência (hora 23:59) |
| `Nome da ação` | **sim** | texto | Nome da regra no IPOP |
| `Tipo de regra` | **sim** | `Agravo/Desconto`, `Não exibe prêmio` ou `Ajuste por relac. IS` | Ver [Tipos de regra](tipos-de-regra.md) |
| `Fator` | **sim** | número (vírgula ou ponto) | Multiplicador: `1,58` = +58%; `0,90` = −10% |
| `Modelos de regras` | não | nome da aba *Modelos de regras* ou `Não se aplica` | Regra-modelo a copiar |
| `Descrição do modelo de regra` | não | texto | Só informativo |

¹ Se a data ficar vazia, o robô usa **31/12/2070**. Isso vale também para a data inicial: preencha sempre as duas.

Também são aceitas as colunas `id_regra_modelo` ou `ID`, com o código numérico da regra-modelo. Quando existem, elas têm prioridade sobre o nome do modelo.

### Colunas de variável

Toda coluna que não é fixa é lida como variável se o nome seguir o padrão:

```
<NomeDW> <Inclusão|Exclusão> (<Categórica|Contínua>)
```

| Exemplo de cabeçalho | Variável | Ação | Tipo |
|---|---|---|---|
| `CodParceiro Exclusão (Categórica)` | CodParceiro | exclusão (diferente) | categórica |
| `NroCpfCnpj Inclusão (Categórica)` | NroCpfCnpj | inclusão (igual) | categórica |
| `ClasseBonus Inclusão (Categórica)` | ClasseBonus | inclusão | categórica |
| `IdadeSegurado Inclusão (Contínua)` | IdadeSegurado | inclusão | contínua |
| `CodParceiro (Exclusão)` | CodParceiro | exclusão | categórica (forma curta) |
| `ClasseBonus Igual (Categórica)` | ClasseBonus | inclusão | `Igual` = inclusão, `Diferente` = exclusão |

Detalhes da leitura:

- `<NomeDW>` precisa estar na coluna **NomeDW** da [tabela de variáveis](tabelas-auxiliares.md#tabela-de-variaveis-de-para). Maiúsculas, minúsculas e acentos contam.
- Sem ação escrita, vale **inclusão**.
- Colunas sem `( … )` no fim são **ignoradas**, como as colunas de ajuda "Clique aqui escolha a Variável…".
- Célula vazia: a variável não entra nessa regra.

### Valores

| Tipo | Formato | Exemplo |
|---|---|---|
| Categórica | valores separados por `;` | `5; 6; 7` |
| Contínua | faixas `mín a máx` separadas por `;` (inteiros) | `18 a 25; 26 a 40` |

Números inteiros que o Excel guarda como `10.0` viram `10`. Uma faixa contínua fora do padrão (por exemplo `18-25`) **interrompe a leitura** com *"faixa inválida '18-25'. Use o formato '18 a 25'"*.

### Exemplo

| Negócio | Data inicial | Data final | Nome da ação | Tipo de regra | Fator | Modelos de regras | CodParceiro Exclusão (Categórica) | ClasseBonus Inclusão (Categórica) | IdadeSegurado Inclusão (Contínua) |
|---|---|---|---|---|---|---|---|---|---|
| Automóvel | 2026-11-01 | 2026-11-30 | R_EXEMPLO_Agravo_10% | Agravo/Desconto | 1,10 | Ituran Compreensiva | 10 | 5; 6; 7 | 18 a 25 |

---

## Aba Módulo Oferta

| Coluna | Obrigatória | Uso |
|---|---|---|
| `Nome Agrupamento` (ou `Nome da ação`) | **sim** | Nome da regra **e** valor do agrupamento de CPF/CNPJ |
| `Fator (%)` (ou `Fator`) | **sim** | Percentual **como deve aparecer no IPOP** (`6` = 6%) |
| `Data Inicial` / `Data inicial` | não¹ | Início da vigência |
| `Data Final` / `Data final` | não¹ | Fim da vigência |
| `Tipo de regra` | não | Padrão: `Oferta` |
| `Modelos de regras`, `id_regra_modelo`, `ID` | não | Sem modelo, usa a regra-modelo padrão de Oferta (`OFERTA_MODELO_ID`, padrão **139278**) |
| `Código Parceiro (Exclusão)` | não | Vira a variável `CodParceiro` com exclusão |
| Outras colunas `<NomeDW> … (<tipo>)` | não | Lidas como na Subscrição |

Regras próprias da Oferta:

- **CPF/CNPJ automático:** toda regra de Oferta recebe a variável `NroCpfCnpj` (inclusão, categórica) com **o valor igual ao Nome Agrupamento**. Se existir uma coluna de CPF/CNPJ, o valor da célula também é trocado pelo nome do agrupamento.
- Colunas de parceiro (`Código Parceiro`, `CodParceiro`) são normalizadas para `CodParceiro`. Sem `( … )` no nome, a coluna é tratada como categórica.

### Exemplo

| Nome Agrupamento | Fator (%) | Data Inicial | Data Final | Código Parceiro (Exclusão) |
|---|---|---|---|---|
| R_EXEMPLO_Oferta_6% | 6 | 2026-11-01 | 2026-11-30 | 10 |

---

## Subscrição e Oferta no mesmo arquivo

Pode. Preencha as duas abas: o robô troca de módulo no IPOP sozinho. Na pré-visualização, cada módulo tem a sua aba.
