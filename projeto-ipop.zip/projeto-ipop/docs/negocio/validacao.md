# Regras de validação

A validação roda **antes do envio** e **de novo** quando o cadastro começa. Ela reúne **todos** os problemas de uma vez, em vez de parar no primeiro, para que a pessoa corrija tudo numa rodada só.

- **Erro:** bloqueia o envio (ou, no cadastro, impede que **qualquer** regra seja cadastrada).
- **Aviso:** não bloqueia. Mostra algo que o robô vai tratar sozinho ou que pode ser intencional.

Cada problema traz a aba, a linha do Excel, o nome da regra, o **campo** e a mensagem. A tela usa o campo para pintar de vermelho a célula correspondente.

## Erros

| Campo | Mensagem | Causa |
|---|---|---|
| `nome` | Nome da ação: coluna vazia. | `Nome da ação` em branco numa linha preenchida |
| `fator` | Fator: coluna vazia. | `Fator` em branco |
| `fator` | Fator: "X" não é um número. | Texto como `1,1O` (letra O) |
| `vigencia` | Vigência: a data inicial (dd/mm/aaaa) é depois da data final (dd/mm/aaaa). | Datas invertidas |
| `tipo` | Tipo de regra: "X" não é suportado. | Subscrição com tipo fora dos 3 aceitos |
| `modelo` | Modelo de regra: "X" não está na lista oficial de modelos. | Nome de modelo que não está em `TblRegraModelo` |
| `variaveis` | Variáveis: "X" não está na tabela de variáveis do IPOP. | NomeDW fora de `TblDePara` |
| `variaveis` | Variáveis: Nome (ID) sem grupo de variáveis no IPOP. | O SQL Server não tem grupo (`GrupoVariavelDetalhe`) para a variável |
| `variaveis` | Variáveis: Nome (ID) sem valores. | Variável sem nenhum valor depois da leitura |

## Avisos

| Campo | Mensagem | Por que é só aviso |
|---|---|---|
| `nome` | Nome da ação: "X" repetido (também na linha N). | Às vezes é de propósito, por exemplo uma regra por filial com o mesmo nome (caso do lote ID3420) |
| `modelo` | Modelo de regra: sem regra-modelo. A regra será criada do zero. | Subscrição sem modelo é permitida |
| `variaveis` | Variáveis: regra sem nenhuma variável. | Permitido, mas raro |
| `variaveis` | Variáveis: Nome (ID) · valores não está nas tabelas do IPOP. O robô vai procurar pelo texto na lista. | O domínio não foi achado no SQL Server; o robô tenta pelo texto no grid |

## Erros que interrompem a leitura

Estes não viram lista de problemas: a validação termina como **falhou**, com uma mensagem única.

| Situação | Mensagem |
|---|---|
| Arquivo não é Excel | `Erro ao ler o arquivo Excel: …` |
| Nenhuma aba de regras | `Nenhuma aba de regras encontrada…` |
| Aba de Subscrição sem colunas obrigatórias | `Aba 'X' sem as colunas [...]` |
| Data em formato desconhecido | `Data em formato não reconhecido: '…'` |
| Faixa contínua inválida | `Aba 'X', coluna 'Y': faixa inválida '…'. Use o formato '18 a 25'.` |
| Sem acesso ao SQL Server | `Sem acesso: SQL Server (…)` |
| Configuração faltando | `Faltam variáveis no .env: SQL_SERVIDOR, …` |

## Validações da API (antes de chegar ao worker)

| Regra | Resposta |
|---|---|
| Extensão diferente de `.xlsx` / `.xlsm` | 422 *Envie a planilha XLSX do modelo oficial.* |
| Arquivo acima de `TAMANHO_MAXIMO_MB` | 413 *A planilha passa de N MB.* |
| Conteúdo não começa com a assinatura ZIP (`PK\x03\x04`) | 422 *O arquivo não é uma planilha XLSX válida.* |
| Enviar uma validação que não terminou sem erros | 409 *A planilha precisa estar validada e sem erros para enviar.* |
| Categoria fora de `CATEGORIAS` | 422 *Categoria do pedido inválida.* |
| Validação já enviada | 409 *Esta planilha já foi enviada na solicitação do lote X.* |
| Campos do formulário vazios ou longos demais | 422 (validação do Pydantic) |

O frontend repete as checagens de extensão e tamanho antes do upload, para dar a resposta na hora.
