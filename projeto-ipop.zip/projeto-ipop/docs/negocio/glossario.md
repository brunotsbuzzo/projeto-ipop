# Glossário

Agravo
:   Aumento de prêmio. Na planilha, Fator > 1 (`1,58` = +58%).

Desconto
:   Redução de prêmio. Na planilha, Fator ≤ 1 (`0,90` = −10%).

Agrupamento (Oferta)
:   Conjunto de CPF/CNPJ cadastrado no IPOP com um nome. Na aba de Oferta, o *Nome Agrupamento* é o nome da regra **e** o valor da variável CPF/CNPJ (agrupamento, ID 193).

Ambiente
:   `hml` (homologação, `net.hdi.com.br`) ou `prd` (produção, `www.hdi.com.br`) do IPOP.

Aviso
:   Problema na planilha que **não** bloqueia o envio.

Batimento (heartbeat)
:   Sinal de vida que o worker grava no Postgres a cada 5 s. Sem batimento por mais de 2 min, a execução é considerada órfã.

Cadastro
:   Execução do tipo `cadastro`: abre o IPOP e cria as regras. Na tela, é a **solicitação**.

Categoria do pedido
:   Classificação da solicitação (`Renovação Ituran`, `Frota`…). Configurada em `CATEGORIAS`.

Cópia de…
:   Regra criada pelo botão *Copiar* do IPOP a partir de uma regra-modelo. É a única que o robô aceita editar.

Domínio (IdDominio)
:   Valor possível de uma variável categórica no IPOP (tabela `[var].[VariavelDominio]` do RosieRep).

Erro
:   Problema na planilha que **bloqueia** o envio.

Execução
:   Registro na tabela `execucoes`. Pode ser do tipo `validacao` ou `cadastro`.

Fase
:   Estado técnico da execução (`na_fila`, `cadastrando`, `concluida`…). Veja [Status](status.md).

Fator
:   Na Subscrição, o multiplicador do prêmio. Na Oferta (`Fator (%)`), o percentual.

Grupo de variável
:   Agrupador do IPOP onde a variável aparece no formulário (`[var].[GrupoVariavelDetalhe]`). Sem grupo, a variável não pode ser cadastrada.

IPOP
:   Sistema de precificação da HDI (`/rosie/ipop_v4`), com os módulos Subscrição e Oferta.

Lote (ID do lote)
:   Identificador do pedido no **Taskflow**. Aparece como "ID solicitado" no histórico.

Modelo de regra (regra-modelo)
:   Regra do IPOP usada como base. Já traz variáveis fixas (produto, fluxo, roteiro). Listada em `TblRegraModelo.xlsx`.

NomeDW
:   Nome técnico da variável no data warehouse. É o que vai no cabeçalho da coluna da planilha.

Órfã
:   Execução cujo worker parou de dar sinal de vida. Vira *Interrompida*.

Pré-visualização
:   Tabela de regras lida da planilha, mostrada antes do envio.

RosieRep
:   Banco SQL Server com o cadastro de variáveis, grupos e domínios do IPOP. O robô só lê dele.

Solicitação
:   Pedido de cadastro enviado pela tela (execução do tipo `cadastro`).

Status Tag
:   Componente do design system que mostra o status com cor (success, processing, warning, error, default, info).

Taskflow
:   Ferramenta onde os lotes de regras são registrados. Não há integração automática.

Trace
:   Gravação completa da sessão do Playwright (`trace.zip`), com prints, DOM e rede. Abre em <https://trace.playwright.dev>.

Validação
:   Execução do tipo `validacao`: lê e confere a planilha **sem** abrir o IPOP.

Variável categórica
:   Variável de valores discretos (parceiro, bônus, CPF/CNPJ). Vários valores separados por `;`.

Variável contínua
:   Variável numérica por faixa (idade). Formato `18 a 25`.

Worker
:   Processo que executa as validações e os cadastros (o "robô").
