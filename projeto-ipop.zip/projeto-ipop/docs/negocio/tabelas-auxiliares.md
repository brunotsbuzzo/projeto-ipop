# Tabelas auxiliares

São duas planilhas que traduzem o que a pessoa escreve na planilha do pedido para os códigos do IPOP. As duas vêm com a imagem (`backend/dados/tbl_dim/`) e podem ser **substituídas sem nova versão**: basta enviá-las ao bucket (veja [Operação](../infraestrutura/operacao.md#atualizar-as-tabelas-auxiliares)).

| Arquivo | Para quê | Colunas usadas |
|---|---|---|
| `TblRegraModelo.xlsx` | Nome do modelo → ID da regra-modelo no IPOP, e nome exibido da cópia | `Modelos de regras`, `Descrição`, `ID`, `NomeRegraIPOP` |
| `TblDePara.xlsx` | NomeDW da coluna da planilha → ID da variável no IPOP | `IDVariavel`, `NmVariavel`, `Nome Ipop`, `NomeDW` |

!!! note "De onde vêm as tabelas usadas"
    Em cada execução, o worker baixa `config/tbl_dim/TblDePara.xlsx` e `config/tbl_dim/TblRegraModelo.xlsx` do bucket. Se **as duas** existirem, usa as do bucket. Se só uma existir, registra um aviso e usa **as duas da imagem**. A planilha-modelo para download segue a mesma lógica.

## Modelos de regras

Conteúdo atual de `TblRegraModelo.xlsx`:

| Modelos de regras | Descrição | ID | NomeRegraIPOP |
|---|---|---:|---|
| Frota Fluxo 2022 (139) | Inclui na regra produto 131, fluxo 2022 e roteiro 8 | 119989 | Regra Modelo Frota Fluxo 2022 (139) |
| Frota Fluxo 2022 (131) | Inclui na regra produto 139, fluxo 2022 e roteiro 8 | 119988 | Regra Modelo Frota Fluxo 2022 (131) |
| Ituran Compreensiva | Inclui na regra produto Ituran compreensiva | 119978 | Regra Modelo - Renovação Ituran Compreensiva |
| Ituran Não Compreensiva | Inclui na regra produto Ituran não compreensiva | 119979 | Regra Modelo - Renovação Ituran Não Compreensiva |
| Não se aplica | Aplica na regra apenas as variáveis escolhidas pelo usuário | — | — |
| Perfilados Fluxo 2023 | Inclui na regra produtos perfilados, fluxo 2023 e roteiro 6 | 119987 | Regra Modelo Perfilados Fluxo 2023 |
| Frota (131) Compreensiva | Incluir fluxo 2022, produto 131, compreensiva e roteiro 8 | 120093 | Regra Modelo - Frota (131) Compreensiva |
| Frota (139) Compreensiva | Incluir fluxo 2022, produto 139, compreensiva e roteiro 8 | 120508 | Regra Modelo - Frota (139) Compreensiva |
| Frota (131 e 139) Compreensiva | Incluir fluxo 2022, produto 131 e 139, compreensiva e roteiro 8 | 120509 | Regra Modelo - Frota (131 e 139) Compreensiva |
| Regra Robo Ituran | Inclui na regra produto Ituran não compreensiva | 126950 | Regra Robo Ituran |

- `Não se aplica` não tem ID, então a regra é criada do zero.
- `NomeRegraIPOP` forma o nome da cópia procurada quando o IPOP não deixa a cópia selecionada: `Cópia de <NomeRegraIPOP>`.
- Para **Oferta**, o modelo padrão (`OFERTA_MODELO_ID`, 139278) não está nesta tabela. Na lista do IPOP de homologação ele aparece como *Regra Modelo Oferta Ituran*.

!!! warning "Atenção às descrições do Frota Fluxo 2022"
    Na tabela atual, a descrição de *Frota Fluxo 2022 (139)* cita o produto 131, e a de *(131)* cita o 139. Confirme com a área de negócio qual está certa antes de usar esses modelos.

## Tabela de variáveis (De-Para)

O robô procura o cabeçalho da coluna (o **NomeDW**) e pega o `IDVariavel`. O `Nome Ipop` é o nome mostrado na pré-visualização.

!!! warning "NomeDW repetido"
    Estes NomeDW aparecem mais de uma vez: `CodCaracterAuto`, `CodCategTarifa`, `CodCongenere`, `CodGrpModelo`, `CodRegCirc`, `CodRegiaoRiscoAuto`, `IdadeVeiculo` e `NroCpfCnpj`. O robô usa **a primeira linha** da tabela. Exemplos: `NroCpfCnpj` → **193** (*CPF / CNPJ (agrupamento)*), e não 21; `CodCaracterAuto` → **42**. Para usar outra variável, reordene a tabela ou crie um NomeDW único para ela.

    A variável 193 (CPF/CNPJ por agrupamento) é a que a Oferta usa. O grid dela no IPOP é muito grande, por isso o robô filtra a resposta (veja [Automação do IPOP](../codigo/backend/automacao-ipop.md#filtro-do-grid-pesado)).

Conteúdo atual de `TblDePara.xlsx` (65 variáveis):

| IDVariavel | Nome no IPOP | NomeDW (coluna da planilha) |
|---:|---|---|
| 241 | Flag Recálculo da Apólice para Endossos | `CalcApolEndosso` |
| 31 | CEP de Circulação | `CepCirculacao` |
| 32 | CEP de Pernoite | `CepPernoite` |
| 40 | Classe de Bônus | `ClasseBonus` |
| 295 | Cód Alteração Endosso - (Agrupamento) | `CodAlteracaoEndosso` |
| 240 | Código Atividade | `CodAtividade` |
| 42 | Modelo do Veículo | `CodCaracterAuto` |
| 110 | Marca do Veículo | `CodCaracterAuto` |
| 126 | Modelos | `CodCaracterAuto` |
| 141 | Modelos de Veículos Categorias | `CodCaracterAuto` |
| 33 | Categoria Tarifária | `CodCategTarifa` |
| 144 | Categorias Nacional Importado | `CodCategTarifa` |
| 217 | Classe Veículo | `CodClasseVeiculo` |
| 35 | Congênere | `CodCongenere` |
| 131 | Tipo de Negócio | `CodCongenere` |
| 17 | Corretora | `CodCorretor` |
| 5 | Empresa | `CodEmpresa` |
| 88 | Estipulante | `CodEstipulante` |
| 125 | Forma de Contratação | `CodFormaContrat` |
| 212 | Grupos de Modelos | `CodGrpModelo` |
| 213 | Grupos de Modelos (agrupamento) | `CodGrpModelo` |
| 258 | Código Loja Santander Auto | `CodLojaSantander` |
| 229 | Código Parceiro | `CodParceiro` |
| 192 | HDI DUO - Planos | `CodPlanoPatr` |
| 8 | Produto | `CodPrdOperac` |
| 90 | Região de Circulação | `CodRegCirc` |
| 211 | Região Circulação (agrupamento) | `CodRegCirc` |
| 386 | Código de região de risco | `CodRegiaoRiscoAuto` |
| 495 | Código de região de risco (agrupamento) | `CodRegiaoRiscoAuto` |
| 372 | RNS do Segurado (Agrupamento) | `CodRNSSegurado` |
| 147 | Agrupamento RNS do Veículo | `CodRNSVeiculo` |
| 228 | Roteiro de cálculo | `CodRoteiroCalc` |
| 116 | Sexo do Condutor | `CodSexo` |
| 7 | Filial | `CodSucursal` |
| 226 | Tipo de Operação do Item | `CodTpOperacaoItem` |
| 205 | Tipo de Pessoa | `CodTpPessoa` |
| 191 | Tipo de Renovação | `CodTpRenovacao` |
| 221 | Utilização de Veículo | `CodUtilizVeiculo` |
| 260 | Flag Possui Blindagem | `FlagPossuiBlindagem` |
| 259 | Flag Possui Kit Gás | `FlagPossuiKitGas` |
| 132 | Zero km | `FlagZeroKm` |
| 304 | Fluxo de Cálculo | `FluxoCalculoPremio` |
| 182 | Idade Condutor | `IdadeCondutor` |
| 201 | Idade do Segurado | `IdadeSegurado` |
| 142 | Idade do Veículo (por faixa) | `IdadeVeiculo` |
| 136 | Idade do Veículo | `IdadeVeiculo` |
| 347 | Natureza JurÍdica | `NaturezaJuridica` |
| 193 | CPF / CNPJ (agrupamento) | `NroCpfCnpj` |
| 21 | CPF / CNPJ do Segurado | `NroCpfCnpj` |
| 122 | FIPE | `PercFipe` |
| 220 | Relação do Prêmio Final/IS em % | `PercPremioISFinal` |
| 377 | Pontuação do score autoGlass | `PtoScoreAutoGlass` |
| 256 | Score Risco Cadastral | `PtoScoreCadastral` |
| 251 | Score Risco Georreferenciado | `PtoScoreGeorref` |
| 296 | Score Multi Score | `PtoScoreMultiScore` |
| 269 | Score PJ Perda Parc | `PtoScorePJPerdaParc` |
| 206 | Pontuação Fonte RF | `PtoScoreRF` |
| 378 | Pontuacao Score de RF (Neurotech) | `PtoScoreRFv4` |
| 200 | Score Customizado | `PtoScoreSerasa` |
| 230 | Score Sinistro | `PtoScoreSinistro` |
| 289 | Qtde de Itens | `QtdeItens` |
| 279 | Qtde Meses Relação Total | `QtdeMesesRelacTotal` |
| 64 | Tipo de Operação | `TipoOperacao` |
| 47 | Valor IS Casco Merc | `VlrIscascomer` |
| 49 | Valor IS RCF DM | `VlrIsDm` |
